package api;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;
import mobile.common.exceptions.InvalidEnvironmentException;

@Slf4j
public class ApiBase {

    private static final String HOST_QA = "";
    private static final String HOST_STAGING = "";
    private static final String HOST_PROD = "";
    private static final String CLIENTID = "NIOy7ZkGWQTN3vywLIzRH9WSD6kKThkw";
    private static final String CLIENTSECRET = "RkNT1LAbaw67VXN0IH_adyvob1a8kV4VKbGPrqEUOE0Gum7IO5QKRxqBHahLd9MI";
    private static String HOST = null;

    protected ApiBase() {
        final String environment = System.getProperty("appium.environment").toLowerCase();
        switch (environment) {
            case "qa":
                HOST = HOST_QA;
                break;
            case "staging":
                HOST = HOST_STAGING;
                break;
            case "prod":
                HOST = HOST_PROD;
                break;
            default:
                throw new InvalidEnvironmentException("Invalid Environment");
        }
    }

    public static RequestSpecification getRequestSpec(final String token) {

        RestAssured.baseURI = HOST;
        return RestAssured.given()
                .accept("application/json")
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + token)
                .log().all();
    }

    public static Response getResponse(final String urlPath, final String token) {
        return getRequestSpec(token).get(urlPath);
    }

    public static Response delete(final String urlPath, final String token) {
        return getRequestSpec(token).delete(urlPath);
    }

    public static Response post(final String urlPath, final String token, final Object bodyObject) {
        return getRequestSpec(token).body(bodyObject).post(urlPath);
    }

    public static Response put(final String urlPath, final String token, final Object bodyObject) {
        return getRequestSpec(token).body(bodyObject).put(urlPath);
    }

    public static Response getResponse(final RequestSpecification request, final String urlPath) {
        return request.get(urlPath);
    }
}
