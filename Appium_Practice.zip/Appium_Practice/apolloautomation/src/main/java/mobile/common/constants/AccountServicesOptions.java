package mobile.common.constants;

import mobile.common.exceptions.InvalidAccountServiceException;

import java.util.HashMap;
import java.util.Map;

public enum AccountServicesOptions {
    DOCUMENT_DELIVERY("Document Delivery"),
    EMAIL_NOTIFICATION("Email Notifications"),
    PASSWORD_AND_SECURITY("Password and Security"),
    ACCOUNT_NAMES("Account Names");

    private static final Map<String, AccountServicesOptions> ACCOUNTSERVICES_MAP = new HashMap<>();

    static {
        for (AccountServicesOptions t : values()) {
            ACCOUNTSERVICES_MAP.put(t.option, t);
        }
    }

    private final String option;

    AccountServicesOptions(String option) {
        this.option = option;
    }

    public static AccountServicesOptions fromValue(final String value) {
        AccountServicesOptions result = ACCOUNTSERVICES_MAP.get(value);

        if (null == result) {
            throw new InvalidAccountServiceException(
                    String
                            .format("Not a valid %s value: %s",
                                    AccountServicesOptions.class.getSimpleName(),
                                    value));
        }
        return result;
    }

    @Override
    public String toString() {
        return option;
    }
}
