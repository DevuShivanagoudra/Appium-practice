package mobile.common.constants;

import mobile.common.exceptions.InvalidAccountServiceException;

import java.util.HashMap;
import java.util.Map;

public enum ExternalAccounts {
    ACCOUNT_NAMES1("Banking"),
    ACCOUNT_NAMES2("Credit Card"),
    ACCOUNT_NAMES3("Pacific Life - Versa-Flex III");

    private static final Map<String, ExternalAccounts> ACCOUNTNAMES_MAP = new HashMap<>();

    static {
        for (ExternalAccounts t : values()) {
            ACCOUNTNAMES_MAP.put(t.option, t);
        }
    }

    private final String option;

    ExternalAccounts(String option) {
        this.option = option;
    }

    public static ExternalAccounts fromValue(final String value) {
        ExternalAccounts result = ACCOUNTNAMES_MAP.get(value);

        if (null == result) {
            throw new InvalidAccountServiceException(
                    String
                            .format("Not a valid %s value: %s",
                                    ExternalAccounts.class.getSimpleName(),
                                    value));
        }
        return result;
    }

    @Override
    public String toString() {
        return option;
    }
}

