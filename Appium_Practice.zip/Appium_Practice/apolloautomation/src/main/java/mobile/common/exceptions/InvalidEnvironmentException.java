package mobile.common.exceptions;

public class InvalidEnvironmentException extends RuntimeException {

    public InvalidEnvironmentException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidEnvironmentException(String message) {
        super(message);
    }
}
