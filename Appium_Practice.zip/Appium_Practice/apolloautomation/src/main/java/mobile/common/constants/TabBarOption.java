package mobile.common.constants;

import jarvis.mobile.common.exceptions.InvalidTabBarOptionException;

import java.util.HashMap;
import java.util.Map;

public enum TabBarOption {
    DASHBOARD("Dashboard"),
    ACCOUNTS("Accounts"),
    PORTFOLIO("Portfolio"),
    ANALYSIS("Analysis"),
    ACTIVITY("Activity"),
    MORE("More");

    private static final Map<String, TabBarOption> TABBAR_MAP = new HashMap<>();

    static {
        for (TabBarOption t : values()) {
            TABBAR_MAP.put(t.option, t);
        }
    }

    private final String option;

    TabBarOption(String option) {
        this.option = option;
    }

    public static TabBarOption fromValue(final String value) {
        TabBarOption result = TABBAR_MAP.get(value);

        if (null == result) {
            throw new InvalidTabBarOptionException(
                    String
                            .format("Not a valid %s value: %s", TabBarOption.class.getSimpleName(), value));
        }
        return result;
    }

    @Override
    public String toString() {
        return option;
    }
}
