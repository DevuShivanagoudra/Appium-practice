package mobile.common.constants;

public enum TransferTypes {
    NEWTRANSFER("New Transfer"),
    PENDING("Pending"),
    HISTORY("History");

    private String state;

    TransferTypes(final String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return state;
    }
}
