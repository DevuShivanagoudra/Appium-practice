package mobile.common.constants;

import mobile.common.exceptions.InvalidOptionException;

import java.util.HashMap;
import java.util.Map;

public enum ErrorMessages {
    ACCOUNTNAME_INVALIDTEXT(
            "Account name is invalid. The account name can only contain alphanumeric, period, dash, and apostrophe characters, and must be between 2 and 60 characters"),
    INCORRECTSECRETANSWER_ERROR("The information you provided does not match our records.");

    private static final Map<String, ErrorMessages> MESSAGES_MAP = new HashMap<>();

    static {
        for (ErrorMessages t : values()) {
            MESSAGES_MAP.put(t.option, t);
        }
    }

    private final String option;

    ErrorMessages(String option) {
        this.option = option;
    }

    public static ErrorMessages fromValue(final String value) {
        ErrorMessages result = MESSAGES_MAP.get(value);

        if (null == result) {
            throw new InvalidOptionException(
                    String
                            .format("Not a valid %s value: %s", ErrorMessages.class.getSimpleName(),
                                    value));
        }
        return result;
    }

    @Override
    public String toString() {
        return option;
    }
}
