package mobile.common.constants;

import jarvis.mobile.common.exceptions.InvalidTypeException;

public enum Toggle {
    ON("true"),
    OFF("false");

    private String state;

    Toggle(String state) {
        this.state = state;
    }

    public boolean getBoolValue() {
        try {
            return Boolean.parseBoolean(getState());
        } catch (Exception e) {
            throw new InvalidTypeException(String.format("Unsupported Toggle state `%s`", state));
        }
    }

    public String getState() {
        return state;
    }
}
