package mobile.common.constants;

import mobile.common.exceptions.InvalidOptionException;

import java.util.HashMap;
import java.util.Map;

public enum MoreOptions {
    CLIENT_TOOLS("Client Tools"),
    DOCUMENTS("Documents"),
    ACTIVITY("Activity"),
    VAULT("Vault"),
    FUNDS_TRANSFER("Funds Transfer"),
    ANALYSIS("Analysis"),
    MARKETRESEARCH("Market Research"),
    NOTIFICATIONS("Notifications");

    private static final Map<String, MoreOptions> MOREOPTIONS_MAP = new HashMap<>();

    static {
        for (MoreOptions t : values()) {
            MOREOPTIONS_MAP.put(t.option, t);
        }
    }

    private final String option;

    MoreOptions(String option) {
        this.option = option;
    }

    public static MoreOptions fromValue(final String value) {
        MoreOptions result = MOREOPTIONS_MAP.get(value);

        if (null == result) {
            throw new InvalidOptionException(
                    String
                            .format("Not a valid %s value: %s", MoreOptions.class.getSimpleName(), value));
        }
        return result;
    }

    @Override
    public String toString() {
        return option;
    }
}
