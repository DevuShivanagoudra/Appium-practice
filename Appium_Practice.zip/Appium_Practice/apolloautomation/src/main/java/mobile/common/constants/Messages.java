package mobile.common.constants;

import mobile.common.exceptions.InvalidOptionException;

import java.util.HashMap;
import java.util.Map;

public enum Messages {
    DOCUMENTS_DISCLOSURES(
            "If online delivery of the client’s documents is selected, the selected documents will be delivered electronically; they will not receive these documents by mail. Email notifications will be sent when the documents are available online. These may include statements for deposit accounts held at Raymond James Bank, as applicable. Documents that are not currently offered online-only will be mailed to the client’s address(es) of record.\n"
                    +
                    "\n" +
                    "With electronic delivery of monthly Investment account statements, the client will automatically receive an online annual summary of activity. With these accounts, they may also choose to receive a paper annual or quarterly summary of activity. With paper document delivery, certain documents such as statements and trade confirmations will also be available online.\n"
                    +
                    "\n" +
                    "Tax reports that may be delivered online include: IRS Composite form (1099-B, -DIV, -INT, -MISC, -OID) and [RS Forms 1099-R, 1099-Q, 5498, and 1042-S. Other correspondence that may be delivered online include: Disclosure documents (such as ADV disclosures for advisory accounts and disclosures for ERISA accounts), confirmations of certain activities (such as international wire transfers or new account profiles that have been established), verifications of information about clients and/or their accounts, and other notifications that may be delivered to clients electronically with their consent.\n"
                    +
                    "\n" +
                    "If you choose the Paper option for Prospectuses, it will not apply to prospectuses for Syndicate transactions. Syndicate prospectuses are only delivered electronically."),

    NO_DOCUMENTS_TEXT("There are no documents available for the filter options you selected."),
    NO_DOCUMENTS_TEXT_iOS("There are no recent documents to show"),
    NOT_GETTING_EMAIL_NOTIFICATIONS_HEADER("Not getting your email notifications?"),
    NOT_GETTING_EMAIL_NOTIFICATIONS_TEXT(
            String.format(
                    "To ensure the following email addresses aren’t filtered as spam, add them to your contacts:")),
    NOT_GETTING_EMAIL_NOTIFICATIONS_EMAIL_IDs(String.format(
            "• Prospectus_mbox@investordelivery.com\n" +
                    "• id@proxyvote.com\n" +
                    "• notifyinvestor@RaymondJames.com")
    ),
    NOT_GETTING_EMAIL_NOTIFICATIONS_EMAIL_IDs_IOS(String.format(
            " • Prospectus_mbox@investordelivery.com\n" +
                    " • id@proxyvote.com\n" +
                    " • notifyinvestor@RaymondJames.com")),
    ALLOCATION_DESCRIPTION_TEXT(
            "The Asset Allocation Analysis reflects the various asset classes held in your selected account(s). Some investments, such as mutual funds and annuities, may have been split more than one asset class based on their underlying holdings, as reported by Morningstar.\n"
                    +
                    "\n" +
                    "Morningstar mutual fund and annuity information is as of October 3, 2022. Raymond James and Morningstar data are subject to the availability of fund filings as well as internal analysis and may not represent real-time allocations.\n"
                    +
                    "\n" +
                    "Morningstar 529 information as of October 3, 2022.\n" +
                    "\n" +
                    "This analysis is for informational purposes only and is intended to be used as part of a complete portfolio review with your financial advisor. The data provided in this analysis is subject to inherent limitations and is not guaranteed to represent actual asset class exposure(s) within your account(s) at the time of calculation. See the FAQ to learn more.\n"
                    +
                    "\n" +
                    "© 2023 Morningstar, Inc. All rights reserved. The information contained herein: (1) is proprietary to Morningstar and/or its content providers; (2) may not be copied or distributed; and (3) is not warranted to be accurate, complete or timely. Neither Morningstar nor its content providers are responsible for any damages or losses arising from any use of this information. Past performance is no guarantee of future results."),
    ALLOCATION_DESCRIPTION_TEXT_ANDROID(
            "The Asset Allocation Analysis reflects the various asset classes held in your selected account(s). Some investments, such as mutual funds and annuities, may have been split more than one asset class based on their underlying holdings, as reported by Morningstar."),
    ALLOCATION_DESCRIPTION_TEXT_ANDROID1(
            "Morningstar mutual fund and annuity information is as of September 20, 2022. Raymond James and Morningstar data are subject to the availability of fund filings as well as internal analysis and may not represent real-time allocations."),
    ALLOCATION_DESCRIPTION_TEXT_ANDROID2("Morningstar 529 information as of September 20, 2022."),
    ALLOCATION_DESCRIPTION_TEXT_ANDROID3(
            "This analysis is for informational purposes only and is intended to be used as part of a complete portfolio review with your financial advisor. The data provided in this analysis is subject to inherent limitations and is not guaranteed to represent actual asset class exposure(s) within your account(s) at the time of calculation. See the FAQ to learn more."),
    ALLOCATION_DESCRIPTION_TEXT_ANDROID4(
            String.format(
                    "© 2023 Morningstar, Inc. All rights reserved. The information contained herein: (1) is proprietary to Morningstar and/or its content providers; (2) may not be copied or distributed; and (3) is not warranted to be accurate, complete or timely. Neither Morningstar nor its content providers are responsible for any damages or losses arising from any use of this information. Past performance is no guarantee of future results.")),
    DAILY_CHANGE_INFO_TEXT(
            "Due to variations in timing and availability of product prices, this total may not represent all market value changes in your portfolio."),

    ACTIVITY_DISCLOSURES_TEXT_ANDROID1(
            String.format(
                    "© 2023 Raymond James & Associates, Inc., Member New York Stock Exchange/SIPC. | Statement of Financial Condition.")),
    ACTIVITY_DISCLOSURES_TEXT_ANDROID2(
            "The Dow Jones (“Index”) is a product of S&P Dow Jones Indices LLC, its affiliates and/or their licensors and has been licensed for use. Copyright © 2023 S&P Dow Jones Indices LLC, its affiliates and/or their licensors. All rights reserved. Redistribution or reproduction in whole or in part are prohibited without written permission of S&P Dow Jones Indices LLC. For more information on any S&P Dow Jones Indices LLC’s indices please visit: https://www.spglobal.com/spdji/en/disclaimers/"),
    ACTIVITY_DISCLOSURES_TEXT_ANDROID3(
            "Raymond James & Associates, Inc. member New York Stock Exchange / SIPC and Raymond James Financial Services, Inc. member FINRA / SIPC are subsidiaries of Raymond James Financial, Inc."),
    ACTIVITY_DISCLOSURES_TEXT_ANDROID4(String.format("Privacy / Security")),
    ACTIVITY_DISCLOSURES_TEST_IOS(
            String.format(
                    "© 2023 Raymond James & Associates, Inc., Member New York Stock Exchange/SIPC. | Statement of Financial Condition.\n"
                            + "\n" +
                            "The Dow Jones (%sIndex%s) is a product of S&P Dow Jones Indices LLC, its affiliates and/or their licensors and has been licensed for use. Copyright © 2023 S&P Dow Jones Indices LLC, its affiliates and/or their licensors. All rights reserved. Redistribution or reproduction in whole or in part are prohibited without written permission of S&P Dow Jones Indices LLC. For more information on any S&P Dow Jones Indices LLC’s indices please visit: https://www.spglobal.com/spdji/en/disclaimers/\n"
                            + "\n" +
                            "Raymond James & Associates, Inc. member New York Stock Exchange / SIPC and Raymond James Financial Services, Inc. member FINRA / SIPC are subsidiaries of Raymond James Financial, Inc.\n"
                            + "\n" +
                            "Privacy / Security", "“", "”")),
    UNREALIZEDGAINLOSS_MESSAGE(
            "Total unrealized gain/loss values (Investment gain/loss, Cost Basis gain/loss) may differ from the unrealized Summary short term and long term gain/loss due to rounding, fractional share differences between position share quantity and tax lot quantity, and/or the timing of corporate action event updates. Unrealized Investment gain/loss values displayed are not indicative of taxable gain/loss that may be reported at year-end."),

    DOCUMENTS_SHAREHOLDER_TEXT(
            "Shareholder Documents are available in Client Access for your convenience; They do not replace hard copies mailed to your address of record except when (and to the extent that) you elect to suppress postal delivery of any such documents as described in Section 22 of the Terms & Conditions. During maintenance periods, access to online documents will not be available. If, at any time, you see an error in any document, please contact your financial advisor or Raymond James Client Services at 877-752-2237 immediately."),
    DOCUMENTS_SHAREHOLDER_TEXT_ANDROID(
            String.format(
                    "Shareholder Documents are available in Client Access for your convenience; They do not replace hard copies mailed to your address of record except when (and to the extent that) you elect to suppress postal delivery of any such documents as described in Section 22 of the Terms & Conditions. During maintenance periods, access to online documents will not be available. If, at any time, you see an error in any document, please contact your financial advisor or Raymond James Client Services at 877–752–2237 immediately.")),
    VAULT_DELETE_FOLDER_CONFIRMATION("Are you sure you want to delete %s and all its contents?"),
    VAULT_DELETE_FOLDER_CONFIRMATION_IOS(
            "Are you sure you want to delete “%s” and all its contents?"),
    FUNDSTRANSFER_SUMMARYCOPY(
            "For transfers to or from non-Raymond James accounts to be processed the next business day, the cutoff time is 4 p.m. ET. For transfers between Raymond James accounts to be effective same day, the cutoff time is 7:30 p.m. ET."),
    NEWTRANSFER_SUBTEXT("Submit new fund transfers between accounts"),
    PENDING_SUBTEXT("View, edit or cancel pending transfers"),
    HISTORY_SUBTEXT("View all previous transfers"),
    NO_PENDINGTRANSFERS_MESSAGE("No pending transactions are available at this time."),
    NO_TRANSFERHISTORY_MESSAGE("No transfer history is available at this time."),
    HISTORY_COPY(String.format(
            "View up to 13 months of completed and canceled transfers.\nSee Activity for a comprehensive view of historical activity for your\naccount(s).")),
    HISTORY_COPY_IOS(String.format(
            "View up to 13 months of completed and canceled transfers. See Activity for a comprehensive view of historical activity for your account(s).")),
    HISTORY_DISCLOSURES_TEXT_IOS(String.format(
            "© 2023 Raymond James & Associates, Inc., Member New York Stock Exchange/SIPC. | Statement of Financial Condition.\n"
                    + "\n"
                    + "The Dow Jones (“Index”) is a product of S&P Dow Jones Indices LLC, its affiliates and/or their licensors and has been licensed for use. Copyright © 2023 S&P Dow Jones Indices LLC, its affiliates and/or their licensors. All rights reserved. Redistribution or reproduction in whole or in part are prohibited without written permission of S&P Dow Jones Indices LLC. For more information on any S&P Dow Jones Indices LLC’s indices please visit: https://www.spglobal.com/spdji/en/disclaimers/\n"
                    + "\n"
                    + "Raymond James & Associates, Inc. member New York Stock Exchange / SIPC and Raymond James Financial Services, Inc. member FINRA / SIPC are subsidiaries of Raymond James Financial, Inc.\n"
                    + "\n"
                    + "Privacy / Security")),
    HISTORY_DISCLOSURES_TEXT(String
            .format("© 2023 Raymond James & Associates, Inc., Member New York Stock Exchange/SIPC. | \n"
                    + "Statement of Financial Condition.\n"
                    + "\n"
                    + "The Dow Jones (“Index”) is a product of S&P Dow Jones Indices LLC, its affiliates and/or their licensors and has been licensed for use. Copyright © 2023 S&P Dow Jones Indices LLC, its affiliates and/or their licensors. All rights reserved. Redistribution or reproduction in whole or in part are prohibited without written permission of S&P Dow Jones Indices LLC. For more information on any S&P Dow Jones Indices LLC’s indices please visit: https://www.spglobal.com/spdji/en/disclaimers/\n"
                    + "\n"
                    + "Raymond James & Associates, Inc. member New York Stock Exchange / SIPC and Raymond James Financial Services, Inc. member FINRA / SIPC are subsidiaries of Raymond James Financial, Inc.\n"
                    + "\n"
                    + "Privacy / Security\n"));

    private static final Map<String, Messages> MESSAGES_MAP = new HashMap<>();

    static {
        for (Messages t : values()) {
            MESSAGES_MAP.put(t.option, t);
        }
    }

    private final String option;

    Messages(String option) {
        this.option = option;
    }

    public static Messages fromValue(final String value) {
        Messages result = MESSAGES_MAP.get(value);

        if (null == result) {
            throw new InvalidOptionException(
                    String
                            .format("Not a valid %s value: %s", Messages.class.getSimpleName(), value));
        }
        return result;
    }

    @Override
    public String toString() {
        return option;
    }
}
