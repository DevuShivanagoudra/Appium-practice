package mobile.common.constants;

public enum MarketResearchOptions {
    WATCHLIST("Watch List"),
    SYMBOLQUOTE("Symbol Quote"),
    OPTIONQUOTE("Option Quote"),
    OPTIONCHAIN("Option Chain"),
    EQUITYRESEARCH("Equity Research"),
    COMMENTARY("Commentary");

    private String option;

    MarketResearchOptions(final String option) {
        this.option = option;
    }

    @Override
    public String toString() {
        return option;
    }
}
