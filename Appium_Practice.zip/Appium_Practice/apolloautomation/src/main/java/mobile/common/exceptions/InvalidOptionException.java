package mobile.common.exceptions;

public class InvalidOptionException extends RuntimeException {

    public InvalidOptionException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidOptionException(String message) {
        super(message);
    }
}
