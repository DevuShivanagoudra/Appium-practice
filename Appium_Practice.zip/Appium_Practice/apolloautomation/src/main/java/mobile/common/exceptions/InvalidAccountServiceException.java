package mobile.common.exceptions;

public class InvalidAccountServiceException extends RuntimeException {

    public InvalidAccountServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidAccountServiceException(String message) {
        super(message);
    }
}
