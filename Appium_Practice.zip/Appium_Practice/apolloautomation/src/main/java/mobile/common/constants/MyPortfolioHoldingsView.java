package mobile.common.constants;

import mobile.common.exceptions.InvalidOptionException;

import java.util.HashMap;
import java.util.Map;

public enum MyPortfolioHoldingsView {
    GainLoss("Unrealized G/L"),
    GainLoss_Android("Unrealized Gain/Loss"),
    ValueChange("Daily Value Change");

    private static final Map<String, MyPortfolioHoldingsView> VIEWOPTIONS_MAP = new HashMap<>();

    static {
        for (MyPortfolioHoldingsView t : values()) {
            VIEWOPTIONS_MAP.put(t.option, t);
        }
    }

    private final String option;

    MyPortfolioHoldingsView(String option) {
        this.option = option;
    }

    public static MyPortfolioHoldingsView fromValue(final String value) {
        MyPortfolioHoldingsView result = VIEWOPTIONS_MAP.get(value);

        if (null == result) {
            throw new InvalidOptionException(
                    String.format("Not a valid %s value: %s", MyPortfolioHoldingsView.class.getSimpleName(), value));
        }
        return result;
    }

    @Override
    public String toString() {
        return option;
    }
}
