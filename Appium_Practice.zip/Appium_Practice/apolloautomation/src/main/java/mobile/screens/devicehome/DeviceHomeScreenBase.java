package mobile.screens.devicehome;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static io.appium.java_client.pagefactory.LocatorGroupStrategy.ALL_POSSIBLE;
import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class DeviceHomeScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"SIGN IN\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Work Client Access\").instance(0)")
    protected WebElement clientAccessApp;

    @HowToUseLocators(androidAutomation = ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypePageIndicator[`name == \"Page control\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\".*launcher:id/workspace\")")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\".*launcher3:id/workspace\")")
    protected WebElement springBoard;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypePageIndicator[`name == \"Page control\"`]")
    @AndroidFindBy(id = "android:id/navigationBarBackground")
    protected WebElement background;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"OPEN\"`]")
    @AndroidFindBy(accessibility = "Open")
    protected WebElement open;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"UPDATE\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.view.View\").description(\"Update\")")
    protected WebElement update;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"INSTALL\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.view.View\").description(\"Install\")")
    protected WebElement install;

    protected DeviceHomeScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Launches app from TestFlight(IOS) or Work Playstore(Android).
     */
    public abstract void launchApp();

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(springBoard, MAXIMUM_WAIT_TIMEOUT,
                "Device Home not displayed.");
    }
}