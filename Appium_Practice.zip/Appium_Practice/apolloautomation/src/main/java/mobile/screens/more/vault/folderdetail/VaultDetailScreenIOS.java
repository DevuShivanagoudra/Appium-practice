package mobile.screens.more.vault.folderdetail;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.screens.more.vault.VaultScreenIOS;

@Slf4j
@Getter
public class VaultDetailScreenIOS extends VaultScreenIOS {

    public VaultDetailScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
