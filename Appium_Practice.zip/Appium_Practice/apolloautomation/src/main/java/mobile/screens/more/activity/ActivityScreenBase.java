package mobile.screens.more.activity;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class ActivityScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Last 30 Days\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Date Range-dropDownIcon\")")
    private WebElement dateRange;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Disclosures\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"DisclosuresText\")")
    private WebElement disclosures;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Pending Activity\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Pending Activity-expandableSurface\").childSelector(new UiSelector().resourceId(\"icon\"))")
    private WebElement pendingActivity;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"All Types\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"ViewoutlineTextField\").childSelector(new UiSelector().resourceId(\"ViewLabel\"))")
    private WebElement viewDropDown;

    protected ActivityScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps Disclosures link.
     */
    public void tapDisclosuresLink() {
        getDriver().scrollTo(disclosures, Direction.UP).click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(pendingActivity, DEFAULT_WAIT_TIMEOUT,
                "Activity Screen is not displayed.");
    }

    public void waitForPendingActivityToLoad() {
        getDriver().waitUntilClickable(viewDropDown, DEFAULT_WAIT_TIMEOUT,
                "Pending Activity is not loaded.");
    }

    public void tapOnPendingActivity() {
        pendingActivity.click();
    }

}
