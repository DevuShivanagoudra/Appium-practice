package mobile.screens.analysis.allocation.description;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class AllocationDescriptionScreenAndroid extends
        AllocationDescriptionScreenBase<AndroidCustomDriver> {

    final String childLocator = "new UiSelector().className(\"android.widget.TextView\")";

    public AllocationDescriptionScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    /**
     * Fetches Description text.
     *
     * @return
     */
    public List<String> getDescriptionTexts() {
        List<WebElement> elements = getDriver().findAll(getDescriptionText(),
                AppiumBy.androidUIAutomator(childLocator));
        return elements.stream()
                .map(x -> x.getText())
                .collect(Collectors.toList());
    }
}
