package mobile.screens.analysis.allocation.disclosures;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class AllocationDisclosuresScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Done\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-IconButton\")")
    private WebElement closeButton;


    protected AllocationDisclosuresScreenBase(final D driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(closeButton, MAXIMUM_WAIT_TIMEOUT,
                "Allocation Disclosures Screen is not displayed.");
    }
}
