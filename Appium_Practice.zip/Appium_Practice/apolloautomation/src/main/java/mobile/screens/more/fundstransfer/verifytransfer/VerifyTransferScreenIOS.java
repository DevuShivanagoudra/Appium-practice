package mobile.screens.more.fundstransfer.verifytransfer;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class VerifyTransferScreenIOS extends
        VerifyTransferScreenBase<IOSCustomDriver> {

    public VerifyTransferScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
