package mobile.screens.analysis.reports;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class ReportsScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Filter\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Filter\")")
    private WebElement filter;

    protected ReportsScreenBase(final D driver) {
        super(driver);
    }

    public void tapFilter() {
        filter.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(filter, MAXIMUM_WAIT_TIMEOUT,
                "Reports Screen is not displayed.");
    }
}
