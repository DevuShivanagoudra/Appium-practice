package mobile.screens.alerts;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

import static io.appium.java_client.pagefactory.LocatorGroupStrategy.ALL_POSSIBLE;

public abstract class AlertDialogBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeAlert/**/XCUIElementTypeStaticText[1]")
    @AndroidFindBy(id = "android:id/alertTitle")
    public WebElement alertTitle;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeAlert")
    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Do you want to continue?\")")
    private WebElement alert;

    @HowToUseLocators(androidAutomation = ALL_POSSIBLE)
    @AndroidFindBy(id = "android:id/message")
    @AndroidFindBy(uiAutomator =
            "new UiSelector().className(\"androidx.appcompat.widget.LinearLayoutCompat\")" +
                    ".childSelector(new UiSelector().className(\"mobile.android.widget.TextView\"))")
    private WebElement alertMessage;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"OK\"`]")
    @AndroidFindBy(id = "android:id/button1")
    private WebElement accept;

    @AndroidFindBy(id = "android:id/button2")
    private WebElement cancel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeAlert/**/XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\")")
    private List<WebElement> alertOptions;

    protected AlertDialogBase(D driver) {
        super(driver);
    }

    protected WebElement getAlertDialog() {
        return alert;
    }

    public boolean isAlertDisplayed() {
        return getDriver().isElementVisible(alert);
    }

    public void accept() {
        accept.click();
    }

    public void dismiss() {
        cancel.click();
    }

    public String getAlertMessage() {
        return alertMessage.getText();
    }

    public String getAlertTitle() {
        return alertTitle.getText();
    }

    public void tapOption(final String optionName) {
        alertOptions.stream()
                .filter(a -> a.getText().equals(optionName))
                .collect(Collectors.toList()).get(0).click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(alertTitle, "Alert is not displayed.");
    }
}
