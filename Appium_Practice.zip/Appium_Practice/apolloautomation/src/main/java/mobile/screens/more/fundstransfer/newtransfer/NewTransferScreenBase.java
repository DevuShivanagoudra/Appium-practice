package mobile.screens.more.fundstransfer.newtransfer;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class NewTransferScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name = 'From']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text = 'From']/following-sibling::android.widget.TextView")
    private WebElement fromSelectable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"To\"`]")
    @AndroidFindBy(xpath = "//*[@text = 'To']/following-sibling::android.widget.TextView")
    private WebElement toSelectable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Next\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Next\")")
    private WebElement nextButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Date Picker\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Transfer Date\")")
    private WebElement transferDate;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Amount\")")
    private WebElement amount;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Why Don’t I See All My Accounts?\")")
    private WebElement dontSeeAccounts;

    protected NewTransferScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Select 'From' Account from Accounts list.
     *
     * @param accountName String
     */
    protected abstract void selectAccount(final String accountName);

    /**
     * Enters amount in the textfield.
     *
     * @param amount double
     */
    protected abstract void enterAmount(final double amount);

    /**
     * Taps on 'Next' button.
     */
    public void tapNext() {
        getDriver().scrollTo(nextButton).click();
    }

    /**
     * Taps on 'From' selectable.
     */
    public void tapFromSelectable() {
        getDriver().waitUntilClickable(fromSelectable).click();
    }

    /**
     * Taps on 'To' selectable.
     */
    public void tapToSelectable() {
        toSelectable.click();
    }

    /**
     * Taps on the link "Why Don't I see All My Accounts.".
     */
    public void tapDontSeeAccounts() {
        dontSeeAccounts.click();
    }

    /**
     * Waits for 'Transfer Date' to load.
     */
    public void waitForTransferDateToLoad() {
        getDriver().waitUntilVisible(transferDate, MAXIMUM_WAIT_TIMEOUT,
                "Transfer Date is not displayed yet.");
    }

    @SneakyThrows
    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(fromSelectable, MAXIMUM_WAIT_TIMEOUT,
                "Funds Transfer Screen is not displayed.");
        //TODO: To be reviewed on later builds.
        Thread.sleep(10000);
    }
}
