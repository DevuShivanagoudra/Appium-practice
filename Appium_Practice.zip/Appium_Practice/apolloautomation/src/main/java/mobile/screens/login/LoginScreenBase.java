package mobile.screens.login;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static io.appium.java_client.pagefactory.LocatorGroupStrategy.ALL_POSSIBLE;
import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class LoginScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @HowToUseLocators(iOSXCUITAutomation = ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther[1]/**/XCUIElementTypeSecureTextField")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther[1]/**/XCUIElementTypeTextField")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSecureTextField[`label == \"Username\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"userName\")")
    private WebElement username;

    @HowToUseLocators(iOSXCUITAutomation = ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther[2]/**/XCUIElementTypeSecureTextField")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther[2]/**/XCUIElementTypeTextField")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSecureTextField[`label == \"Password\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"password\")")
    private WebElement password;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSwitch[`label == \"Remember Username\"`]/XCUIElementTypeSwitch")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"rememberUsernameSwitch\")")
    private WebElement rememberUsername;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Sign In\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"signIn\").childSelector(new UiSelector().className(\"android.widget.Button\"))")
    private WebElement signIn;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Sign In Help\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Sign In Help\")")
    private WebElement signInHelp;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/**/XCUIElementTypeButton[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"userNameIconButton\")")
    private WebElement showIconUsername;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/**/XCUIElementTypeButton[2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"passwordIconButton\")")
    private WebElement showIconPassword;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Forgot Username\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"forgotUserNameText\")")
    private WebElement forgotUsername;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Forgot Password\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"forgotPasswordText\")")
    private WebElement forgotPassword;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Disclosures\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"disclosures\")")
    private WebElement disclosuresButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Disclosures\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textStartsWith(\"v 4.\")")
    private WebElement build;

    protected LoginScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Sets RememberUserName Toggle.
     *
     * @param toggleState boolean
     */
    protected abstract void setRememberUserName(final boolean toggleState);

    /**
     * Fetches RememberUserName Toggle state.
     *
     * @return
     */
    protected abstract boolean getRememberUserNameState();

    /**
     * Taps on Forgotusername button
     */
    public void tapForgotUsername() {
        getDriver().tap(forgotUsername);
    }

    /**
     * Taps on Forgotpassword button
     */
    public void tapForgotPassword() {
        getDriver().tap(forgotPassword);
    }

    /**
     * Taps on Forgotpassword button
     */
    public void tapSigninHelp() {
        getDriver().tap(signInHelp);
    }

    /**
     * Fill in Username.
     *
     * @param username User ID
     */
    protected abstract void fillUsername(final String username);

    /**
     * Fill in Username.
     *
     * @param password User ID
     */
    protected abstract void fillPassword(final String password);

    /**
     * Taps on Username's show Hide icon.
     */
    public void tapShowHideIconUsername() {
        showIconUsername.click();
    }

    /**
     * Taps on Username's show Hide icon.
     */
    public void tapShowHideIconPassword() {
        showIconPassword.click();
    }

    /**
     * Taps on Disclosures button
     */
    public void tapDisclosures() {
        getDriver().tap(disclosuresButton);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(signIn, MAXIMUM_WAIT_TIMEOUT,
                "Login Screen is not displayed.");
    }
}
