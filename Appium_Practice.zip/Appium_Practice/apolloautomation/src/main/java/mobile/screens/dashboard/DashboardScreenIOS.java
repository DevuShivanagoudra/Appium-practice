package mobile.screens.dashboard;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

@Slf4j
@Getter
public class DashboardScreenIOS extends DashboardScreenBase<IOSCustomDriver> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeCell[`label BEGINSWITH[cd] \"Net Balance\"`]/**/XCUIElementTypeStaticText[2]")
    private WebElement balance;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeCell[`label BEGINSWITH[cd] \"Net Balance\"`]/**/XCUIElementTypeStaticText[3]")
    private WebElement dateUpdated;

    public DashboardScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    public void verifyWidgetsWhenDashboardCustomised() {
        getDriver().scrollTo(getMyHoldingsCheckbox(), Direction.DOWN, 3);
        if (getMyHoldingsCheckbox().getAttribute("value").equals("Checked checkbox")) {
            getMyHoldingsCheckbox().click();
        }
        getCustomiseDashboardDoneButton().click();
        Assert.assertFalse(getDriver().isElementVisible(getMyHoldingsLabel()), "My Holdings label is visible.");
        getDriver().scrollTo(getCustomize()).click();

        if (getMyHoldingsCheckbox().getAttribute("value").equals("Unchecked checkbox")) {
            getMyHoldingsCheckbox().click();
        }
        getCustomiseDashboardDoneButton().click();
        Assert.assertTrue(getDriver().isElementVisible(getMyHoldingsLabel()), "My Holdings label is not visible.");
    }
}
