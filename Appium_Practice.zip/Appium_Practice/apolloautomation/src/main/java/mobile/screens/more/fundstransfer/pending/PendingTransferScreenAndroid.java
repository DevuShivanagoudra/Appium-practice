package mobile.screens.more.fundstransfer.pending;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class PendingTransferScreenAndroid extends
        PendingTransferScreenBase<AndroidCustomDriver> {

    private static final String ACCOUNT_LOCATOR = "new UiSelector().text(\"%s\")";

    public PendingTransferScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
