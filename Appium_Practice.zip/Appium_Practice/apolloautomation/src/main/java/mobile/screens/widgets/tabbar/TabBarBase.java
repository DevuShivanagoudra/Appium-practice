package mobile.screens.widgets.tabbar;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.common.constants.TabBarOption;
import org.openqa.selenium.WebElement;

import java.util.List;

@Slf4j
@Getter
public abstract class TabBarBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTabBar/**/XCUIElementTypeButton")
    @AndroidFindBy(xpath = "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[3]//android.widget.TextView")
    private List<WebElement> buttons;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTabBar/**/XCUIElementTypeButton[`value == \"1\"`]")
    @AndroidFindBy(xpath = "//*[@focused = 'true'")
    private WebElement selectedTabBar;

    protected TabBarBase(
            D driver) {
        super(driver);
    }

    /**
     * Fetches selected TabBar option.
     *
     * @return TabBarOption
     */
    public TabBarOption getSelectedTabBar() {
        return TabBarOption.fromValue(selectedTabBar.getAttribute("name"));
    }

    /**
     * Checks Whether a TabBar option is selected.
     *
     * @param name TabBarOption
     * @return boolean
     */
    public boolean isSelectedTabBar(TabBarOption name) {
        return getSelectedTabBar().equals(name);
    }

    /**
     * Taps on a TabBar Option.
     *
     * @param option
     */
    public void tap(TabBarOption option) {
        getOption(option).click();
    }

    /**
     * Fetches a TabBar option.
     *
     * @param option Mobile Element
     * @return
     */
    protected abstract WebElement getOption(TabBarOption option);

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(buttons.get(0), "Tab bar is not loaded correctly.");
    }
}
