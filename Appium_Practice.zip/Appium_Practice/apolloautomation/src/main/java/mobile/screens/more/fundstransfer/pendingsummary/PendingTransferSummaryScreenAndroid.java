package mobile.screens.more.fundstransfer.pendingsummary;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class PendingTransferSummaryScreenAndroid extends
        PendingTransferSummaryScreenBase<AndroidCustomDriver> {

    private static final String ACCOUNT_LOCATOR = "new UiSelector().text(\"%s\")";

    public PendingTransferSummaryScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
