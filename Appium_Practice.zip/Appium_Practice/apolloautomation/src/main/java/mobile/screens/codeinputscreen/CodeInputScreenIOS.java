package mobile.screens.codeinputscreen;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import org.openqa.selenium.WebElement;

@Slf4j
@Getter
public class CodeInputScreenIOS extends CodeInputScreenBase<IOSCustomDriver> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Please enter a valid code.\"`]")
    private WebElement errorMessage;

    public CodeInputScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void submitCode(final String code) {
        CommonUtils.replaceText(getDriver(), getCodeInputEditable(), code);
        getSubmitButton().click();
    }
}
