package mobile.screens.more.accountservices;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class AccountServicesScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Password and Security\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Password and Security\")")
    private WebElement passwordAndSecurity;

    protected AccountServicesScreenBase(D driver) {
        super(driver);
    }

    /**
     * Taps on the Service name.
     *
     * @param serviceName String
     */
    public abstract void tapService(final String serviceName);

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(passwordAndSecurity, DEFAULT_WAIT_TIMEOUT,
                "Account Services Screen is not displayed.");
    }
}
