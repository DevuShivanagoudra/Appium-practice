package mobile.screens.secretquestion;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;

import static io.appium.java_client.pagefactory.LocatorGroupStrategy.ALL_POSSIBLE;
import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class SecretQuestionScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @HowToUseLocators(iOSXCUITAutomation = ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSecureTextField[`name == \"Answer - SecureField\"`]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`name CONTAINS 'key: \"Answer\"'`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Answer\")")
    private WebElement secretAnswerEditable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSwitch[`label == \"Trust this device\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Switch\")")
    private WebElement rememberOnDevice;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Submit\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"submitChallenge\")")
    private WebElement submitButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"The information you\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TextError\")")
    private WebElement errorText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Security Verification\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Security Verification\")")
    private WebElement securityVerification;

    protected SecretQuestionScreenBase(final D driver) {
        super(driver);
    }

    protected abstract void submitSecretAnswer(final String secretAnswer, final Toggle state);

    protected abstract void setRememberOnDeviceToggle(final boolean toggleState);

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(securityVerification, MAXIMUM_WAIT_TIMEOUT,
                "Challenge Screen is not displayed.");
    }
}
