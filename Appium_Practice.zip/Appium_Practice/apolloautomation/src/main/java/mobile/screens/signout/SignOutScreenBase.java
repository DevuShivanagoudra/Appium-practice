package mobile.screens.signout;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class SignOutScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {
    protected SignOutScreenBase(D driver) {
        super(driver);
    }

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Sign Out\"`]")
    @AndroidFindBy(uiAutomator = "")
    private WebElement signOutButton;

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(signOutButton, MAXIMUM_WAIT_TIMEOUT,
                "Sign Out button is not displayed.");
    }
}
