package mobile.screens.analysis.filter;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;
import java.util.stream.Collectors;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class AnalysisFilterScreenIOS extends AnalysisFilterScreenBase<IOSCustomDriver> {

    private static final String ACCOUNTSELECTED_ICON_LOCATOR = "**/XCUIElementTypeScrollView[1]/**/XCUIElementTypeOther[`label == \"%s\"`]/XCUIElementTypeImage";
    private static final String GROUPSELECTED_ICON_LOCATOR = "**/XCUIElementTypeScrollView[1]/**/XCUIElementTypeStaticText[`label == \"%s\"`]/XCUIElementTypeImage";
    private static final String ACCOUNTNAMES_LOCATOR = "**/XCUIElementTypeScrollView[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText";
    private static final String ACCOUNTNAME_LOCATOR = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";

    //FIXME: Hardcoded iosclasschain locator to be fixed after implementation of tags.(TASK 1379873)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView[1]/**/XCUIElementTypeStaticText")
    private List<WebElement> accounts;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText")
    private List<WebElement> accountsList;

    @HowToUseLocators(iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cancel\"`]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Back\"`]")
    private WebElement backButton;

    public AnalysisFilterScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapBack() {
        backButton.click();
    }

    /**
     * Fetches Account Names.
     *
     * @return List of String
     */
    public List<String> getAccountNames() {
        List<String> accountNames = accountsList
                .stream()
                .map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
        accountNames.removeAll(getAccountGroupsNames());
        return accountNames
                .stream()
                .map(x -> x.split(" xxx")[0])
                .collect(Collectors.toList());
    }

    @Override
    public WebElement getAccountSelectedIcon(final String accountName) {
        return getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(ACCOUNTSELECTED_ICON_LOCATOR, accountName)));
    }

    @Override
    public void selectDeselectAccount(final String accountName, final boolean state) {
        int i = 0;
        while ((state && !getDriver().waitUntilVisible(
                        AppiumBy.iOSClassChain(String.format(ACCOUNTSELECTED_ICON_LOCATOR, accountName)))
                .getAttribute("label").equalsIgnoreCase("Selected") ||
                !state && !getDriver().waitUntilVisible(
                                AppiumBy.iOSClassChain(String.format(ACCOUNTSELECTED_ICON_LOCATOR, accountName)))
                        .getAttribute("label").equalsIgnoreCase("Square")) && i < 2) {
            getDriver().waitUntilVisible(
                    AppiumBy.iOSClassChain(String.format(ACCOUNTNAME_LOCATOR, accountName))).click();
            i++;
        }
    }

    public void toggleGroup(final String groupName, final boolean state) {
        int i = 0;
        while ((state && !getDriver().waitUntilVisible(
                        AppiumBy.iOSClassChain(String.format(GROUPSELECTED_ICON_LOCATOR, groupName)))
                .getAttribute("label").equalsIgnoreCase("Selected") ||
                !state && !getDriver().waitUntilVisible(
                                AppiumBy.iOSClassChain(String.format(GROUPSELECTED_ICON_LOCATOR, groupName)))
                        .getAttribute("label").equalsIgnoreCase("Square")) && i < 2) {
            getDriver().waitUntilVisible(
                    AppiumBy.iOSClassChain(String.format(ACCOUNTNAME_LOCATOR, groupName))).click();
            i++;
        }
    }

    @Override
    public boolean isAccountSelectedIconVisible(final String accountName) {
        return getDriver().waitUntilVisible(AppiumBy.iOSClassChain(
                        String.format(ACCOUNTSELECTED_ICON_LOCATOR, accountName))).getAttribute("label")
                .equalsIgnoreCase("Selected");
    }

    @Override
    public void waitUntilAccountsLoaded() {
        getDriver().waitUntilCondition(
                ExpectedConditions
                        .numberOfElementsToBeMoreThan(AppiumBy.iOSClassChain(ACCOUNTNAMES_LOCATOR), 3));
        getDriver().waitUntilClickable(MAXIMUM_WAIT_TIMEOUT,
                AppiumBy.iOSClassChain(String.format(GROUPSELECTED_ICON_LOCATOR, "Assets")),
                "Group Icon is not Clickable.");
    }
}
