package mobile.screens.analysis;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.common.exceptions.InvalidOptionException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class AnalysisScreenIOS extends AnalysisScreenBase<IOSCustomDriver> {

    private static final String SELECT_OPTION = "**/XCUIElementTypeCell/XCUIElementTypeButton[`label BEGINSWITH[cd] \"%s\"`]";
    private static final String CUSTOM_MONTH = "**/XCUIElementTypePickerWheel[`value == \"%s\"`]";
    private static final String YEAR_LOCATOR = "**/XCUIElementTypeText[`label == \"%s\"`]";

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypePicker[`label == \"Months\"`]/XCUIElementTypePickerWheel")
    private WebElement monthPickerWheel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypePicker[`label == \"Years\"`]/XCUIElementTypePickerWheel")
    private WebElement yearPickerWheel;

    public AnalysisScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }


    @Override
    public void selectAssetGrowthEndDate(final String option) {
        tapAssetEndDateButton();
        getDriver()
                .waitUntilVisible(AppiumBy.iOSClassChain(String.format(SELECT_OPTION, option)))
                .click();
    }

    @Override
    public void selectBeginDate(final String option) {
        tapValueBeginDateButton();
        getDriver()
                .waitUntilVisible(AppiumBy.iOSClassChain(String.format(SELECT_OPTION, option)))
                .click();
    }

    @Override
    public void selectValueOverEndDate(final String option) {
        getValueOverTimeEndDateDropDownButton().click();
        WebElement element = getDriver()
                .waitUntilVisible(AppiumBy.iOSClassChain(String.format(SELECT_OPTION, option)));
        getDriver().tap(element);
    }
/*
    public WebElement getSelectedMonthInCalendar() {
        return CommonUtils.getSiblingUsingxPath(getYear_Calendar(), 1);
    }*/

    @Override
    public void selectCustomBeginDate(final String year, final String month) {
        selectBeginDate("Custom");
        selectCustomDate(year, month);
        tapCustomOKButton();
        getDriver().waitUntilClickable(getValueOverTimeBeginDateButton());
    }

    @Override
    public void selectCustomDate(final String year, final String month) {
        getDriver().waitUntilClickable(getOkButton());
        while (!monthPickerWheel.getText().equals(month)) {
            monthPickerWheel.sendKeys(month);
        }
        int yearCount = 0;
        getDriver().waitUntilClickable(yearPickerWheel);
        while (!yearPickerWheel.getText().equals(year) && yearCount < 20) {
            yearPickerWheel.sendKeys(year);
            yearCount++;
        }
        if (!yearPickerWheel.getText().equals(year)) {
            throw new InvalidOptionException(
                    String.format("year %s is not available to select", year));
        }
    }

    @Override
    public boolean isFutureDateAvailable(final String year, final String month) {
        try {
            selectCustomDate(year, month);
            return true;
        } catch (InvalidOptionException e) {
            return false;
        }
    }

    @Override
    public void selectAssetGrowthCustomEndDate(final String year, final String month) {
        selectAssetGrowthEndDate("Custom");
        selectCustomDate(year, month);
        tapCustomOKButton();
        getDriver().waitUntilClickable(getEndDateButton());
    }

    @Override
    public void selectValueOverCustomEndDate(final String year, final String month) {
        selectValueOverEndDate("Custom");
        selectCustomDate(year, month);
        tapCustomOKButton();
        getDriver().waitUntilClickable(getEndDateButton());
    }

    @Override
    public void selectFees(String option) {
        tapFeesButton();
        getDriver()
                .waitUntilVisible(AppiumBy.iOSClassChain(String.format(SELECT_OPTION, option)))
                .click();
    }

    @Override
    public void tapCustomDate(final String Month) {
        getDriver()
                .scrollTo(AppiumBy.iOSClassChain(String.format(CUSTOM_MONTH, Month)),
                        Direction.DOWN_SMALL)
                .click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT,
                ExpectedConditions.or(ExpectedConditions.elementToBeClickable(getPortfolioValue()),
                        ExpectedConditions.visibilityOf(getNoResults())), "Analysis Screen not loaded.");
    }
}
