package mobile.screens.devicehome;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.appium.Utils;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.common.exceptions.AppNotFoundException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class DeviceHomeScreenIOS extends DeviceHomeScreenBase<IOSCustomDriver> {

    private final static String APP_LOCATOR = "**/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"%s\"`]";
    public static String BUILD_VERSION = null;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeIcon[`label == \"TestFlight\"`]")
    private WebElement testFlight;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Apps\"`]")
    private WebElement apps;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"Version \"`]")
    private WebElement appView;

    public DeviceHomeScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void launchApp() {
        final String server = Utils.getProperty("appium.server");
        final String appName = String.format("Client Access %s", server);
        if (getDriver().isElementVisible(apps)) {
            apps.click();
        }
        try {
            getDriver().waitUntilVisible(
                    AppiumBy.iOSClassChain(String.format(APP_LOCATOR, appName))).click();
        } catch (TimeoutException e) {
            throw new AppNotFoundException(
                    String.format("The required app '%s' is not found", appName));
        }

        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(update), ExpectedConditions.visibilityOf(open),
                                ExpectedConditions.visibilityOf(install)),
                "Update/Open buttons not displayed.");
        if (getDriver().isElementVisible(update)) {
            update.click();
            getDriver().waitUntilVisible(open, MAXIMUM_WAIT_TIMEOUT,
                    "Open button is not displayed.");
        }
        if (getDriver().isElementVisible(install)) {
            install.click();
            getDriver().waitUntilVisible(open, MAXIMUM_WAIT_TIMEOUT,
                    "Open button is not displayed.");
        }
        BUILD_VERSION = appView.getText();
        open.click();
    }
}
