package mobile.screens.f5access;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class F5AccessScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Status\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"STATUS\")")
    private WebElement statusLabel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`value BEGINSWITH[cd] \"Connected: \"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Connected\")")
    private WebElement connectionStatus;

    protected F5AccessScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Creates F5 Access connection if not already connected.
     */
    public abstract void getConnection();

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(statusLabel, MAXIMUM_WAIT_TIMEOUT,
                "Home Screen is not displayed.");
    }
}
