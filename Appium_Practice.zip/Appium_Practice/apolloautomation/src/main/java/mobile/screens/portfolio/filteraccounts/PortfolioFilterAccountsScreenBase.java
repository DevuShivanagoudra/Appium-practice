package mobile.screens.portfolio.filteraccounts;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

@Slf4j
@Getter
public abstract class PortfolioFilterAccountsScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-ActionButton-Done\")")
    private WebElement doneButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeSwitch[@name=\"allAccountsToggle\"]/XCUIElementTypeSwitch")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"All Accounts-switch\")")
    private WebElement allAccountsToggleButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Please select at least one (1) account\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Please select at least one (1) account\")")
    private WebElement noAccountsSelectedErrorMessage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Collapse\"]//following-sibling::XCUIElementTypeOther")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(2)")
    private WebElement firstAccountRecord;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"Collapse\"]//following-sibling::XCUIElementTypeOther)[2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(3)")
    private WebElement secondAccountRecord;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Expand\"`]")
    @AndroidFindBy(xpath = "//*")
    private WebElement expandAssetsIcon;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Back\"`]")
    @AndroidFindBy(xpath = "//*")
    private WebElement backButton;

    protected PortfolioFilterAccountsScreenBase(final D driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(allAccountsToggleButton, 5, "Accounts Toggle button is not visible.");
    }
}
