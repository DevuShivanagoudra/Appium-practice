package mobile.screens.homescreen;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class HomeScreenIOS extends HomeScreenBase<IOSCustomDriver> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Next\"`]")
    private WebElement nextButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Start Testing\"`]")
    private WebElement startTesting;

    public HomeScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    public void startTesting() {
        if (getDriver().isElementVisible(nextButton)) {
            nextButton.click();
            getDriver().waitUntilVisible(startTesting).click();
        }
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(nextButton, MAXIMUM_WAIT_TIMEOUT,
                "Login Screen is not displayed.");
    }
}
