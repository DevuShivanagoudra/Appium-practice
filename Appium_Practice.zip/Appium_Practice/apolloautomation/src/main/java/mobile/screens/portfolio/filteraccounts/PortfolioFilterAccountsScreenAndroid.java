package mobile.screens.portfolio.filteraccounts;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class PortfolioFilterAccountsScreenAndroid extends PortfolioFilterAccountsScreenBase
        <AndroidCustomDriver> {

    public PortfolioFilterAccountsScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    public void verifyWhenNoAccountIsSelected() {
        Assert.assertEquals(getDoneButton().getAttribute("enabled"), "false", "Toggle button is enabled.");
        getAllAccountsToggleButton().click();
        Assert.assertTrue(getDriver().waitUntilVisible(getNoAccountsSelectedErrorMessage(), MAXIMUM_WAIT_TIMEOUT, "Error Message: 'Please select at least one (1) account' is not present").isDisplayed());
        getFirstAccountRecord().click();
        Assert.assertEquals(getDoneButton().getAttribute("enabled"), "false", "Toggle button is not enabled.");
    }
}
