package mobile.screens.more.vault.vaultfolderinformation;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class VaultFolderInformationScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTable/XCUIElementTypeCell[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"clickSurface\").instance(0)")
    private WebElement clickSurface;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTable/XCUIElementTypeCell[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-Title-Folder Information\")")
    private WebElement title;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Create New Folder\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Create New Folder\")")
    private WebElement createNewFolder;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther/XCUIElementTypeTextView[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Folder Name-EditField\")")
    private WebElement folderName;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cancel\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-IconButton\")")
    private WebElement backButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Delete Folder\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(1)")
    private WebElement deleteButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Edit\"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Edit\").instance(0)")
    private WebElement editFolder;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Edit\"`][2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Edit\").instance(1)")
    private WebElement editDescription;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Properties\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Properties\")")
    private WebElement propertiesLabel;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Folder Name\"]/following-sibling::*[2]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'Folder Name']/following-sibling::*[1]")
    private WebElement folderNameValue;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Description\"]/following-sibling::*[2]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'Description']/following-sibling::*[1]")
    private WebElement descriptionValue;

    protected VaultFolderInformationScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on Save Button.
     */
    public void tapDeleteButton() {
        deleteButton.click();
    }

    /**
     * Taps on Cancel button.
     */
    public void tapBackButton() {
        backButton.click();
    }

    /**
     * Taps on Edit Folder button.
     */
    public void tapEditFolder() {
        getDriver().waitUntilClickable(editFolder).click();
    }

    /**
     * Taps on Description button.
     */
    public void tapEditDescription() {
        getDriver().waitUntilClickable(editDescription).click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(editDescription, MAXIMUM_WAIT_TIMEOUT,
                "Folder Information Screen is not displayed.");
    }
}
