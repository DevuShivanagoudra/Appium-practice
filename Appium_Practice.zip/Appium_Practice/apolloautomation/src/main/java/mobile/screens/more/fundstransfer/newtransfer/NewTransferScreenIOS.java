package mobile.screens.more.fundstransfer.newtransfer;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class NewTransferScreenIOS extends
        NewTransferScreenBase<IOSCustomDriver> {

    private static final String ACCOUNT_LOCATOR = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";

    public NewTransferScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void selectAccount(final String accountName) {
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(ACCOUNT_LOCATOR, accountName))).click();
    }

    @Override
    public void enterAmount(final double amount) {
        getDriver().replaceText(getAmount(), String.valueOf(amount));
    }
}
