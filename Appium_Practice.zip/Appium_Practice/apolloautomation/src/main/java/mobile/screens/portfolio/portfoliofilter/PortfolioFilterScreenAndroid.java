package mobile.screens.portfolio.portfoliofilter;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

public class PortfolioFilterScreenAndroid extends PortfolioFilterScreenBase
        <AndroidCustomDriver> {

    private static final String GAINLOSS_LOCATOR = "**/XCUIElementTypeButton[`label == \"%s\"`]";
    private static final String SELECTED_LOCATOR = "new UiSelector().text(\"%s\").fromParent(new UiSelector().className(\"android.view.View\"))";
    private static final String ACCOUNT_LOCATOR = "new UiSelector().text(\"%s\")";
    private static final String YEAR_LOCATOR = ACCOUNT_LOCATOR;
    private static final String ACCOUNTSELECTEDICON_LOCATOR = "new UiSelector().description(\"%s\")";
    private static final String SECURITY_GROUP_EXPANDCOLLAPSE_ICON = "new UiSelector().text(\"%s\").fromParent(new UiSelector().descriptionStartsWith(\"Expandable Arrow\"))";

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").fromParent(new UiSelector().className(\"android.widget.TextView\"))")
    private List<WebElement> accountsList;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"OK\")")
    private WebElement okButton;

    @AndroidFindBy(xpath = "(//*[@resource-id='ChipAll Accounts']/following-sibling::android.view.View)[1]")
    private WebElement dateFilterPill;

    public PortfolioFilterScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapAllSecurities(final Toggle state) {
        getDriver().scrollTo(getAllSecuritiesToggle());
        getDriver().waitUntilClickable(getAllSecuritiesToggle());
        final boolean isSecuritiesOff =
                state.getBoolValue() && !getDriver().isElementChecked(getAllSecuritiesToggle());
        final boolean isSecuritiesOn =
                !state.getBoolValue() && getDriver().isElementChecked(getAllSecuritiesToggle());
        if (isSecuritiesOff || isSecuritiesOn) {
            getAllSecuritiesToggle().click();
        }
        getDriver().waitUntilClickable(getAllSecuritiesToggle());
        getDriver().swipeScreen(Direction.UP);
    }

    @Override
    public List<String> fetchAccounts() {
        List<String> accounts = accountsList.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        accounts.removeAll(getAccountGroupsNames());
        return accounts;
    }

    @Override
    public void deSelectAllAccounts() {
        List<String> accounts = accountsList.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        for (String account : accounts) {
            if (getDriver().isElementVisible(
                    AppiumBy.androidUIAutomator(String.format(SELECTED_LOCATOR, account)))) {
                getDriver().waitUntilVisible(
                        AppiumBy.androidUIAutomator(String.format(ACCOUNT_LOCATOR, account))).click();
            }
        }
    }

    @Override
    public void verifyAccountsSelected() {
        List<String> accounts = accountsList.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        for (String account : accounts) {
            Assert.assertTrue(getDriver().isElementVisible(
                            AppiumBy.androidUIAutomator(String.format(SELECTED_LOCATOR, account))),
                    String.format("Account %s is not selected.", account));
        }
    }

    @Override
    public List<String> getSecurityGroupsList() {
        return getSecurityGroups().stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    @Override
    protected void selectGainLossType(String viewOption) {
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(GAINLOSS_LOCATOR, viewOption))).click();
    }

    public void selectDeselectAccount(final String accountName, final boolean state) {
        if (state && !getDriver().isElementVisible(
                AppiumBy.androidUIAutomator(String.format(SELECTED_LOCATOR, accountName))) ||
                !state && getDriver().isElementVisible(
                        AppiumBy.androidUIAutomator(String.format(SELECTED_LOCATOR, accountName)))) {
            getDriver().waitUntilVisible(
                    AppiumBy.androidUIAutomator(String.format(ACCOUNT_LOCATOR, accountName))).click();
        }
    }

    public void verifySecurityGroupNotDisplayed(final String securityGroup) {
        List<String> Securities = getSecurityGroups().stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        Assert.assertFalse(Securities.contains(securityGroup),
                String.format("Security Group %s is displayed.", securityGroup));
    }

    public void selectYear(final String year) {
        getDriver()
                .waitUntilVisible(AppiumBy.androidUIAutomator(String.format(YEAR_LOCATOR, year)))
                .click();
    }

    public void selectMonth(final String month) {
        getDriver()
                .waitUntilVisible(
                        AppiumBy.androidUIAutomator(String.format(YEAR_LOCATOR, month)))
                .click();
    }

    @Override
    public void selectClosingDate(final String year, final String month) {
        getClosingdateFromSelectable().click();
        getYearDropdown().click();
        selectYear(year);
        selectMonth(month);
        getDateSelectorOKButton().click();
    }

    public boolean isAccountSelected(final String accountName) {
        return getDriver().isElementVisible(
                AppiumBy.androidUIAutomator(String.format(ACCOUNTSELECTEDICON_LOCATOR, accountName)));
    }

    @Override
    public void expandCollapseSecurityGroup(String securityGroupName) {
        WebElement expandCollapseIcon = getDriver().waitUntilVisible(AppiumBy
                .androidUIAutomator(
                        String.format(SECURITY_GROUP_EXPANDCOLLAPSE_ICON, securityGroupName)));
        expandCollapseIcon.click();
        getDriver().waitUntilClickable(expandCollapseIcon);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(getGainLossSection(), MAXIMUM_WAIT_TIMEOUT,
                "Portfolio Filter screen not displayed.");
        getDriver().waitUntilVisible(getDoneButton(), MAXIMUM_WAIT_TIMEOUT,
                "Portfolio Filter screen not displayed.");
    }

    public void verifyDatesSelected() throws ParseException {
        getClosingdateFromSelectable().click();
        getFromDateSelectedFilterScreen().click();
        okButton.click();
        getClosingdateToSelectable().click();
        getToDateSelectedFilterScreen().click();
        okButton.click();
        final String fromDateValue = getClosingdateFromSelectable().getAttribute("content-desc").replace("From ", "");
        final String toDateValue = getClosingdateToSelectable().getAttribute("content-desc").replace("To ", "");
        DateFormat inputFormat = new SimpleDateFormat("MMM dd, yyyy");
        DateFormat outputFormat = new SimpleDateFormat("MMM dd");
        String fromDateFormatted = "";
        String toDateFormatted = "";
        Date fromDate = inputFormat.parse(fromDateValue);
        Date toDate = inputFormat.parse(toDateValue);
        fromDateFormatted = outputFormat.format(fromDate);
        toDateFormatted = outputFormat.format(toDate);
        getDoneButton().click();
        Assert.assertEquals(getDriver().waitUntilVisible(dateFilterPill).getAttribute("resource-id").trim().
                        replace("Chip", ""), fromDateFormatted + " – " + toDateFormatted,
                "Mismatch in the value for date in Filter pill and  Filters applied.");
    }
}
