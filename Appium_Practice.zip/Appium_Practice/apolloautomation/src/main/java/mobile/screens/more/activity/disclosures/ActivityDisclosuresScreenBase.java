package mobile.screens.more.activity.disclosures;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class ActivityDisclosuresScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name CONTAINS \"Raymond James & Associates\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.ScrollView\").childSelector(new UiSelector().className(\"android.view.View\"))")
    private WebElement disclosuresText;

    protected ActivityDisclosuresScreenBase(final D driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilPresent(disclosuresText, DEFAULT_WAIT_TIMEOUT);
    }
}
