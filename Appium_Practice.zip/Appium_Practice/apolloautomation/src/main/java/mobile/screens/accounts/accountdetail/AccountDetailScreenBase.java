package mobile.screens.accounts.accountdetail;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class AccountDetailScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeImage[`label == \"Edit Name\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Edit Name\")")
    private WebElement editButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`name == \"Account Name - TextField\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Account name-EditField\")")
    private WebElement accountNameEditable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Save\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Save\")")
    private WebElement saveButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cancel\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Cancel\")")
    private WebElement cancelButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Available Cash\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\".*-clickableRow.*\").instance(0)")
    private WebElement firstAccount;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeNavigationBar/**/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"TopBar-Title.*\")")
    private WebElement title;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"invalidText\")")
    private WebElement invalidText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"balance\")")
    private WebElement balanceLabel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Balance\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"balance\")")
    private WebElement balance;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Total Cash\")")
    private WebElement totalCashLabel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Total Cash\").fromParent(new UiSelector().resourceId(\"MoneyText\"))")
    private WebElement totalCashValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Available Cash\")")
    private WebElement availableCashLabel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Available Cash\").fromParent(new UiSelector().resourceId(\"MoneyText\"))")
    private WebElement availableCashValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Change Since Last Statement\")")
    private WebElement interestRateLabel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Percent\")")
    private WebElement interestRateValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Prior Statement\")")
    private WebElement priorStatementLabel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Prior Statement\").fromParent(new UiSelector().resourceId(\"MoneyText\"))")
    private WebElement priorStatementValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Prior Year End\")")
    private WebElement priorYearEndLabel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Prior Year End\").fromParent(new UiSelector().resourceId(\"MoneyText\"))")
    private WebElement priorYearEndValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Portfolio\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Portfolio-icon\")")
    private WebElement portfolioIcon;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Documents\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Documents-icon\")")
    private WebElement documentsIcon;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Back\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-IconButton\")")
    private WebElement back;

    protected AccountDetailScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on first Account in the list of accounts.
     */
    public abstract void tapFirstAccount();

    /**
     * Edits AccountName
     *
     * @param accountName String
     */
    public void editAccountName(final String accountName) {
        getDriver().enterText(accountNameEditable, accountName);
    }

    /**
     * Taps on Edit button.
     */
    public void tapEdit() {
        getDriver().waitUntilClickable(editButton).click();
    }

    /**
     * Taps on Save button.
     */
    public void tapSave() {
        getDriver().waitUntilClickable(saveButton).click();
    }

    /**
     * Taps on Cancel button.
     */
    public void tapCancel() {
        getDriver().waitUntilClickable(cancelButton).click();
    }

    public void tapDocumentsIcon() {
        documentsIcon.click();
    }

    public void tapPortfolioIcon() {
        portfolioIcon.click();
    }

    public void waitForEditWindowToLoad() {
        getDriver().waitUntilPresent(saveButton, MAXIMUM_WAIT_TIMEOUT);
    }

    public void tapBack() {
        back.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(editButton, MAXIMUM_WAIT_TIMEOUT,
                "Edit button is not clickable yet.");
    }

    /**
     * waits until Detail page for external accounts load.
     */
    public void waitForExternalAccountToLoad() {
        getDriver().waitUntilVisible(editButton, MAXIMUM_WAIT_TIMEOUT,
                "Edit button is not clickable yet.");
    }
}
