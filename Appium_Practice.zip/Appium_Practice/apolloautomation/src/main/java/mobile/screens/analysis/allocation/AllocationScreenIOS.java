package mobile.screens.analysis.allocation;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

@Slf4j
@Getter
public class AllocationScreenIOS extends AllocationScreenBase<IOSCustomDriver> {

    private static final String VIEW_TYPE = "**/XCUIElementTypeButton[`label ==  \"%s\"`]";

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label CONTAINS \"Allocation Type Picker\"`]/XCUIElementTypeStaticText")
    private WebElement allocationType;

    public AllocationScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void selectViewType(final String viewType) {
        getDriver().scrollTo(getViewType(), Direction.DOWN).click();
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(VIEW_TYPE, viewType))).click();
        getDriver().waitUntilClickable(getViewType());
    }
}
