package mobile.screens.more;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class MoreScreenAndroid extends
        MoreScreenBase<AndroidCustomDriver> {

    private static final String MORE_OPTION = "new UiSelector().text(\"%s\")";

    public MoreScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    /**
     * Checks whether an element has a attribute.
     *
     * @param element AndroidElement
     * @return boolean
     */
    private boolean hasAttribute(final WebElement element) {
        try {
            element.getAttribute("content-desc");
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public List<String> getTabBarNames() {
        List<String> tabBarNames = tabBarContainer.stream()
                .map(t -> t.getText())
                .filter(y -> !y.isEmpty())
                .collect(Collectors.toList());
        return tabBarNames;
    }

    @Override
    public void tapMoreOption(final String moreOption) {
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(MORE_OPTION, moreOption))).click();
    }
}
