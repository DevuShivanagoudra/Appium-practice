package mobile.screens.login;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.android.AndroidUtils;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;

@Slf4j
public class LoginScreenAndroid extends
        LoginScreenBase<AndroidCustomDriver> {

    private static final String ENVIRONMENT = "new UiSelector().text(\"%s\")";

    @HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Debug Settings\").fromParent(new UiSelector().className(\"android.widget.TextView\"))")
    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Select environment\").fromParent(new UiSelector().className(\"android.widget.TextView\"))")
    private WebElement environmentSelectable;

    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Select environment\")")
    private WebElement selectEnvironment;

    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Close Dialog\")")
    private WebElement cancel;

    public LoginScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void setRememberUserName(final boolean toggleState) {
        AndroidUtils.setCheckBox(getDriver(), getRememberUsername(), toggleState);
    }

    @Override
    protected boolean getRememberUserNameState() {
        return getDriver().isElementSelected(getRememberUsername());
    }

    /**
     * Login to ClientAccess.
     */
    public void signIn(final String username, final String password) {
        final String env = System.getProperty("appium.environment");
        getDriver().waitUntilVisible(environmentSelectable).click();
        if (getDriver().isElementVisible(selectEnvironment)) {
            getDriver().waitUntilClickable(selectEnvironment).click();
        }
        WebElement environment = getDriver()
                .waitUntilVisible(
                        AppiumBy.androidUIAutomator(String.format(ENVIRONMENT, env)));
        getDriver().waitUntilVisible(environment).click();
        getDriver().waitUntilClickable(cancel).click();
        getDriver().waitUntilClickable(getUsername()).clear();
        getUsername().sendKeys(username);
        getDriver().waitUntilClickable(getPassword()).sendKeys(password);
        getDriver().waitUntilClickable(getSignIn(), DEFAULT_WAIT_TIMEOUT,
                "Sign In button is not enabled").click();
    }

    public void fillUsername(final String username) {
        getUsername().clear();
        getUsername().sendKeys(username);
    }

    public void fillPassword(final String password) {
        getPassword().clear();
        getPassword().sendKeys(password);
    }
}
