package mobile.screens.more.fundstransfer.pendingsummary;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class PendingTransferSummaryScreenIOS extends
        PendingTransferSummaryScreenBase<IOSCustomDriver> {

    public PendingTransferSummaryScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
