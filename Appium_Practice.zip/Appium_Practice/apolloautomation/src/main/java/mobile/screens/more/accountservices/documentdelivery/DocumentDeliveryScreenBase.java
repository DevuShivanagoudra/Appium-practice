package mobile.screens.more.accountservices.documentdelivery;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;

import java.util.List;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class DocumentDeliveryScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"E-Delivery\"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\")")
    private WebElement eDeliveryOption;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Back\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(0)")
    private WebElement backButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Done\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(1)")
    private WebElement doneButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSwitch/XCUIElementTypeSwitch")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"E-Delivery for all documents-switch\")")
    private WebElement eDeliveryAllOptions;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeSwitch")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"E-Delivery for all documents-switch\")")
    private WebElement allDocumentsSwitch;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Paper\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(0)")
    private WebElement statementsPaper;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Statements, E-Delivery\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(1)")
    private WebElement statementsEDelivery;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Paper\"`][2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(2)")
    private WebElement tradeConfimationsPaper;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Trade Confirmations, E-Delivery\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(3)")
    private WebElement tradeConfirmationsEDelivery;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Account\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"ApolloTabRow\").childSelector(new UiSelector().resourceId(\"Account\"))")
    private WebElement accountsHeader;

    //FIXME:
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeButton")
    @AndroidFindBy(xpath = "//android.view.View[@resource-id = 'ApolloTabRow']/following-sibling::*//android.widget.TextView[1]")
    private List<WebElement> accounts;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"View Only Accounts\"]/following-sibling::*[1]//XCUIElementTypeStaticText[1]")
    @AndroidFindBy(xpath = "//*[@text = 'Investment Accounts']//following-sibling::android.widget.TextView")
    private List<WebElement> viewOnlyAccounts;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"View Only Accounts\"`]")
    @AndroidFindBy(xpath = "//android.widget.ScrollView/android.view.View/android.view.View[3]//android.widget.TextView[1]")
    private WebElement viewOnlyAccountsHeader;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Document Delivery Options\"`]")
    @AndroidFindBy(xpath = "//android.widget.ScrollView/android.view.View/android.view.View[3]//android.widget.TextView[1]")
    private WebElement documentDeliveryOptionsCopy;

    @HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Investment Accounts\" OR label == \"Bank Accounts\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Investment Accounts\")")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Bank Accounts\")")
    private WebElement accountList;

    protected DocumentDeliveryScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Tap Accounts Header.
     */
    public void tapAccountsHeader() {
        getDriver().waitUntilClickable(accountsHeader).click();
        getDriver().waitUntilVisible(accountList);
    }

    /**
     * Sets 'EDelivery  for all Options' Toggle.
     *
     * @param state Toggle
     */
    protected abstract void setEDeliveryToggle(final Toggle state);

    /**
     * Taps on account.
     *
     * @param name String
     */
    protected abstract void tapAccount(final String name);

    /**
     * Taps on account.
     *
     * @param name String
     */
    protected abstract void tapDocumentType(final String name);

    /**
     * Verifies whether account is visible.
     *
     * @param account String
     * @return boolean
     */
    protected abstract boolean isAccountVisible(final String account);

    /**
     * Taps Back button.
     */
    public void tapBack() {
        backButton.click();
    }

    /**
     * Taps Back button.
     */
    public void tapDone() {
        doneButton.click();
    }

    /**
     * Waits for Delivery delivery options to load.
     */
    public void waitForOptionsToLoad() {
        getDriver().scrollTo(accountsHeader, Direction.UP, 3);
    }

    /**
     * Waits for Accounts header to load.
     */
    public void waitForAccountsHeaderToLoad() {
        getDriver().waitUntilVisible(accountsHeader, MAXIMUM_WAIT_TIMEOUT,
                "Document delivery Options are not displayed.");
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(allDocumentsSwitch, MAXIMUM_WAIT_TIMEOUT,
                "Document Delivery screen is not displayed.");
    }
}
