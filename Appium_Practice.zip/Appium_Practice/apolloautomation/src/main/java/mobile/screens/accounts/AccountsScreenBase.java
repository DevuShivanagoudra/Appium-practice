package mobile.screens.accounts;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import org.openqa.selenium.WebElement;

@Slf4j
@Getter
public abstract class AccountsScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Accounts\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Accounts\")")
    private WebElement accountsHeader;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"balance\")")
    private WebElement balanceLabel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Account name is invalid\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"balanceText\")")
    private WebElement balance;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSegmentedControl/XCUIElementTypeButton[`label == \"All Accounts\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"primaryTabRow-tab-1\")")
    private WebElement allAccounts;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSegmentedControl/XCUIElementTypeButton[`label == \"Raymond James\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"primaryTabRow-tab-2\")")
    private WebElement raymondjamesAccounts;

    @HowToUseLocators(iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label BEGINSWITH[cd] \"Assets\"`]/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"Assets\"`]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTable/XCUIElementTypeOther")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"Assets.*expandableSurface\")")
    private WebElement assetsSection;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Liabilities\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"Liabilities.*expandableSurface\")")
    private WebElement liabilitiesSection;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Available Cash\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Available Cash\")")
    private WebElement availableCash;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label CONTAINS \", Balance,\"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\".*-clickableRow.*\").childSelector(new UiSelector().className(\"android.widget.TextView\")).instance(0)")
    private WebElement firstAccount;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label CONTAINS \", $\"`][3]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'Liabilities-expandableSurface']/following-sibling::*[@resource-id = 'groupTotalText']")
    private WebElement liabilitiesTotalText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Banking\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Banking\")")
    private WebElement externalAccount;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"View-Only Access\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"View-Only Access\")")
    private WebElement viewOnlyAccess;

    protected AccountsScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on first Account in the list of accounts.
     */
    public abstract void tapFirstAccount();

    /**
     * Taps 'All Accounts' tab.
     */
    public void tapAllAccounts() {
        allAccounts.click();
    }

    /**
     * Taps 'Raymond James' tab.
     */
    public void tapRaymondJamesAccounts() {
        raymondjamesAccounts.click();
    }

    /**
     * Taps on any Account in the list of accounts.
     */
    public abstract void tapAccount(final String accountName);

    /**
     * Taps on the Account name.
     *
     * @param accountName String
     */
    public abstract void selectAccount(String accountName);

    /**
     * verifies visibility of Authorized Representative Icon for Account names
     *
     * @param accountName
     */
    public abstract void verifyAuthorizedRepresentativeVisible(String accountName);

    @Override
    public void waitToLoad() {
        CommonUtils.scrollToElement(getDriver(), assetsSection, Direction.DOWN, 20);
    }
}
