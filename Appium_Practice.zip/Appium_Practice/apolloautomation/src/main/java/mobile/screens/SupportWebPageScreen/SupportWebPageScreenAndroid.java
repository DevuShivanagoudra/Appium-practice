package mobile.screens.SupportWebPageScreen;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SupportWebPageScreenAndroid extends
        SupportWebPageScreenBase<AndroidCustomDriver> {

    public SupportWebPageScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
