package mobile.screens.more.fundstransfer.pending;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

@Slf4j
@Getter
public abstract class PendingTransferScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label CONTAINS \"AM\" OR label CONTAINS \"PM\"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"clickSurface\").instance(0)")
    private WebElement pendingTransferRecord;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"In Process Transfers\"]/following-sibling::*[1]")
    @AndroidFindBy(xpath = "//*[@text = 'In Process Transfers']/../following-sibling::*[1]")
    private WebElement inProcessTransferRecord;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Pending Transfers\"]/following-sibling:: XCUIElementTypeButton/XCUIElementTypeStaticText[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.view.View\").childSelector(new UiSelector().className(\"android.widget.TextView\"))")
    private List<WebElement> recordDates;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Pending Transfers\"]/following-sibling:: XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"clickSurface\")")
    private List<WebElement> records;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"No pending transactions are available at this time.\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"No pending transactions are available at this time.\")")
    private WebElement noRecordsMessage;

    @AndroidFindBy(xpath = "//*[@resource-id = 'transfer_disclosures']/preceding-sibling::android.widget.TextView[starts-with(@text,'For transfers to')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Disclosures\"]/preceding-sibling::XCUIElementTypeStaticText[starts-with(@name,'For transfers to')]")
    private WebElement pendingTransfersCopy;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cancel\" OR label == \"Back\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(0)")
    private WebElement backButton;

    protected PendingTransferScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Select Pending Transfers Record.
     */
    public void selectPendingTransferRecord() {
        pendingTransferRecord.click();
    }

    /**
     * Taps on 'Back' button.
     */
    public void tapBack() {
        backButton.click();
    }

    /**
     * Select In-Process Transfers Record.
     */
    public void selectInProcessTransferRecord() {
        getDriver().scrollTo(inProcessTransferRecord).click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilCondition(
                ExpectedConditions.or(ExpectedConditions.visibilityOf(noRecordsMessage)
                        , ExpectedConditions.elementToBeClickable(pendingTransferRecord)));
    }
}
