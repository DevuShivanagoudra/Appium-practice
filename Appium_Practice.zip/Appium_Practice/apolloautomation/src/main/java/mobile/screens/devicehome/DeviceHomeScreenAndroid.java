package mobile.screens.devicehome;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import jarvis.mobile.appium.Utils;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import mobile.common.exceptions.AppNotFoundException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import static io.appium.java_client.pagefactory.LocatorGroupStrategy.ALL_POSSIBLE;
import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;
import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
public class DeviceHomeScreenAndroid extends
        DeviceHomeScreenBase<AndroidCustomDriver> {

    private static final String APPTEXT_LOCATOR = "new UiSelector().className(\"android.widget.TextView\").text(\"%s\")";
    private static final String SEARCHAPP_LOCATOR = "new UiSelector().descriptionContains(\"%s\")";
    private static final String APP_LOCATOR = "new UiSelector().descriptionStartsWith(\"%s\")";
    private static boolean installFlag = false;
    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Search Google Play\")")
    protected WebElement search;

    @HowToUseLocators(androidAutomation = ALL_POSSIBLE)
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.EditText\")")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\")")
    private WebElement searchEditable;

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.view.View\").description(\"Install\")")
    private WebElement install;

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.view.View\").description(\"Uninstall\")")
    private WebElement uninstall;

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(1)")
    private WebElement uninstallConfirm;

    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Work Play Store\")")
    private WebElement workPlayStore;

    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Work Client Access\").instance(0)")
    private WebElement clientAccessAlpha;

    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Work Client Access\").instance(0)")
    private WebElement clientAccessBeta;

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\")")
    private List<WebElement> apps;

    public DeviceHomeScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    /**
     * Launches Sprintboard by pressing 'Home' button.
     */
    public void launchSprintBoard() {
        getDriver().pressKey(new KeyEvent(AndroidKey.HOME));
        getDriver().waitUntilVisible(springBoard);
        getDriver().waitUntilCondition(ExpectedConditions.numberOfElementsToBeMoreThan(
                AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.TextView\")"),
                1));
    }

    public void openApp() {
        final String server = Utils.getProperty("appium.server").toLowerCase();
        int count = 0;
        WebElement app =
                (server.equalsIgnoreCase("alpha")) ? clientAccessAlpha : clientAccessBeta;

        if (!getDriver().isElementVisible(app)) {
            launchSprintBoard();
            getDriver().waitUntilClickable(springBoard);
            List<String> previousApps = apps
                    .stream()
                    .map(WebElement::getText)
                    .collect(Collectors.toList());
            List<String> currentApps = new LinkedList<>();
            while (!previousApps.equals(currentApps) && count < 10 && !getDriver()
                    .isElementVisible(app)) {
                launchSprintBoard();
                currentApps = apps.stream()
                        .map(WebElement::getText)
                        .collect(Collectors.toList());
                previousApps = currentApps;
                getDriver().swipeScreen(Direction.LEFT);
                getDriver().waitUntilClickable(springBoard);
                count++;
            }
        }
        app.click();
    }

    @Override
    public void launchApp() {
        final boolean buildUpdate = Boolean.parseBoolean(System.getProperty("appium.buildUpdate"));
        if (buildUpdate && !installFlag) {
            launchAppstoreApp();
            installFlag = true;
        } else {
            openApp();
        }
    }

    public void searchFindApp() {
        final String server = Utils.getProperty("appium.server").toLowerCase();
        final String appName = String.format("client access %s", server);
        int count = 0;
        if (!getDriver().isElementVisible(workPlayStore)) {
            launchSprintBoard();
            getDriver().waitUntilClickable(springBoard);
            List<String> previousApps = apps.stream()
                    .map(WebElement::getText)
                    .collect(Collectors.toList());
            List<String> currentApps = new LinkedList<>();
            while (!previousApps.equals(currentApps) && count < 10 && !getDriver()
                    .isElementVisible(workPlayStore)) {
                launchSprintBoard();
                currentApps = apps.stream()
                        .map(WebElement::getText)
                        .collect(Collectors.toList());
                previousApps = currentApps;
                getDriver().swipeScreen(Direction.LEFT);
                getDriver().waitUntilClickable(springBoard);
                count++;
            }
        }
        if (!getDriver().isElementVisible(workPlayStore)) {
            throw new AppNotFoundException(
                    String.format("The required app '%s' is not found", appName));
        }
        workPlayStore.click();
        getDriver().waitUntilCondition(DEFAULT_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(search),
                                ExpectedConditions.visibilityOf(searchEditable)),
                "Search screen is not displayed.");
        if (!getDriver().isElementVisible(AppiumBy.androidUIAutomator(String.format(
                SEARCHAPP_LOCATOR, appName)))) {
            if (getDriver().isElementVisible(search)) {
                search.click();
            } else {
                searchEditable.click();
            }
            searchEditable.sendKeys(appName);
            getDriver().pressKey(new KeyEvent(AndroidKey.ENTER));
        }
        getDriver().waitUntilVisible(AppiumBy.androidUIAutomator(String.format(
                SEARCHAPP_LOCATOR, appName))).click();

    }

    public void installOpenApp() {
        getDriver().waitUntilCondition(DEFAULT_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(open), ExpectedConditions.visibilityOf(update),
                                ExpectedConditions.visibilityOf(install)),
                "App detail screen is not displayed.");
        getDriver().waitUntilVisible(uninstall).click();
        getDriver().waitUntilVisible(uninstallConfirm).click();
        getDriver().waitUntilCondition(ExpectedConditions
                .or(ExpectedConditions.visibilityOf(install),
                        ExpectedConditions.visibilityOf(open)));
        if (getDriver().isElementVisible(install)) {
            getDriver().waitUntilClickable(install, MAXIMUM_WAIT_TIMEOUT,
                    "Install button is not displayed.").click();
        }
        getDriver().waitUntilVisible(uninstall, MAXIMUM_WAIT_TIMEOUT,
                "Uninstall button not shown up yet.");
        getDriver()
                .waitUntilClickable(open, MAXIMUM_WAIT_TIMEOUT,
                        "Open button is not displayed.")
                .click();
    }

    public void launchAppstoreApp() {
        searchFindApp();
        installOpenApp();
    }

    /**
     * Launches any app located on the screen.
     *
     * @param appName String
     */
    public void findAndlaunchApp(final String appName) {
        AppiumBy locator = (AppiumBy) AppiumBy
                .androidUIAutomator(String.format(APP_LOCATOR, appName));

        if (!getDriver().isElementVisible(locator)) {
            launchSprintBoard();
            List<String> previousApps = apps.stream()
                    .map(WebElement::getText)
                    .collect(Collectors.toList());
            List<String> currentApps = new LinkedList<>();
            while (!previousApps.equals(currentApps) && !getDriver().isElementVisible(locator)) {
                getDriver().pressKey(new KeyEvent(AndroidKey.HOME));
                getDriver().waitUntilClickable(springBoard);
                currentApps = apps.stream()
                        .map(WebElement::getText)
                        .collect(Collectors.toList());
                previousApps = currentApps;
                getDriver().swipeScreen(Direction.LEFT);
                getDriver().waitUntilClickable(springBoard);
            }
        }
        if (!getDriver().isElementVisible(locator)) {
            throw new AppNotFoundException(
                    String.format("The required app '%s' is not found", appName));
        } else {
            getDriver().waitUntilVisible(locator).click();
        }
    }

    public void terminateApp(final String appPackage) {
        try {
            getDriver()
                    .executeShellCommand(String.format("adb shell pm clear %s", appPackage));
            getDriver()
                    .executeShellCommand(String.format("adb shell am force-stop %s", appPackage));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
