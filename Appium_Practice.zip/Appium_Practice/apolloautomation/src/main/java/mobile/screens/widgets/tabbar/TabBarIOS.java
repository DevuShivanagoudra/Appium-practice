package mobile.screens.widgets.tabbar;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import mobile.common.constants.TabBarOption;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

public class TabBarIOS extends TabBarBase<IOSCustomDriver> {

    public TabBarIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    protected WebElement getOption(TabBarOption option) {
        List<WebElement> result = getButtons().stream()
                .filter(element -> element.getAttribute("name").equalsIgnoreCase(option.toString()))
                .collect(Collectors.toList());
        if (option.toString().equalsIgnoreCase("analysis")) {
            getDriver().waitUntilVisible(AppiumBy.
                            iOSClassChain(
                                    "**/XCUIElementTypeTabBar/**/XCUIElementTypeButton[`label == \"More\"`]"))
                    .click();
            return getDriver().waitUntilVisible(AppiumBy.
                    iOSClassChain("**/XCUIElementTypeStaticText[`label == \"Analysis\"`]"));
        }
        return result.get(0);
    }
}
