package mobile.screens.login;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import mobile.appium.ios.IOSUtils;
import org.openqa.selenium.WebElement;

@Slf4j
@Getter
public class LoginScreenIOS extends LoginScreenBase<IOSCustomDriver> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther[1]/**/XCUIElementTypeTextField")
    private WebElement filledUsername;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther[2]/**/XCUIElementTypeTextField")
    private WebElement filledPassword;

    public LoginScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void setRememberUserName(final boolean toggleState) {
        IOSUtils.setToggle(getDriver(), getRememberUsername(), toggleState);
    }

    @Override
    public boolean getRememberUserNameState() {
        return getRememberUsername().getAttribute("value") == "0" ? false : true;
    }

    @Override
    public void fillUsername(final String username) {
        CommonUtils.replaceText(getDriver(), getUsername(), username);
    }

    @Override
    public void fillPassword(final String password) {
        CommonUtils.replaceText(getDriver(), getPassword(), password);
    }

    /**
     * Login to ClientAccess.
     */
    public void signIn(final String username, final String password) {
        CommonUtils.replaceText(getDriver(), getUsername(), username);
        CommonUtils.replaceText(getDriver(), getPassword(), password);
        getDriver().swipeScreen(Direction.UP);
        getDriver().tap(getSignIn());
    }
}
