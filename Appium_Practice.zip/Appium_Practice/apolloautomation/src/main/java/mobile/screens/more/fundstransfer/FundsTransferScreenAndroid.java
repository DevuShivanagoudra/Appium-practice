package mobile.screens.more.fundstransfer;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class FundsTransferScreenAndroid extends
        FundsTransferScreenBase<AndroidCustomDriver> {

    public FundsTransferScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(getNewTransfer()),
                                ExpectedConditions.visibilityOf(getPending()),
                                ExpectedConditions.visibilityOf(getHistory())),
                "Support Page is not displayed.");
    }
}
