package mobile.screens.more.fundstransfer.history;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;

@Slf4j
@Getter
public class HistoryScreenIOS extends
        HistoryScreenBase<IOSCustomDriver> {

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"In Process Transfers\"]/following-sibling::XCUIElementTypeButton/XCUIElementTypeStaticText[1]")
    private List<WebElement> inProcessTransferDates;

    public HistoryScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public String fetchHistoryCopy() {
        return getDriver().scrollTo(getHistoryCopy()).getText();
    }
}
