package mobile.screens.alerts.incorrectverificationcode;

import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.screens.alerts.AlertDialogBase;
import org.openqa.selenium.WebElement;

@Slf4j
@Getter
public class IncorrectVerificationCodeAlertAndroid extends
        AlertDialogBase<AndroidCustomDriver> {

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\").instance(0)")
    private WebElement title;

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\").instance(1)")
    private WebElement message;

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\").text(\"Done\")")
    private WebElement done;

    public IncorrectVerificationCodeAlertAndroid(final AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(done, "Alert NOT shown up.");
    }
}
