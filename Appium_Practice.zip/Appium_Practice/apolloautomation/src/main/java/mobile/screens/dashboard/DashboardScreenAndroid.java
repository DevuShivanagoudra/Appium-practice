package mobile.screens.dashboard;

import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

@Slf4j
@Getter
public class DashboardScreenAndroid extends
        DashboardScreenBase<AndroidCustomDriver> {

    private final String balancelabel_locator = "new UiSelector().className(\"android.widget.ScrollView\").childSelector(new UiSelector().text(\"Balance\"))";

    //FIXME : After Tags get updated.
    @AndroidFindBy(uiAutomator = balancelabel_locator
            + ".fromParent(new UiSelector().textStartsWith(\"$\"))")
    private WebElement balance;

    @AndroidFindBy(uiAutomator = balancelabel_locator
            + ".fromParent(new UiSelector().textStartsWith(\"Since\"))")
    private WebElement dateUpdated;

    public DashboardScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    public void verifyWidgetsWhenDashboardCustomised() {
        getDriver().scrollTo(getMyHoldingsCheckbox(), Direction.DOWN, 3);
        if (getMyHoldingsCheckbox().getAttribute("value").equals("Checked checkbox")) {
            getMyHoldingsCheckbox().click();
        }
        getCustomiseDashboardDoneButton().click();
        Assert.assertFalse(getDriver().isElementVisible(getMyHoldingsLabel()), "My Holdings label is visible.");
        getDriver().scrollTo(getCustomize()).click();

        if (getMyHoldingsCheckbox().getAttribute("value").equals("Unchecked checkbox")) {
            getMyHoldingsCheckbox().click();
        }
        getCustomiseDashboardDoneButton().click();
        Assert.assertTrue(getDriver().isElementVisible(getMyHoldingsLabel()), "My Holdings label is not visible.");
    }
}
