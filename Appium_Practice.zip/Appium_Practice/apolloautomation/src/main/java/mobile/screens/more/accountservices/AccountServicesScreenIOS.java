package mobile.screens.more.accountservices;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.extern.slf4j.Slf4j;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
public class AccountServicesScreenIOS extends
        AccountServicesScreenBase<IOSCustomDriver> {

    private static final String SERVICE_LOCATOR = "**/XCUIElementTypeButton[`label == \"%s\"`]";

    public AccountServicesScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapService(final String serviceName) {
        getDriver().waitUntilClickable(MAXIMUM_WAIT_TIMEOUT,
                AppiumBy.iOSClassChain(String.format(SERVICE_LOCATOR, serviceName)),
                String.format("[%s] is not clickable", serviceName)).click();
    }
}
