package mobile.screens.secretquestion;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import mobile.appium.ios.IOSUtils;
import mobile.common.constants.Toggle;

@Slf4j
@Getter
public class SecretQuestionScreenIOS extends SecretQuestionScreenBase<IOSCustomDriver> {

    public SecretQuestionScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    /**
     * Submits default Answer on Secret Question screen.
     */
    @Override
    public void submitSecretAnswer(final String secretAnswer, final Toggle state) {
        CommonUtils.replaceText(getDriver(), getSecretAnswerEditable(), secretAnswer);
        if (getDriver().isElementVisible(getRememberOnDevice())) {
            setRememberOnDeviceToggle(state.getBoolValue());
        }
        getSubmitButton().click();
    }

    public void setRememberOnDeviceToggle(final boolean toggleState) {
        IOSUtils.setToggle(getDriver(), getRememberOnDevice(), toggleState);
    }
}
