package mobile.screens.analysis.allocation;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static io.appium.java_client.pagefactory.LocatorGroupStrategy.ALL_POSSIBLE;
import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class AllocationScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Description\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Description\")")
    private WebElement description;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Disclosures\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Disclosures\")")
    private WebElement disclosures;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Value\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Value\")")
    private WebElement value;

    @HowToUseLocators(iOSXCUITAutomation = ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Allocation Type Picker\"`]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Allocation Type Picker, Asset Class\"`]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Allocation Type Picker, Product Type\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"View-dropDownIcon\")")
    private WebElement viewType;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Value\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"View\").instance(0).resourceId(\"DoughNutChart\")")
    private WebElement doughNutChart;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"No results match the selected criteria\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"No results match the selected criteria.\")")
    private WebElement noResultsMatch;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Reports\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"primaryTab-tab-1\")")
    private WebElement reportsTab;

    public AllocationScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on Filter button.
     */
    public void tapDescription() {
        getDriver().scrollTo(description, Direction.UP).click();
    }

    /**
     * Selects view from the dropdown.
     *
     * @param viewType String
     */
    protected abstract void selectViewType(final String viewType);

    /**
     * Taps on Reports Tab.
     */
    public void tapReportsTab() {
        reportsTab.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(value, MAXIMUM_WAIT_TIMEOUT,
                "Allocation Screen is not displayed.");
    }
}
