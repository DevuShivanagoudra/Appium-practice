package mobile.screens.more.accountservices.documentdelivery.edeliveryterms;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EDeliveryTermsandConditionsScreenIOS extends
        EDeliveryTermsandConditionsScreenBase<IOSCustomDriver> {

    public EDeliveryTermsandConditionsScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
