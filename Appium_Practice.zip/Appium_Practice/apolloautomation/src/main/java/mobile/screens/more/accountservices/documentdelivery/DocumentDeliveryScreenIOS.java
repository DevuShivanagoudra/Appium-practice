package mobile.screens.more.accountservices.documentdelivery;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Getter
public class DocumentDeliveryScreenIOS extends
        DocumentDeliveryScreenBase<IOSCustomDriver> {

    private static final String ACCOUNT_LOCATOR = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";

    public DocumentDeliveryScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @SneakyThrows
    @Override
    public void setEDeliveryToggle(Toggle state) {
        //FIXME: TypeSwitch "Visible" property is set to false.(IOS16) (BUG 1462181).
        //getDriver().scrollToElement(getEDeliveryAllOptions(), Direction.DOWN);
        getDriver().swipeScreen(Direction.DOWN);
        setToggle(getEDeliveryAllOptions(), state.getBoolValue());
    }

    public void setToggle(final WebElement toggleElement,
                          final boolean toggleState) {
        //FIXME: TypeSwitch "Visible" property is set to "false"(IOS16) (BUG 1462181).
        //driver.scrollToElement(toggleElement);
        CommonUtils.scrollToElement(getDriver(), toggleElement, Direction.UP, 10);
        if (toggleState && toggleElement.getAttribute("value").equals("0")) {
            //FIXME: Click is not working on TypeSwitch(IOS16) (BUG 1462176).
            getDriver().tap(toggleElement);
            getDriver()
                    .waitUntilCondition(ExpectedConditions.attributeToBe(toggleElement, "value", "1"));
        } else if (!toggleState && toggleElement.getAttribute("value").equals("1")) {
            //FIXME: Click is not working on TypeSwitch(IOS16) (BUG 1462176).
            getDriver().tap(toggleElement);
            getDriver()
                    .waitUntilCondition(ExpectedConditions.attributeToBe(toggleElement, "value", "0"));
        }
    }

    @Override
    public void tapAccount(final String name) {
        final WebElement element = getDriver()
                .scrollTo(AppiumBy.iOSClassChain(String.format(ACCOUNT_LOCATOR, name)));
        getDriver().swipeScreen(0.5, 0.4);
        element.click();
    }

    @Override
    public void tapDocumentType(final String name) {
        getDriver().scrollTo(AppiumBy.iOSClassChain(String.format(ACCOUNT_LOCATOR, name)))
                .click();
    }

    public List<String> getAccountsInSection(final String fromSection, final String toSection) {
        List<String> accounts = getAccounts().stream().map(
                x -> x.getAttribute("label")).collect(
                Collectors.toList());

        List<String> accountNames = getAccounts()
                .subList(accounts.indexOf(fromSection) + 1, accounts.indexOf(toSection))
                .stream()
                .map(x -> x.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText")))
                .map(x -> x.getAttribute("label")).collect(
                        Collectors.toList());
        return accountNames;
    }

    public List<String> getAccountsInSection(final String fromSection, final String fromSubSection,
                                             final String toSection) {
        List<String> accounts = getAccounts().stream()
                .map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());

        List<WebElement> accountsInSection = getAccounts()
                .subList(accounts.indexOf(fromSection) + 1, accounts.indexOf(toSection));
        List<String> accountNamesInSection = getAccounts()
                .subList(accounts.indexOf(fromSection) + 1, accounts.indexOf(toSection))
                .stream()
                .map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
        List<String> accountNames = accountsInSection
                .subList(accountNamesInSection.indexOf(fromSubSection) + 1,
                        accountNamesInSection.size())
                .stream()
                .map(x -> x.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText")))
                .map(x -> x.getAttribute("label")).collect(
                        Collectors.toList());
        return accountNames;
    }

    @Override
    public boolean isAccountVisible(final String account) {
        getDriver()
                .scrollTo(AppiumBy.iOSClassChain(String.format(ACCOUNT_LOCATOR, account)));
        return getDriver()
                .isElementVisible(AppiumBy.iOSClassChain(String.format(ACCOUNT_LOCATOR, account)));
    }
}
