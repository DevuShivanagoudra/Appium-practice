package mobile.screens.more.marketresearch.marketresearchhome.symbolquote.companydetails;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class CompanyDetailsScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeNavigationBar/**/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"TopBar-Title-.*\")")
    private WebElement title;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Company Address\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Company Address-expandableSurface\")")
    private WebElement companyAddress;

    protected CompanyDetailsScreenBase(final D driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(companyAddress, MAXIMUM_WAIT_TIMEOUT,
                "Stock Detail Screen is not displayed.");
    }

}
