package mobile.screens.analysis.reports;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class ReportsScreenIOS extends ReportsScreenBase<IOSCustomDriver> {

    public ReportsScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

}
