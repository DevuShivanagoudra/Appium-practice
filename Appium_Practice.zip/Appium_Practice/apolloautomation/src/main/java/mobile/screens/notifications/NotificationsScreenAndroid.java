package mobile.screens.notifications;

import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.constants.ElementDirection;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;

@Slf4j
@Getter
public class NotificationsScreenAndroid extends
        NotificationsScreenBase<AndroidCustomDriver> {

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"clickSurface\").instance(0)")
    private WebElement notificationItem;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"clickSurface\")")
    private List<WebElement> notificationList;

    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Delete\")")
    private WebElement deleteIcon;

    public NotificationsScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    public void swipingAndDeletingNotification() {
        getDriver().swipeElement(notificationItem, ElementDirection.LEFT);
        getDriver().tap(deleteIcon);
    }
}
