package mobile.screens.analysis.allocation.disclosures;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AllocationDisclosuresScreenAndroid extends
        AllocationDisclosuresScreenBase<AndroidCustomDriver> {

    public AllocationDisclosuresScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
