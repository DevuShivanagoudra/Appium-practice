package mobile.screens.more.vault;

import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import org.openqa.selenium.WebElement;

@Getter
public class VaultNewFolderScreenIOS extends VaultScreenIOS {

    @HowToUseLocators(iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextView")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeTextView")
    private WebElement descriptionEditable;

    public VaultNewFolderScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void enterFolderDetails(final String name, final String description) {
        getDriver().enterText(getFolderNameEditable(), name);
        getDriver().enterText(descriptionEditable, description);
    }

    @Override
    public void enterFolderName(final String name) {
        getDriver().replaceText(getFolderNameEditable(), name);
    }

    /**
     * Clears folder name field/element.
     */
    public void clearFolderName() {
        getFolderNameEditable().clear();
        getDriver().waitUntilClickable(getFolderNameEditable());
    }

    /**
     * Enters description in the description field.
     *
     * @param description String
     */
    public void enterDescription(final String description) {
        getDriver().replaceText(descriptionEditable, description);
    }
}
