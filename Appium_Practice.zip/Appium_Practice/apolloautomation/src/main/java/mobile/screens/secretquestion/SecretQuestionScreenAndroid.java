package mobile.screens.secretquestion;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.android.AndroidUtils;
import mobile.common.constants.Toggle;

@Slf4j
public class SecretQuestionScreenAndroid extends
        SecretQuestionScreenBase<AndroidCustomDriver> {

    public SecretQuestionScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    /**
     * Submits default Answer on Secret Question screen.
     */
    @Override
    public void submitSecretAnswer(final String secretAnswer, final Toggle state) {
        getDriver().waitUntilClickable(getSecretAnswerEditable()).sendKeys(secretAnswer);
        if (getDriver().isElementVisible(getRememberOnDevice())) {
            setRememberOnDeviceToggle(state.getBoolValue());
        }
        getDriver().waitUntilClickable(getSubmitButton()).click();
    }

    @Override
    protected void setRememberOnDeviceToggle(final boolean toggleState) {
        AndroidUtils.setCheckBox(getDriver(), getRememberOnDevice(), toggleState);
    }
}
