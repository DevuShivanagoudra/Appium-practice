package mobile.screens.portfolio.stockdetails;

import jarvis.mobile.common.driver.AndroidCustomDriver;

public class HoldingDetailsScreenAndroid extends HoldingDetailsScreenBase
        <AndroidCustomDriver> {

    public HoldingDetailsScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
