package mobile.screens.more.fundstransfer.history;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

@Slf4j
@Getter
public abstract class HistoryScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeDatePicker[@name=\"toDatePicker\"]/following-sibling::XCUIElementTypeButton[1]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'To']/following-sibling::android.view.View[1]")
    private WebElement firstRecord;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeDatePicker[`label == \"From\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"From\")")
    private WebElement fromDateSelectable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeDatePicker[`label == \"To\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"To\")")
    private WebElement toDateSelectable;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeDatePicker[@name=\"toDatePicker\"]/following-sibling:: XCUIElementTypeButton/XCUIElementTypeStaticText[1]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'To']/following-sibling::android.view.View/android.widget.TextView")
    private List<WebElement> recordDates;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeDatePicker[@name=\"toDatePicker\"]/following-sibling:: XCUIElementTypeButton")
    @AndroidFindBy(xpath = "//*[@resource-id = 'To']/following-sibling::android.view.View")
    private List<WebElement> records;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"No pending transactions are available at this time.\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"No pending transactions are available at this time.\")")
    private WebElement noRecordsMessage;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"No transfer history is available at this time.\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"No transfer history is available at this time.\")")
    private WebElement noTransferHistoryMessage;

    @AndroidFindBy(xpath = "//*[@resource-id = 'transfer_disclosures']/preceding-sibling::android.view.View[starts-with(@content-desc, 'View up to')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Disclosures\"]/preceding-sibling::XCUIElementTypeStaticText[starts-with(@name,'View up to')]")
    private WebElement historyCopy;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Disclosures\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"transfer_disclosuresText\")")
    private WebElement disclosuresLink;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cancel\" OR label == \"Back\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(0)")
    private WebElement backButton;

    protected HistoryScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Selects a Record.
     */
    public void selectRecord() {
        firstRecord.click();
    }

    /**
     * Taps on 'Back' button.
     */
    public void tapBack() {
        backButton.click();
    }

    /**
     * Taps on 'Disclosures' link.
     */
    public void tapDisclosuresLink() {
        getDriver().scrollTo(disclosuresLink).click();
    }

    /**
     * Fetches History Copy.
     */
    protected abstract String fetchHistoryCopy();

    @Override
    public void waitToLoad() {
        getDriver().waitUntilCondition(
                ExpectedConditions.or(ExpectedConditions.visibilityOf(noRecordsMessage)
                        , ExpectedConditions.elementToBeClickable(firstRecord)));
    }
}
