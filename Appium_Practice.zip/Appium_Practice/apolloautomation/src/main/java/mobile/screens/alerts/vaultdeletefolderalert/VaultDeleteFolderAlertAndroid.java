package mobile.screens.alerts.vaultdeletefolderalert;

import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.screens.alerts.AlertDialogBase;
import org.openqa.selenium.WebElement;

@Slf4j
@Getter
public class VaultDeleteFolderAlertAndroid extends
        AlertDialogBase<AndroidCustomDriver> {

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\").text(\"Permanently Delete\")")
    private WebElement title;

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\").instance(1)")
    private WebElement message;

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\").text(\"Cancel\")")
    private WebElement Cancel;

    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\").text(\"Delete\")")
    private WebElement Delete;

    public VaultDeleteFolderAlertAndroid(final AndroidCustomDriver driver) {
        super(driver);
    }

    public void tapDelete() {
        Delete.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(title, "Alert NOT shown up.");
    }
}
