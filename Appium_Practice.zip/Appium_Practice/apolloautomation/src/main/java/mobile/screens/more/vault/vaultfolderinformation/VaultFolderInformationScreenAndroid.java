package mobile.screens.more.vault.vaultfolderinformation;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class VaultFolderInformationScreenAndroid extends
        VaultFolderInformationScreenBase<AndroidCustomDriver> {

    public VaultFolderInformationScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
