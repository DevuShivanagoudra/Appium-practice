package mobile.screens.signout;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class SignOutScreenIOS extends
        SignOutScreenBase<IOSCustomDriver> {

    public SignOutScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}