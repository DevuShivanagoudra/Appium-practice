package mobile.screens.more.documents.file;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DocumentFileScreenAndroid extends
        DocumentFileScreenBase<AndroidCustomDriver> {

    public DocumentFileScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
