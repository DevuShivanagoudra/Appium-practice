package mobile.screens.portfolio;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static io.appium.java_client.pagefactory.LocatorGroupStrategy.ALL_POSSIBLE;
import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
public class PortfolioScreenAndroid extends
        PortfolioScreenBase<AndroidCustomDriver> {

    private static final String MYPORTFOLIOHOLDING_VIEWOPTION = "new UiSelector().resourceId(\"%s\")";
    private static final String MYPORTFOLIOHOLDING_GROUPBYOPTION = "new UiSelector().resourceId(\"Group By-%s-Text\")";
    private static final String VIEW_OPTION = "new UiSelector().text(\"%s\")";
    private static final String CUSIP_LOCATOR = "//*[@text = '%s']";

    @HowToUseLocators(androidAutomation = ALL_POSSIBLE)
    @AndroidFindBy(xpath = "//*[@resource-id = \"Realized Gain / (Loss) Summary\"]//android.widget.TextView")
    @AndroidFindBy(xpath = "//*[@resource-id = \"Unrealized Gain / (Loss) Summary\"]//android.widget.TextView")
    private List<WebElement> gainLossDetails;

    @AndroidFindBy(xpath = "//*[@resource-id = \"Realized Gain / (Loss) Summary\"]//android.widget.TextView[@resource-id = \"Gain\"]")
    private WebElement realizedGainLossGainText;

    @AndroidFindBy(xpath = "//*[@resource-id='accountsContent']/*[not(@resource-id='Filter by Accounts')]")
    private WebElement accountSelected;

    public PortfolioScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void selectMyPortFolioHoldingView(final String viewOption) {
/*        getDriver().scrollToElement(getMyPortFolioHoldings_ViewSelectable(), Direction.DOWN)
            .click();*/
        getDriver().scrollTo(
                        AppiumBy.androidUIAutomator(String.format(MYPORTFOLIOHOLDING_VIEWOPTION, viewOption)),
                        Direction.DOWN)
                .click();
    }

    @Override
    public void selectView(final String viewOption) {
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(VIEW_OPTION, viewOption))).click();
    }

    @Override
    public WebElement getCurrentValue(final String cusipName) {
        final String siblingLocator = "/android.widget.TextView";
        getDriver()
                .scrollTo(By.xpath(String.format(CUSIP_LOCATOR, cusipName)), Direction.UP_SMALL);
        return CommonUtils.getSiblingUsingxPath(getDriver(), String.format(CUSIP_LOCATOR, cusipName)
                , siblingLocator, 2);
    }

    @Override
    public WebElement getCurrentValueChange(final String cusipName) {
        final String siblingLocator = "/android.widget.TextView";
        return CommonUtils.getSiblingUsingxPath(getDriver(), String.format(CUSIP_LOCATOR, cusipName)
                , siblingLocator, 3);
    }

    @Override
    public WebElement getpriceChange(final String cusipName) {
        final String siblingLocator = "//android.widget.TextView";
        return CommonUtils.getSiblingUsingxPath(getDriver(), String.format(CUSIP_LOCATOR, cusipName)
                , siblingLocator, 4);
    }

    @Override
    public void selectMyPortFolioHoldingGroupBy(final String viewOption) {
        getMyPortFolioHoldings_GroupBySelectable().click();
        getDriver().waitUntilVisible(
                        AppiumBy.androidUIAutomator(String.format(MYPORTFOLIOHOLDING_VIEWOPTION, viewOption)))
                .click();
    }

    @Override
    public WebElement getTotalValue(final String text) {
        final String siblingLocator = "/android.widget.TextView";
        return CommonUtils.getSiblingUsingxPath(getDriver(), String.format(CUSIP_LOCATOR, text)
                , siblingLocator, 1);
    }

    @Override
    public WebElement getRecordDescription(final String text) {
        final String siblingLocator = "/android.widget.TextView";
        getDriver()
                .scrollTo(By.xpath(String.format(CUSIP_LOCATOR, text)), Direction.UP_SMALL);
        return CommonUtils.getSiblingUsingxPath(getDriver(), String.format(CUSIP_LOCATOR, text)
                , siblingLocator, 1);
    }

    @Override
    public Map<String, String> fetchGainLossDetails() {
        Map<String, String> gainLoss = new LinkedHashMap<>();
        gainLoss.put(gainLossDetails.get(1).getText(), "");
        gainLoss.put(gainLossDetails.get(2).getText(), gainLossDetails.get(3).getText());
        gainLoss.put(gainLossDetails.get(4).getText(), gainLossDetails.get(5).getText());
        gainLoss.put(gainLossDetails.get(6).getText(), gainLossDetails.get(7).getText());
        gainLoss.put(gainLossDetails.get(8).getText(), "");
        gainLoss.put(String.format("longTerm%s", gainLossDetails.get(9).getText()), gainLossDetails
                .get(10).getText());
        gainLoss.put(String.format("longTerm%s", gainLossDetails.get(11).getText()), gainLossDetails
                .get(12).getText());
        gainLoss.put(String.format("longTerm%s", gainLossDetails.get(13).getText()), gainLossDetails
                .get(14).getText());
        gainLoss.put(gainLossDetails.get(15).getText(), gainLossDetails.get(16).getText());
        return gainLoss;
    }

    @Override
    public void tapUnrealizedGainLoss() {
        //FIXME:Ticket 1354549: Unrealized Gain / (Loss) static text is not visible, should be working fine  after bug is fixed
        getUnrealizedGainLossSection().click();
    }

    @Override
    public void waitForRealizedGLToLoad() {
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT,
                ExpectedConditions.or(ExpectedConditions.visibilityOf(realizedGainLossGainText),
                        ExpectedConditions.visibilityOf(getNoResultsMessage())),
                "No Result Message/Realized Gain/Loss Details not displayed.");
    }

    @Override
    public void tapARecordUsingCusip(final String cusipName) {
        getRecordDescription(cusipName).click();
    }

    public void verifyColorAmountInUnrealizedSummary() {
        getDriver().swipeScreen(Direction.DOWN);

        if (shortTermGainAmt > 0) {
            Assert.assertEquals(getShortTermGain().getText().charAt(0), '$', "Short-Term Gain amount is not in green color.");
        } else {
            Assert.assertEquals(shortTermGainAmt, 0, "Short-Term Gain amount is not in black color.");
            Assert.assertEquals(returnFirstCharacterByText(getDriver().scrollTo(getShortTermGain())), '$', "Short-Term Gain amount is not in black color.");
        }

        if (shortTermLossAmt < 0) {
            Assert.assertEquals(returnFirstCharacterByText(getShortTermLoss()), '(', "Short-Term Loss amount is not in red color.");
        } else {
            Assert.assertEquals(shortTermLossAmt, 0, "Short-Term Loss amount is not in black color.");
            Assert.assertEquals(returnFirstCharacterByText(getDriver().scrollTo(getShortTermLoss())), '$', "Short-Term Loss amount is not in black color.");
        }

        if (shortTermSubTotalAmt > 0) {
            Assert.assertEquals(returnFirstCharacterByText(getShortTermSubTotal()), '$', "Short-Term Sub Total amount is not in green color.");
        } else if (shortTermSubTotalAmt < 0) {
            Assert.assertEquals(returnFirstCharacterByText(getShortTermSubTotal()), '(', "Short-Term Sub Total amount is not in red color.");
        } else {
            Assert.assertEquals(returnFirstCharacterByText(getShortTermSubTotal()), '$', "Short-Term Sub Total amount is not in black color.");
        }

        if (longTermGainAmt > 0) {
            Assert.assertEquals(returnFirstCharacterByText(getLongTermGain()), '$', "Long-Term Gain amount is not in green color.");
        } else {
            Assert.assertEquals(longTermGainAmt, 0, "Long-Term gain amount is not in black color.");
            Assert.assertEquals(returnFirstCharacterByText(getLongTermGain()), '$', "Long-Term gain amount is not in black color.");
        }

        if (longTermLossAmt < 0) {
            Assert.assertEquals(returnFirstCharacterByText(getLongTermLoss()), '(', "Long-Term Loss amount is not in red color.");
        } else {
            Assert.assertEquals(longTermLossAmt, 0, "Long-Term Loss amount is not in black color.");
            Assert.assertEquals(returnFirstCharacterByText(getLongTermLoss()), '$', "Long-Term Loss amount is not in black color.");
        }

        if (longTermSubTotalAmt > 0) {
            Assert.assertEquals(returnFirstCharacterByText(getLongTermSubTotal()), '$', "Long-Term Sub Total amount is not in green color.");
        } else if (shortTermSubTotalAmt < 0) {
            Assert.assertEquals(returnFirstCharacterByText(getLongTermSubTotal()), '(', "Long-Term Sub Total amount is not in red color.");
        } else {
            Assert.assertEquals(returnFirstCharacterByText(getLongTermSubTotal()), '$', "Long-Term Sub Total amount is not in black color.");
        }

        Assert.assertTrue(getDriver().scrollTo(getNetGainLossTotalAmount()).isDisplayed());
        if (netGainLossTotalAmt > 0) {
            Assert.assertEquals(returnFirstCharacterByText(getNetGainLossTotalAmount()), '$', "Net Gain Loss Total amount is not in green color.");
        } else if (netGainLossTotalAmt < 0) {
            Assert.assertEquals(returnFirstCharacterByText(getNetGainLossTotalAmount()), '(', "Net Gain Loss Total amount is not in red color.");
        } else {
            Assert.assertEquals(returnFirstCharacterByText(getNetGainLossTotalAmount()), '$', "Net Gain Loss Total amount is not in black color.");
        }
    }

    public void verifyColorAmountInPortfolioHoldings() {
        getDriver().scrollTo(getValueChangeButton()).click();
        Assert.assertEquals(returnFirstCharacterByText(getDailyValueChangeSubHeaderAmount()), '$', "Sub Header Amount is not 0 or positive as required.");
        Assert.assertEquals(returnFirstCharacterByText(getDvcFirstRecordChangedAmount()), '$', "Amount in value is not 0 or positive as required.");
        final char dvcValueInPercent = returnFirstCharacterByText(getDvcFirstRecordChangeInAmountPercent());
        switch (returnFirstCharacterByText(getDvcFirstRecordChangeInAmount())) {
            case '$':
                Assert.assertEquals(dvcValueInPercent, '$', "Amount in % is not a zero or positive value as required.");
                break;
            case '(':
                Assert.assertEquals(dvcValueInPercent, '(', "Amount in % is not a negative value as required.");
                break;
            default:
                Assert.fail("Error while verifying color of amounts in Position Holdings.");
        }
    }

    public void verifyAccountsSelected() {
        Assert.assertEquals(accountSelected.getText().contains("accounts selected"), false, "More than one Account is selected.");
    }
}
