package mobile.screens.analysis.reports.disclosures;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class ReportsDisclosuresScreenIOS extends
        ReportsDisclosuresScreenBase<IOSCustomDriver> {

    public ReportsDisclosuresScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

}
