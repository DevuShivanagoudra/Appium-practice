package mobile.screens.analysis.reports.disclosures;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ReportsDisclosuresScreenAndroid extends
        ReportsDisclosuresScreenBase<AndroidCustomDriver> {

    public ReportsDisclosuresScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

}
