package mobile.screens.notifications;

import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;


@Slf4j
@Getter
public abstract class NotificationsScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    protected NotificationsScreenBase(D driver) {
        super(driver);
    }

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-Title-Notifications\")")
    private WebElement notificationHeader;

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(notificationHeader, MAXIMUM_WAIT_TIMEOUT,
                "Notification Header is not displayed.");
    }
}
