package mobile.screens.more.morereorder;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class MoreReorderScreenAndroid extends
        MoreReorderScreenBase<AndroidCustomDriver> {

    private static final String reOrderIcon = "new UiSelector().resourceId(\"%s\").childSelector(new UiSelector().resourceId(\"trailingIcon\"))";

    public MoreReorderScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public List<String> getTabBarNames() {
        List<String> tabBarNames = tabBarContainer.stream()
                .map(t -> t.getText())
                .collect(Collectors.toList());
        return tabBarNames;
    }

    @Override
    public WebElement getTabbarDragIcon(final String tabbarName) {
        String name = tabbarName.replace(" ", "");
        return getDriver()
                .waitUntilVisible(AppiumBy.androidUIAutomator(String.format(reOrderIcon, name)));
    }

    @Override
    public boolean isTabbarNameVisible(final String tabbarName) {
        return getTabBarNames().contains(tabbarName);
    }
}
