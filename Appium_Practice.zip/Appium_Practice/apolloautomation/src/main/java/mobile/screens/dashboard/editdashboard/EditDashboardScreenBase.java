package mobile.screens.dashboard.editdashboard;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

@Slf4j
@Getter
public abstract class EditDashboardScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeNavigationBar[`name == \"_TtGC7SwiftUI19UIHosting\"`]/**/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"TopBar-Title.*\")")
    private WebElement title;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Selected\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.ScrollView\").childSelector(new UiSelector().className(\"android.widget.CheckBox\"))")
    private WebElement widgetCheckbox;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeImage[`label == \"arrow.up.and.down.and.arrow.left.and.right\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.ScrollView\").childSelector(new UiSelector().description(\"Drag\"))")
    private WebElement dragIcon;

    protected EditDashboardScreenBase(final D driver) {
        super(driver);
    }

    public abstract void waitToLoad();
}
