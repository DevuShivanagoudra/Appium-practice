package mobile.screens.more.accountservices.documentdelivery.accountdeliveryoptions;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.android.AndroidUtils;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;

import java.util.Map;

@Slf4j
public class AccountDeliveryOptionsScreenAndroid extends
        AccountDeliveryOptionsScreenBase<AndroidCustomDriver> {

    private static final String DELIVERYTYPE_TOGGLE = "new UiSelector().resourceId(\"%s-switch\")";

    public AccountDeliveryOptionsScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void setDeliveryTypes(final Map<String, String> deliveryTypes) {
        AndroidUtils.setCheckBox(getDriver(), getAllDocumentsOptions(),
                Toggle.OFF.getBoolValue());
        for (String key : deliveryTypes.keySet()) {
            WebElement element = getDriver().waitUntilPresent(
                    AppiumBy.androidUIAutomator(String.format(DELIVERYTYPE_TOGGLE, key)));
            if (deliveryTypes.get(key).equalsIgnoreCase("paper")) {
                AndroidUtils.setCheckBox(getDriver(), element,
                        Toggle.OFF.getBoolValue());
            } else {
                AndroidUtils.setCheckBox(getDriver(), element,
                        Toggle.ON.getBoolValue());
            }
        }
    }

    /**
     * Checks whether account toggle is selected.
     *
     * @param accountName String
     * @return boolean
     */
    public boolean isAccountSelected(final String accountName) {
        WebElement element = getDriver().waitUntilPresent(
                AppiumBy.androidUIAutomator(String.format(DELIVERYTYPE_TOGGLE, accountName)));
        return getDriver().isElementChecked(element);
    }
}
