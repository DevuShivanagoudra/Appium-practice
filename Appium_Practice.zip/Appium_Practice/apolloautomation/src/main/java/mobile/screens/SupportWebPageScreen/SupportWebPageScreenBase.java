package mobile.screens.SupportWebPageScreen;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class SupportWebPageScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Recover Username\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Recover Username\")")
    private WebElement recoverUsername;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Help with Login - Password Reset\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Help with Login - Password Reset\")")
    private WebElement recoverPassword;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"Address\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.android.chrome:id/url_bar\")")
    private WebElement pageURL;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Username Guidelines\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Username Guidelines\")")
    private WebElement signInHelpPage;

    protected SupportWebPageScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Fetches Page URL.
     *
     * @return String
     */
    public String fetchPageURL() {
        pageURL.click();
        getDriver().waitUntilClickable(pageURL);
        return pageURL.getText();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(recoverUsername),
                                ExpectedConditions.visibilityOf(recoverPassword)),
                "Support Page is not displayed.");
    }

    /**
     * Waits for Sign In page to load.
     */
    public void waitForSignInHelpPageToLoad() {
        getDriver().waitUntilVisible(signInHelpPage, "Sign In Help is not displayed.");
    }

}
