package mobile.screens.more.documents;

import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;

@Slf4j
@Getter
public class DocumentsScreenAndroid extends
        DocumentsScreenBase<AndroidCustomDriver> {

    //FIXME: Fix the locator once implemented
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Statements\")")
    private List<WebElement> docType;

    public DocumentsScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
