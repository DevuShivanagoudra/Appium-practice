package mobile.screens.more.accountservices.documentdelivery.accountdeliveryoptions;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.Map;

import static io.appium.java_client.pagefactory.LocatorGroupStrategy.ALL_POSSIBLE;
import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class AccountDeliveryOptionsScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Back\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(0)")
    private WebElement backButton;

    @HowToUseLocators(iOSXCUITAutomation = ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSwitch[`label == \"Statements\"`]/XCUIElementTypeSwitch")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Paper\"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(0)")
    private WebElement statementsPaper;

    @HowToUseLocators(iOSXCUITAutomation = ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"E-Delivery\"`]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"E-Delivery\"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Statements-switch\")")
    private WebElement statementsEDelivery;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSwitch[`label == \"Statements\"`]/XCUIElementTypeSwitch")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(1)")
    private WebElement statementsToggle;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSwitch[`label == \"Trade Confirmations\"`]/XCUIElementTypeSwitch")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(1)")
    private WebElement tradeConfirmationsToggle;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Paper\"`][2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(2)")
    private WebElement tradeConfimationsPaper;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"E-Delivery\"`][2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Trade Confirmations-switch\")")
    private WebElement tradeConfirmationsEDelivery;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"E-Delivery\"`][2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Accounts\")")
    private WebElement documentTypeHeader;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"All documents will be delivered by email\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"All documents will be delivered by email.\")")
    private WebElement documentDeliveryOptions;

    @HowToUseLocators(androidAutomation = ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSwitch/XCUIElementTypeSwitch")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"E-Delivery for all documents-switch\")")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"All Documents-switch\")")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"All Accounts-switch\")")
    private WebElement allDocumentsOptions;

    protected AccountDeliveryOptionsScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Set delivery Types for each delivery option.
     *
     * @param deliveryTypes
     */
    protected abstract void setDeliveryTypes(final Map<String, String> deliveryTypes);

    /**
     * Taps Back button.
     */
    public void tapBack() {
        backButton.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(documentDeliveryOptions, DEFAULT_WAIT_TIMEOUT,
                "Document delivery Screen is not displayed.");
    }
}
