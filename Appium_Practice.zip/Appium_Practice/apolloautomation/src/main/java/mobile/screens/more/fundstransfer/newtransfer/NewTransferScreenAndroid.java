package mobile.screens.more.fundstransfer.newtransfer;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class NewTransferScreenAndroid extends
        NewTransferScreenBase<AndroidCustomDriver> {

    private static final String ACCOUNT_LOCATOR = "new UiSelector().text(\"%s\")";

    public NewTransferScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void selectAccount(final String accountName) {
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(ACCOUNT_LOCATOR, accountName))).click();
    }

    @Override
    public void enterAmount(final double amount) {
        getAmount().sendKeys(String.valueOf(amount));
    }
}
