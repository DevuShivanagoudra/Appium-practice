package mobile.screens.accounts;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.constants.ElementDirection;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

@Slf4j
@Getter
public class AccountsScreenIOS extends AccountsScreenBase<IOSCustomDriver> {

    private static final String RECORD_LOCATOR = "**/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"%s\"`]";
    private static final String RECORD_SWIPE_LOCATOR = "**/XCUIElementTypeButton[`label BEGINSWITH[cd] \"%s\"`]";
    private static final String RECORD_SWIPE_LOCATOR_EXTERNAL = "//XCUIElementTypeStaticText[starts-with(@name,\"%s\")]/..";
    private static final String RECORD_INFO_LOCATOR = "**/XCUIElementTypeButton[`label == \"Info\"`]";
    private static final String AUTHORIZED_REPRESENTATIVE = "//XCUIElementTypeStaticText[starts-with(@name,\"%s\")]/../XCUIElementTypeOther[@name=\"Has authorized representatives\"]";

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"OK\"`]")
    private WebElement okButton;

    public AccountsScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapFirstAccount() {
        getDriver().swipeElement(getFirstAccount(), ElementDirection.LEFT);
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(RECORD_INFO_LOCATOR))).click();
    }

    @Override
    public void tapAccount(final String accountName) {
        CommonUtils.scrollToElement(getDriver(), getAssetsSection(), Direction.DOWN, 4);
        getDriver()
                .scrollTo(AppiumBy.iOSClassChain(String.format(RECORD_LOCATOR, accountName)));
        WebElement element = getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(RECORD_SWIPE_LOCATOR, accountName)));
        getDriver().swipeElement(element, ElementDirection.LEFT);
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(RECORD_INFO_LOCATOR, accountName))).click();
    }

    public void tapExternalAccount(final String accountName) {
        CommonUtils.scrollToElement(getDriver(), getAssetsSection(), Direction.DOWN, 20);
        getDriver()
                .scrollTo(AppiumBy.iOSClassChain(String.format(RECORD_LOCATOR, accountName)),
                        Direction.UP, 20);
        WebElement element = getDriver().waitUntilPresent(
                By.xpath(String.format(RECORD_SWIPE_LOCATOR_EXTERNAL, accountName)));
        getDriver().swipeElement(element, ElementDirection.LEFT);
    }

    public void tapInfoIcon(final String accountName) {
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(RECORD_INFO_LOCATOR, accountName))).click();
    }

    /**
     * verifies if External account is visible.
     *
     * @return boolean
     */
    public boolean isExternalAccountVisible() {
        return getDriver().isElementVisible(getExternalAccount());
    }

    /**
     * verifies if External account is Not visible.
     *
     * @return boolean
     */
    public boolean isExternalAccountNotVisible() {
        try {
            getDriver().scrollTo(getExternalAccount(), Direction.UP, 5);
            return false;
        } catch (TimeoutException | NotFoundException e) {
            return true;
        }
    }

    @Override
    public void selectAccount(final String accountName) {
        getDriver().scrollTo(
                AppiumBy.iOSClassChain(String.format(RECORD_LOCATOR, accountName)), Direction.UP_SMALL,
                20);
        WebElement element = getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(RECORD_SWIPE_LOCATOR, accountName)));
        getDriver().swipeElement(element, ElementDirection.LEFT);
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(RECORD_INFO_LOCATOR, accountName))).click();
    }

    public void selectAccount_External(final String accountName) {
        tapExternalAccount(accountName);
    }

    public boolean isUserAbleToEditExternalAccount(final String accountName) {
        return getDriver().isElementVisible(
                AppiumBy.iOSClassChain(String.format(RECORD_INFO_LOCATOR, accountName)));
    }

    @Override
    public void verifyAuthorizedRepresentativeVisible(final String accountName) {
        getDriver()
                .scrollTo(AppiumBy.iOSClassChain(String.format(RECORD_LOCATOR, accountName)));
        Assert.assertTrue(getDriver().isElementPresent(
                        By.xpath(String.format(AUTHORIZED_REPRESENTATIVE, accountName))),
                String.format("Authorized Representative Icon is not visible for account %s",
                        accountName));
    }
}
