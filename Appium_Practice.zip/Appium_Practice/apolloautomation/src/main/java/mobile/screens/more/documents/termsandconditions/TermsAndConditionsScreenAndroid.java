package mobile.screens.more.documents.termsandconditions;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TermsAndConditionsScreenAndroid extends
        TermsAndConditionsScreenBase<AndroidCustomDriver> {

    public TermsAndConditionsScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
