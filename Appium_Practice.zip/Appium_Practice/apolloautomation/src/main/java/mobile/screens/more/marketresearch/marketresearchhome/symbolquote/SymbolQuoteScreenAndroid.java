package mobile.screens.more.marketresearch.marketresearchhome.symbolquote;

import io.appium.java_client.MobileBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class SymbolQuoteScreenAndroid extends
        SymbolQuoteScreenBase<AndroidCustomDriver> {

    String SYMBOL = "//*[@text='%s']";
    String COMPANY = "//*[@text='%s']";
    @AndroidFindBy(xpath = "//*[@resource-id = 'Symbol/Company Name']/../following-sibling::android.view.View[4]")
    private WebElement lastRecord;

    public SymbolQuoteScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void enterDataInSearchBar(String companyName) {
        getDriver().waitUntilClickable(getSearchBar()).sendKeys(companyName);
    }

    @Override
    public WebElement fetchNoRecordsMessage() {
        return getDriver().waitUntilVisible(getNoRecords(),
                MAXIMUM_WAIT_TIMEOUT, "No Records Message is not displayed.");
    }

    public void verifySymbolAndCompanyName(String symbol, String companyName) {
        Assert.assertTrue(getDriver().isElementVisible(MobileBy.xpath(String.format(SYMBOL, symbol))),
                String.format("Symbol label is not visible."));
        Assert.assertTrue(getDriver().isElementVisible(MobileBy.xpath(String.format(COMPANY, symbol))),
                String.format("Company Label is not visible."));
    }
}
