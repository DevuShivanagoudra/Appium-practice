package mobile.screens.more.documents.termsandconditions;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class TermsAndConditionsScreenIOS extends
        TermsAndConditionsScreenBase<IOSCustomDriver> {

    public TermsAndConditionsScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
