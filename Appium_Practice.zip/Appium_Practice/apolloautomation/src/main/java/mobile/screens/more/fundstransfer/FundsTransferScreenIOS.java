package mobile.screens.more.fundstransfer;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class FundsTransferScreenIOS extends
        FundsTransferScreenBase<IOSCustomDriver> {

    public FundsTransferScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
