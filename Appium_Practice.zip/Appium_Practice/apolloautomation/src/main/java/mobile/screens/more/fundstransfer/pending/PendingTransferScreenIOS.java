package mobile.screens.more.fundstransfer.pending;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;

@Slf4j
@Getter
public class PendingTransferScreenIOS extends
        PendingTransferScreenBase<IOSCustomDriver> {

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"In Process Transfers\"]/following-sibling::XCUIElementTypeButton/XCUIElementTypeStaticText[1]")
    private List<WebElement> inProcessTransferDates;


    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Close\"`]")
    private WebElement closeButton;

    public PendingTransferScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    /**
     * Taps on Close button.
     */
    public void tapClose() {
        closeButton.click();
    }
}
