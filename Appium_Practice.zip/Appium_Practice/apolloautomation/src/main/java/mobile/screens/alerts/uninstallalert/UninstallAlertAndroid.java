package mobile.screens.alerts.uninstallalert;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import mobile.screens.alerts.AlertDialogBase;

public class UninstallAlertAndroid extends
        AlertDialogBase<AndroidCustomDriver> {

    public UninstallAlertAndroid(final AndroidCustomDriver driver) {
        super(driver);
    }
}
