package mobile.screens.portfolio;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class PortfolioScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Realized G/L\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"primaryTabRow-tab-2\")")
    private WebElement realizedGainLoss;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label ENDSWITH \" Gain/(Loss)\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textMatches(\".* Gain or \\(Loss\\)\")")
    private WebElement gainLossTypeText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"Views\"'`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"View-dropDownIcon\")")
    private WebElement viewsButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"View\"'`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"View-dropDownIcon\").instance(1)")
    private WebElement myPortFolioHoldings_ViewSelectable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"Group by\"'`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Group By\")")
    private WebElement myPortFolioHoldings_GroupBySelectable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Short-Term\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Short-Term\")")
    private WebElement shortTermText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Long-Term\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Long-Term\")")
    private WebElement longTermText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Net Gain / (Loss) Total\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Net Gain / (Loss) Total\")")
    private WebElement netGainLossText;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Net Gain / (Loss) Total\"]/../following-sibling::XCUIElementTypeStaticText[1]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text = \"Net Gain / (Loss) Total\"]/../following-sibling::android.widget.TextView")
    private WebElement unrealizedGainLossMessage;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Current Value\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Current Value\").instance(0)")
    private WebElement currentValueTab;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Current Value\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Current Value\").instance(1)")
    private WebElement currentValueText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Daily Change\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Daily Change\")")
    private WebElement dailyChangeText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Investment Gain/(Loss)\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Investment Gain or (Loss)\")")
    private WebElement investmentGLSummaryText;

    //TODO: Locator need to be fixed after the ticket "" is fixed.
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Current Value\"]/following-sibling::XCUIElementTypeOther")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"CurrentValueAmount\")")
    private WebElement currentValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH \"As of\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textStartsWith(\"As of\")")
    private WebElement asOfValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Filter\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"ToFilter\")")
    private WebElement realizedGainLossFilterIcon;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"From\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"From\")")
    private WebElement closingFromDateText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"To\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"To\")")
    private WebElement closingToDateText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Unrealized Gain/(Loss) Summary\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Unrealized Gain / (Loss) Summary-expandableSurface\")")
    private WebElement unrealizedGainLossSection;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Unrealized Gain/(Loss) Summary\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"title\")")
    private WebElement unrealizedGainLossText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"View\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"ViewLabel\").instance(1)")
    private WebElement myPortfolioHoldingsViewButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Unrealized G/L\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Unrealized Gain/Loss\")")
    private WebElement gainLossButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Gain/Loss\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"ViewLabel\").instance(1)")
    private WebElement gainLossText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Default\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Default\")")
    private WebElement defaultText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Daily Value Change\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Daily Value Change\")")
    private WebElement valueChangeButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"All Accounts\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"All Accounts\")")
    private WebElement allAccountsChip;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Filter\"]/preceding-sibling::*//XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"Chip.*Text\")")
    private List<WebElement> chips;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"All Securities\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"All Product Types\")")
    private WebElement allSecuritiesChip;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name == \"MO - description\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textStartsWith(\"ALTRIA GROUP INCORPORATED\")")
    private WebElement holdingDescription;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"ALTRIA GROUP INCORPORATED\")")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton/XCUIElementTypeStaticText[`name ENDSWITH \"- description\"`][1]")
    private WebElement firstHoldingDescription;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"MO\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"MO\")")
    private WebElement holdingSymbol;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name == \"MO - currentValue\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\".*_Value\")")
    private WebElement holdingsCurrentValue;

    @iOSXCUITFindBy(iOSNsPredicate = "label CONTAINS \"$\" AND name == \" - TotalValue\"")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"MoneyText\")")
    private WebElement totalHoldingsValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Filter\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"ToFilter\")")
    private WebElement filterButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Total\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Total\")")
    private WebElement totalText;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Daily Change Info Button\"]/following-sibling::XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"DailyChangeAmount\")")
    private WebElement dailyChangeValue;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Daily Change Info Button\"]/../following-sibling::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"GainLossAmount\")")
    private WebElement investmentGLValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Total\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"title\")")
    private List<WebElement> sectionHeaders;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Daily Change Info Button\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Daily Change-Info\")")
    private WebElement dailyChangeInfoButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"Due to variations in timing and availability\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\").instance(1)")
    private WebElement dailyChangeDescriptionText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Daily Change\"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Daily Change\")")
    private WebElement dailyChangeModalText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"All Capital Gains & Losses\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"All Capital Gains & Losses\")")
    private WebElement capitalGainLossText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Short-Term Gains & Losses\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Realized Gain / (Loss) Summary\").childSelector(new UiSelector().text(\"Short-Term\"))")
    private WebElement shortTermGainLossText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Long-Term Gains & Losses\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Realized Gain / (Loss) Summary\").childSelector(new UiSelector().text(\"Long-Term\"))")
    private WebElement longTermGainLossText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"No results match the selected criteria\"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"No results match the selected criteria\")")
    private WebElement noResultsMessage;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"No results match the selected criteria\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"No results match the selected criteria\")")
    private WebElement noResultsMatch;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Short-Term\"]//following::XCUIElementTypeStaticText[@name=\"Gain\"] )[1]//following-sibling:: XCUIElementTypeOther")
    @AndroidFindBy(xpath = "((//*[@text='Short-Term']//following-sibling::*[@text='Gain'])[1]//following-sibling::*[@resource-id=\"MoneyText\"])[1]")
    private WebElement shortTermGain;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Short-Term\"]//following::XCUIElementTypeStaticText[@name=\"Loss\"] )[1]//following-sibling:: XCUIElementTypeOther")
    @AndroidFindBy(xpath = "((//*[@text='Short-Term']//following-sibling::*[@text='Loss'])[1]//following-sibling::*[@resource-id=\"MoneyText\"])[1]")
    private WebElement shortTermLoss;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Short-Term\"]//following::XCUIElementTypeStaticText[@name=\"Subtotal\"] )[1]//following-sibling:: XCUIElementTypeOther")
    @AndroidFindBy(xpath = "((//*[@text='Short-Term']//following-sibling::*[@text='Subtotal'])[1]//following-sibling::*[@resource-id=\"MoneyText\"])[1]")
    private WebElement shortTermSubTotal;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Long-Term\"]//following::XCUIElementTypeStaticText[@name=\"Gain\"] )[1]/following-sibling:: XCUIElementTypeOther")
    @AndroidFindBy(xpath = "((//*[@text='Long-Term']//following-sibling::*[@text='Gain'])[1]//following-sibling::*[@resource-id=\"MoneyText\"])[1]")
    private WebElement longTermGain;


    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Long-Term\"]//following::XCUIElementTypeStaticText[@name=\"Loss\"] )[1]/following-sibling:: XCUIElementTypeOther")
    @AndroidFindBy(xpath = "((//*[@text='Long-Term']//following-sibling::*[@text='Loss'])[1]//following-sibling::*[@resource-id=\"MoneyText\"])[1]")
    private WebElement longTermLoss;


    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Long-Term\"]//following::XCUIElementTypeStaticText[@name=\"Subtotal\"] )[1]/following-sibling:: XCUIElementTypeOther")
    @AndroidFindBy(xpath = "((//*[@text='Long-Term']//following-sibling::*[@text='Subtotal'])[1]//following-sibling::*[@resource-id=\"MoneyText\"])[1]")
    private WebElement longTermSubTotal;


    @iOSXCUITFindBy(xpath = "//*[@name=\"Net Gain / (Loss) Total\"]//following-sibling:: XCUIElementTypeOther")
    @AndroidFindBy(xpath = "//*[@text='Net Gain / (Loss) Total']/following-sibling::*[@resource-id=\"MoneyText\"]")
    private WebElement netGainLossTotalAmount;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,\"As of\")]")
    @AndroidFindBy(xpath = "//*[@text='Net Gain / (Loss) Total']/following-sibling::*[@resource-id=\"MoneyText\"]")
    private WebElement currentDateTime;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\" - description- - currentValue\"]//XCUIElementTypeOther[@name=\" - currentValue\"]/XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'_Value')])[1]")
    private WebElement dailyValueChangeSubHeaderAmount;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Current Value\"]/following:: XCUIElementTypeOther)[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"CurrentValueAmount\")")
    private WebElement currentValueAmount;

    @iOSXCUITFindBy(iOSNsPredicate = "name == \" - TotalValue\"")
    @AndroidFindBy(xpath = "//*[@resource-id='Total']//following-sibling::*[@resource-id='MoneyText']")
    private WebElement totalHoldingsAmount;

    @iOSXCUITFindBy(xpath = "(((//XCUIElementTypeButton[@name=\" - description- - currentValue\"]//following-sibling:: XCUIElementTypeButton)[1]//XCUIElementTypeOther)[1]/XCUIElementTypeStaticText)[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'_Value')])[2]")
    private WebElement dvcFirstRecordChangedAmount;

    @iOSXCUITFindBy(xpath = "(((//XCUIElementTypeButton[@name=\" - description- - currentValue\"]//following-sibling:: XCUIElementTypeButton)[1]//XCUIElementTypeOther)[2]/XCUIElementTypeStaticText)[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'_Value')])[3]")
    private WebElement dvcFirstRecordChangeInAmount;

    @iOSXCUITFindBy(xpath = "(((//XCUIElementTypeButton[@name=\" - description- - currentValue\"]//following-sibling:: XCUIElementTypeButton)[1]//XCUIElementTypeOther)[3]/XCUIElementTypeStaticText)[1]")
    @AndroidFindBy(xpath = "(//*[contains(@resource-id,'_Value')])[2]//following-sibling::*[@resource-id='MoneyText']")
    private WebElement dvcFirstRecordChangeInAmountPercent;

    protected double shortTermGainAmt = 0;
    protected double shortTermLossAmt = 0;
    protected double shortTermSubTotalAmt = 0;
    protected double longTermGainAmt = 0;
    protected double longTermLossAmt = 0;
    protected double longTermSubTotalAmt = 0;
    protected double netGainLossTotalAmt = 0;

    protected PortfolioScreenBase(final D driver) {
        super(driver);
    }

    public void waitToLoadCurrentValueScreen() {
        getDriver().waitUntilPresent(currentValue);
    }

    /**
     * Selects My Portfolio Holdings view.
     *
     * @param viewOption String
     */
    protected abstract void selectMyPortFolioHoldingView(final String viewOption);

    /**
     * Select Main Views.
     *
     * @param viewOption String
     */
    protected abstract void selectView(final String viewOption);

    /**
     * Fetches Current Value of a particular Stock.
     *
     * @param cusipName String
     * @return Mobile Element
     */
    protected abstract WebElement getCurrentValue(final String cusipName);

    /**
     * Fetches Current Value Change of a particular Stock.
     *
     * @param cusipName String
     * @return Mobile Element
     */
    protected abstract WebElement getCurrentValueChange(final String cusipName);

    /**
     * Fetches Price Change of a particular Stock.
     *
     * @param cusipName String
     * @return Mobile Element
     */
    protected abstract WebElement getpriceChange(final String cusipName);

    /**
     * Selects 'Group By' option in My Portfolio Holdings.
     *
     * @param viewOption String
     */
    protected abstract void selectMyPortFolioHoldingGroupBy(final String viewOption);

    /**
     * Fetches Total value of all Stocks.
     *
     * @param text String
     * @return Mobile Element
     */
    protected abstract WebElement getTotalValue(final String text);

    /**
     * Fetches description of a Stock.
     *
     * @param text String
     * @return Mobile Element
     */
    protected abstract WebElement getRecordDescription(final String text);

    protected abstract void tapARecordUsingCusip(final String cusipName);

    protected abstract Map<String, String> fetchGainLossDetails();

    /**
     * Taps on Views under Current value tab.
     */
    public void tapViews() {
        getDriver().waitUntilClickable(viewsButton).click();
    }

    /**
     * Taps on Realized G/L Tab.
     */
    public void tapRealizedGainLoss() {
        realizedGainLoss.click();
    }

    /**
     * Taps on Realized G/L Filter ICon.
     */
    public void PortfolioClosingfields() {

        getDriver().waitUntilVisible(realizedGainLossFilterIcon, MAXIMUM_WAIT_TIMEOUT,
                "Filter icon is not Displayed").click();
    }

    /**
     * Taps on Current Value Tab.
     */
    public void tapCurrentValue() {
        currentValueTab.click();
    }

    /**
     * Taps on Unrealized Gain / (Loss).
     */
    protected abstract void tapUnrealizedGainLoss();


    /**
     * Waits for Realzed G/L screen to load.
     */
    protected abstract void waitForRealizedGLToLoad();

    /**
     * Taps on My Portfolio Holdings View.
     */
    public void tapMyPortfolioHoldingsView() {
        myPortfolioHoldingsViewButton.click();
    }

    /**
     * Tap on Gain / Loss under My Portfolio Holdings.
     */
    public void tapGainLoss() {
        gainLossButton.click();
    }

    /**
     * Wait until Holdings description is displayed.
     */
    public void waitUntilHoldingsDescriptionDisplayed() {
        //FIXME: TASK 1354549: waitUntilElementVisible is not working for StaticText. will be fixed once the Ticket is fixed.
        getDriver().waitUntilPresent(holdingDescription, MAXIMUM_WAIT_TIMEOUT);
    }

    /**
     * Taps on Filter button on Current value screen.
     */
    public void tapFilterButton() {
        getDriver().waitUntilClickable(filterButton).click();
    }

    /**
     * Taps on Daily change info icon.
     */
    public void tapDailyChangeInfoButton() {
        getDriver().tap(dailyChangeInfoButton);
    }

    /**
     * Fetches Chips that are applied.
     *
     * @return List of String
     */
    public List<String> fetchChips() {
        return chips.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    /**
     * wait until Current value tab displayed.
     */
    public void waitForCurrentValueTabDisplayed() {
        getDriver().waitUntilVisible(getCurrentValueTab(), MAXIMUM_WAIT_TIMEOUT,
                "Current value tab is not displayed");
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT,
                ExpectedConditions.or(ExpectedConditions.visibilityOf(currentValue),
                        ExpectedConditions.visibilityOf(getTotalText()),
                        ExpectedConditions.visibilityOf(getNoResultsMessage())),
                "Current value screen not displayed.");
    }

    public void verifyNetGainLossTotal() {
        shortTermGainAmt = returnMoneyValue(shortTermGain);
        shortTermLossAmt = returnMoneyValue(shortTermLoss);
        shortTermSubTotalAmt = returnMoneyValue(shortTermSubTotal);
        longTermGainAmt = returnMoneyValue(longTermGain);
        longTermLossAmt = returnMoneyValue(longTermLoss);
        longTermSubTotalAmt = returnMoneyValue(longTermSubTotal);
        netGainLossTotalAmt = returnMoneyValue(netGainLossTotalAmount);

        Assert.assertEquals(Math.round(shortTermGainAmt + shortTermLossAmt), Math.round(shortTermSubTotalAmt), "Short-Term Subtotal amount does not match.");
        Assert.assertEquals(Math.round(longTermGainAmt + longTermLossAmt), Math.round(longTermSubTotalAmt), "Long-Term Subtotal amount does not match.");
        Assert.assertEquals(Math.round(netGainLossTotalAmt), Math.round(longTermSubTotalAmt + shortTermSubTotalAmt), "Net Gain Loss Total amount does not match.");
    }

    public double returnMoneyValue(final WebElement element) {
        Assert.assertTrue(getDriver().scrollTo(element).isDisplayed());
        final String amount = element.getText().trim();
        double value = Double.parseDouble(amount.replaceAll("[$,()&nbsp;\\p{Z}]", ""));
        if (amount.contains("(") && amount.contains(")")) {
            value *= -1;
        }
        return value;
    }

    public void verifyScreenRefresh() throws ParseException {

        final String timeStampBeforeRefresh = currentDateTime.getText().trim().replace("As of ", "");
        getDriver().swipeScreen(Direction.DOWN);
        final String timeStampAfterRefresh = currentDateTime.getText().trim().replace("As of ", "");
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy, hh:mm:ss a");
        Date dateBeforeRefresh = formatter.parse(timeStampBeforeRefresh);
        Date dateAfterRefresh = formatter.parse(timeStampAfterRefresh);
        Assert.assertTrue(dateAfterRefresh.compareTo(dateBeforeRefresh) >= 0, "Refresh was not successful.");
    }

    public void verifyHoldingsWithTotalsSummary() {
        Assert.assertTrue(getDriver().scrollTo(currentValueAmount, Direction.DOWN).isDisplayed());
        final String currentValueAmnt = getDriver().scrollTo(currentValueAmount, Direction.DOWN).getText().trim();
        final String holdingsAmount = getDriver().scrollTo(totalHoldingsAmount, Direction.UP).getText().trim();
        Assert.assertEquals(holdingsAmount, currentValueAmnt, "Position Holdings amount does not match Current Amount.");
    }

    public char returnFirstCharacterByValue(final WebElement element) {
        return element.getAttribute("value").trim().charAt(0);
    }

    public char returnFirstCharacterByText(final WebElement element) {
        return element.getText().trim().charAt(0);
    }
}
