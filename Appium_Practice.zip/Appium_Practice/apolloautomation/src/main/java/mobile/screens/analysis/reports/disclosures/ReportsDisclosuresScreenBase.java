package mobile.screens.analysis.reports.disclosures;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class ReportsDisclosuresScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeStaticText[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"groupLiabilities\")")
    private WebElement disclosuresText;

    protected ReportsDisclosuresScreenBase(final D driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(disclosuresText, MAXIMUM_WAIT_TIMEOUT,
                "Reports Disclosures Screen is not displayed.");
    }
}
