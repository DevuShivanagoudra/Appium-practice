package mobile.screens.twofactorauthentication;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;

import java.util.List;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class TwoFactorAuthenticationScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"Method.*Item\").childSelector(new UiSelector().className(\"android.widget.TextView\"))")
    List<WebElement> methodValueList;

    @HowToUseLocators(iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"Phone Number\"'`]/XCUIElementTypeButton")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name CONTAINS 'key: \"Phone Number\"'`]/XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Phone Number-dropDownIcon\")")
    private WebElement phoneSelectable;

    @HowToUseLocators(iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"Method\"'`]/XCUIElementTypeButton")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name CONTAINS 'key: \"Method\"'`]/XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"MethodoutlineTextField\").childSelector(new UiSelector().resourceId(\"MethodLabel\"))")
    private WebElement methodSelectable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Text - Mobile only\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"Method.*Text\").text(\"Text - Mobile only\")")
    private WebElement textMobileOnly;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Phone\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"Method.*Text\").text(\"Voice\")")
    private WebElement voice;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSwitch[`label == \"Trust this device\"`]/XCUIElementTypeSwitch")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Trust this device-switch\")")
    private WebElement trustThisDevice;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Next\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"submitMfa\")")
    private WebElement submitButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"What you should know\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"What you should know\")")
    private WebElement info;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Back\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-IconButton\")")
    private WebElement backButton;

    protected TwoFactorAuthenticationScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Selects Phone Number, Mode of sending code and 'Remember on device' toggle.
     */
    protected abstract void submit2FASecurity(final String secretAnswer, final String codeSendingMode, final Toggle state);

    /**
     * Sets 'Remember on Device' Toggle.
     *
     * @param toggleState boolean
     */
    protected abstract void setRememberOnDeviceToggle(final boolean toggleState);

    /**
     * Verifies whether Phone number is visible.
     *
     * @param phoneNumber String
     * @return boolean
     */
    protected abstract boolean isPhoneNumberVisible(final String phoneNumber);

    /**
     * Taps on Phone Number dropdown.
     */
    protected abstract void tapPhoneNumberList();

    /**
     * Waits for the Phone Number dropdown to get opened.
     */
    protected abstract void waitForPhoneNumbersToLoad();

    /**
     * Selects phone number from the dropdown.
     *
     * @param phone String
     */
    protected abstract void selectPhoneNumber(final String phone);

    /**
     * Get all the values from the Method dropdown.
     */
    protected abstract List<String> getMethodValues();

    public void tapBackButton() {
        backButton.click();
    }

    public void tapTextMobileOnly() {
        textMobileOnly.click();
    }

    public void tapOnMethodDropdown() {
        methodSelectable.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(info, MAXIMUM_WAIT_TIMEOUT, "2FA Screen is not displayed.");
    }
}
