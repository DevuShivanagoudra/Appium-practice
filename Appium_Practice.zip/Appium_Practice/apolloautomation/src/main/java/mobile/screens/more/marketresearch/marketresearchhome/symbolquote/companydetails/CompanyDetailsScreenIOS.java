package mobile.screens.more.marketresearch.marketresearchhome.symbolquote.companydetails;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class CompanyDetailsScreenIOS extends
        CompanyDetailsScreenBase<IOSCustomDriver> {

    public CompanyDetailsScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
