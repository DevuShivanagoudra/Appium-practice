package mobile.screens.analysis.allocation.disclosures;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class AllocationDisclosuresScreenIOS extends
        AllocationDisclosuresScreenBase<IOSCustomDriver> {

    public AllocationDisclosuresScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
