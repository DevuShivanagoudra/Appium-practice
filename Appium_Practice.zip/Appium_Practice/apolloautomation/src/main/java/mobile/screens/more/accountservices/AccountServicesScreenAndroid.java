package mobile.screens.more.accountservices;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AccountServicesScreenAndroid extends
        AccountServicesScreenBase<AndroidCustomDriver> {

    private static final String SERVICE_LOCATOR = "new UiSelector().text(\"%s\")";

    public AccountServicesScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapService(final String serviceName) {
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(SERVICE_LOCATOR, serviceName))).click();
    }

}
