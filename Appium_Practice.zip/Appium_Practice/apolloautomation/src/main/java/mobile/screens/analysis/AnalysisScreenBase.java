package mobile.screens.analysis;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class AnalysisScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Value Over Time\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-Title-Analysis\")")
    private WebElement title;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Value Over Time\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Value Over Time\")")
    private WebElement valueOverTime;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Market Value\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Market Value\")")
    private WebElement MarketValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Allocation\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Allocation\")")
    private WebElement allocation;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Reports\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Reports\")")
    private WebElement reports;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Disclosures\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Disclosures\")")
    private WebElement disclosures;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Portfolio Value\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Portfolio Value\")")
    private WebElement portfolioValue;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Filter\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"ToFilter\")")
    private WebElement filter;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"End Date\"'`][2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"End Date-dropDownIcon\")")
    private WebElement endDateButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"End Date\"'`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"End Date-dropDownIcon\")")
    private WebElement valueOverTimeEndDateDropDownButton;

    @HowToUseLocators(iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"Fees\"'`]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"End Date\"'`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"End Date-dropUpIcon\")")
    private WebElement valueOverTimeEndDateDropUPButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"Fees\"'`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Fees-dropDownIcon\")")
    private WebElement feesButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Asset Growth\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Asset Growth-expandableSurface\")")
    private WebElement assetGrowthSection;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Previous Business Day\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Previous Business Day\")")
    private WebElement previousBusinessDayButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Previous Month End\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Previous Month End\")")
    private WebElement previousMonthEndButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name== \"updateCustom - PickerOption\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Custom\")")
    private WebElement customButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Market value graph type\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"chartTypeButton\").childSelector(new UiSelector().className(\"android.view.View\"))")
    private WebElement chartTypeButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Amount Invested\"`]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Amount Invested']")
    private WebElement amountInvested;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Value Over Time\"]/..//XCUIElementTypeStaticText[@name=\"Market Value\"]")
    @AndroidFindBy(xpath = "//android.view.View[@index='2']/android.view.View[@resource-id='Value Over Time']//android.widget.TextView[@text='Market Value']")
    private WebElement marketValueGraph;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Begin Date\"`][2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Begin Date\")")
    private WebElement assetBeginDateText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"End Date\"`][2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"End Date\")")
    private WebElement assetEndDateText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Fees\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Fees\")")
    private WebElement assetFeesText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Gross of Fees\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Gross of Fees\")")
    private WebElement grossFeeButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Net of Fees\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Net of Fees\")")
    private WebElement netFeeButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Account Inception\"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Account Inception\")")
    private WebElement assetAccountInceptionText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Account Inception\"`][2]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Account Inception\")")
    private WebElement valueOverTimeAccountInceptionText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Previous Business Day\"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Previous Business Day\")")
    private WebElement valueOverTimePreviousBusinessDayText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"Begin Date\"'`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Begin Date-dropDownIcon\")")
    private WebElement valueOverTimeBeginDateButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Account Inception\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Account Inception\")")
    private WebElement valueOverTimeAccountInceptionButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"Begin Date\"'`]/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Begin DateLabel\")")
    private WebElement valueOverTimeBegindateSelectedOption;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name CONTAINS 'key: \"End Date\"'`]/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"End DateLabel\")")
    private WebElement valueOverTimeEnddateSelectedOption;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Done\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(1)")
    private WebElement okButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Apr 2022\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"End DateLabel\")")
    private WebElement assetEndDateLabel;

    //FIXME: xPaths will be fixed once the ticket "TASK 1293422" is resolved
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Asset Growth\"]/following-sibling::XCUIElementTypeOther[1]/XCUIElementTypeButton/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Previous Business Day\")")
    private WebElement assetPreviousBusinessDayText;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Asset Growth\"]/following-sibling::XCUIElementTypeOther[2]/XCUIElementTypeButton/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Net of Fees\")")
    private WebElement assetNetFeesText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Asset Growth\" AND value ==\"Expanded\" OR value ==\"Collapsed\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().descriptionStartsWith(\"Expandable Arrow\")")
    private WebElement assetGrowthExpandCollapse;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Quarter-to-date\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Asset Growth\").childSelector(new UiSelector().text(\"Quarter-to-date\"))")
    private WebElement quarterToDate;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Year-to-date\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Asset Growth\").childSelector(new UiSelector().text(\"Year-to-date\"))")
    private WebElement yearToDate;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Inception\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Asset Growth\").childSelector(new UiSelector().text(\"Inception\"))")
    private WebElement inception;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Inception\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textStartsWith(\"20\")")
    private WebElement year_Calendar;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Inception\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\").instance(1)")
    private WebElement month_Calendar;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Quarter-to-date\"]/following-sibling::*[1]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'Asset Growth']//*[@text = 'Quarter-to-date']/following-sibling::*[1]")
    private WebElement quarterToDateBeginEndDates;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Quarter-to-date\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.ProgressBar\")")
    private WebElement progressBar;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-IconButton\")")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"More\"`][1]")
    private WebElement backButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Value Over Time\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Value Over Time-expandableSurface\")")
    private WebElement valueOverTimeButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cancel\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(0)")
    private WebElement cancelButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Filter\"]/preceding-sibling::*//XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"Chip.*-Text\")")
    private List<WebElement> chips;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"View\")")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"No results match the selected criteria\"`]")
    private WebElement noResults;

    protected AnalysisScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on Filter icon.
     */
    public void tapFilter() {
        getDriver().waitUntilClickable(filter).click();
    }

    /**
     * Taps on Allocation Tab.
     */
    public void tapAllocation() {
        allocation.click();
    }

    /**
     * Taps on ChartType Button.
     */
    public void tapChartTypeButton() {
        chartTypeButton.click();
    }

    /**
     * Taps on Asset EndDate Button.
     */
    public void tapAssetEndDateButton() {
        getDriver().scrollTo(getFeesButton(), Direction.UP);
        endDateButton.click();
    }

    /**
     * Selects option from Asset Growth End date dropdown.
     *
     * @param option String
     */
    protected abstract void selectAssetGrowthEndDate(final String option);

    /**
     * Selects Custom End date in Asset Growth Section.
     *
     * @param year  String
     * @param month String
     */
    protected abstract void selectAssetGrowthCustomEndDate(final String year, final String month);

    /**
     * Selects Begin date option from dropdown.
     *
     * @param option String
     */
    protected abstract void selectBeginDate(final String option);

    /**
     * Selects Custom Begin date in Asset Growth Section.
     *
     * @param year  String
     * @param month String
     */
    protected abstract void selectCustomBeginDate(final String year, final String month);

    /**
     * Selects option from Value over End date dropdown.
     *
     * @param option String
     */
    protected abstract void selectValueOverEndDate(final String option);

    /**
     * Selects Custom End date in Value over Section.
     *
     * @param year  String
     * @param month String
     */
    protected abstract void selectValueOverCustomEndDate(final String year, final String month);

    /**
     * Check future date is selected or not.
     *
     * @param year
     * @param month
     * @return
     */
    protected abstract boolean isFutureDateAvailable(final String year, final String month);

    /**
     * Selects Year and month from the Calendar.
     *
     * @param year  String
     * @param month String
     */
    protected abstract void selectCustomDate(final String year, final String month);

    /**
     * Selects option from Fees dropdown.
     *
     * @param option String
     */
    protected abstract void selectFees(final String option);

    /**
     * Taps on Value over time End Date Button.
     */
    public void tapEndDateButton() {
        valueOverTimeEndDateDropDownButton.click();
    }

    /**
     * Taps on Business day button.
     */
    public void tapBusinessDayButton() {
        previousBusinessDayButton.click();
    }

    /**
     * Taps on Fees button.
     */
    public void tapFeesButton() {
        feesButton.click();
    }

    /**
     * Taps on Value Over Time Begin Date button.
     */
    public void tapValueBeginDateButton() {
        valueOverTimeBeginDateButton.click();
    }

    /**
     * Taps on Value Over Time Begin Date Account Inception button.
     */
    public void tapValueBeginDateAccountInceptionButton() {
        getDriver().tap(valueOverTimeAccountInceptionButton);
    }

    /**
     * Taps on Custom date.
     *
     * @param month String
     */
    public abstract void tapCustomDate(final String month);

    /**
     * Taps on Custom Date button.
     */
    public void tapCustomButton() {
        customButton.click();
    }

    /**
     * Taps on Custom Date button.
     */
    public void tapCustomCancelButton() {
        cancelButton.click();
    }

    /**
     * Taps on Custom Date OK button.
     */
    public void tapCustomOKButton() {
        okButton.click();
    }

    /**
     * Taps on Asset Growth Expand icon.
     */
    public void tapAssetExpandCollapseIcon() {
        assetGrowthExpandCollapse.click();
    }

    /**
     * Taps on Custom Date OK button.
     */
    public void tapSelectedMonthInCalendar() {
        month_Calendar.click();
    }

    /**
     * Tap on Back button
     */
    public void tapBack() {
        backButton.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(portfolioValue, MAXIMUM_WAIT_TIMEOUT,
                "Allocation tab is not displayed.");
    }

    /**
     * Waits for market value to load.
     */
    public void waitForMarketValue() {
        getDriver().waitUntilVisible(MarketValue, MAXIMUM_WAIT_TIMEOUT,
                "Market value should display.");
    }

    /**
     * Scroll to Asset Growth section.
     */
    public void scrollTillAssetGrowth() {
        getDriver().scrollTo(feesButton, Direction.UP);
    }

    /**
     * Scroll to Value over time section.
     */
    public void scrollTillValueOverTime() {
        getDriver().scrollTo(valueOverTimeButton, Direction.DOWN);
    }
}
