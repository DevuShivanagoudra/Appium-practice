package mobile.screens.accounts.accountdetail;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AccountDetailScreenAndroid extends
        AccountDetailScreenBase<AndroidCustomDriver> {

    public AccountDetailScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapFirstAccount() {
        getFirstAccount().click();
    }

    /**
     * wait until Balance Text is displayed
     */
    public void waitUntilBalanceDisplayed() {
        getBalance().isDisplayed();
    }
}
