package mobile.screens.analysis.reports;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ReportsScreenAndroid extends
        ReportsScreenBase<AndroidCustomDriver> {

    public ReportsScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

}
