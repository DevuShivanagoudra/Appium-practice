package mobile.screens.accounts.accountdetail;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

@Slf4j
@Getter
public class AccountDetailScreenIOS extends AccountDetailScreenBase<IOSCustomDriver> {

    private static final String RECORD_DETAILS = "**/XCUIElementTypeOther[`label == \"%s\"`]";

    public AccountDetailScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapFirstAccount() {
        getFirstAccount().click();
    }

    public WebElement getRecordDetails(final String recordDetails) {
        return getDriver().waitUntilPresent(AppiumBy.iOSClassChain(
                String.format(RECORD_DETAILS, recordDetails)));
    }
}
