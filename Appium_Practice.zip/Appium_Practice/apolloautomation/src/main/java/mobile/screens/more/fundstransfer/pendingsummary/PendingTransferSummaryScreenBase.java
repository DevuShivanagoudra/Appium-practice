package mobile.screens.more.fundstransfer.pendingsummary;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class PendingTransferSummaryScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Updated By\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Updated By\")")
    private WebElement updatedBy;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Status\"]/following-sibling::*")
    @AndroidFindBy(xpath = "//*[@resource-id = 'Status']/following-sibling::*")
    private WebElement status;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cancel\" OR label == \"Back\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(0)")
    private WebElement backButton;

    protected PendingTransferSummaryScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on 'Back' button.
     */
    public void tapBack() {
        backButton.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(updatedBy, MAXIMUM_WAIT_TIMEOUT,
                "Pending Transfer Summary Screen is not displayed.");
    }
}
