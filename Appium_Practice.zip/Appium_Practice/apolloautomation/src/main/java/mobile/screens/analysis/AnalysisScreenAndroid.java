package mobile.screens.analysis;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
public class AnalysisScreenAndroid extends
        AnalysisScreenBase<AndroidCustomDriver> {

    private static final String ENDDATE_OPTION = "new UiSelector().text(\"%s\")";
    private static final String FEES_OPTION = "new UiSelector().text(\"%s\")";
    private static final String CUSTOM_MONTH_LOCATOR = "new UiSelector().text(\"%s\")";
    private static final String YEAR_LOCATOR = CUSTOM_MONTH_LOCATOR;
    private static final String SELECTED_YEAR = "//*[@text = 'Select end date' or @text = 'Select begin date']/following-sibling::*[2]";

    @AndroidFindBy(xpath = "//*[@text = 'Select end date']/following-sibling::android.view.View[1]")
    private WebElement yearContainer;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"ToFilter\")")
    private WebElement filterIcon;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Filter by Accounts\")")
    private WebElement filterByAccounts;

    private By accountsList = By.xpath("//android.widget.CheckBox[not(@content-desc='Assets group')]");
    private By accountsNameList = By.xpath("//android.widget.CheckBox[not(@content-desc='Assets group')]/preceding-sibling::android.widget.TextView");

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-ActionButton-Done\")")
    private WebElement doneButton;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-Title-Filter\")")
    private WebElement filterHeader;

    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Close Dialog\")")
    private WebElement closeDialog;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"All Accounts\")")
    private WebElement filterByAllAccounts;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"All Accounts-switch\")")
    private WebElement allAccountsToggleButton;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"ChipAll Accounts\")")
    private WebElement allAccountsFilterPill;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"primaryTabRow-tab-1Text\")")
    private WebElement reportsTab;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Beginning Market Value\")")
    private WebElement beginningMarketValue;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Contributions/ Withdrawals\")")
    private WebElement contributionsWithdrawals;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Ending Market Value\")")
    private WebElement endingMarketValue;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Investment Results\")")
    private WebElement investmentResults;

    @AndroidFindBy(xpath = "(//*[@text='Year-to-date']//following-sibling::*[@text='Beginning Market Value'])[1]")
    private WebElement yearToDateBeginningMarketValue;

    @AndroidFindBy(xpath = "(//*[@text='Year-to-date']//following-sibling::*[@text='Ending Market Value'])[1]")
    private WebElement yearToDateEndingMarketValue;

    @AndroidFindBy(xpath = "(//*[@text='Year-to-date']//following-sibling::*[@text='Contributions/ Withdrawals'])[1]")
    private WebElement yearToDateContributionsWithdrawals;

    @AndroidFindBy(xpath = "(//*[@text='Year-to-date']//following-sibling::*[@text='Investment Results'])[1]")
    private WebElement yearToDateInvestmentResults;

    @AndroidFindBy(xpath = "(//*[@text='Inception']//following-sibling::*[@text='Beginning Market Value'])[1]")
    private WebElement inceptionBeginningMarketValue;

    @AndroidFindBy(xpath = "(//*[@text='Inception']//following-sibling::*[@text='Ending Market Value'])[1]")
    private WebElement inceptionEndingMarketValue;

    @AndroidFindBy(xpath = "(//*[@text='Inception']//following-sibling::*[@text='Contributions/ Withdrawals'])[1]")
    private WebElement inceptionContributionsWithdrawals;

    @AndroidFindBy(xpath = "(//*[@text='Inception']//following-sibling::*[@text='Investment Results'])[1]")
    private WebElement inceptionInvestmentResults;

    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"Value Over Time\")")
    private WebElement valueOverTime;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"View-dropDownIcon\")")
    private WebElement viewDropDown;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"View-Product Type-Text\")")
    private WebElement viewDropDownProductType;

    private By filterList = By.xpath("//android.view.View[2]/android.widget.Button");
    private By accountNameInFilterScreen = By.xpath("//*[@text='Filter by Accounts']//following-sibling::android.widget.TextView");
    private String productTypeField = "//*[@text='Filter by Accounts']//following-sibling::android.widget.TextView";

    public AnalysisScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void selectAssetGrowthEndDate(final String option) {
        tapAssetEndDateButton();
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(ENDDATE_OPTION, option))).click();
    }

    @Override
    public void selectBeginDate(final String option) {
        tapValueBeginDateButton();
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(ENDDATE_OPTION, option))).click();
    }

    @Override
    public void selectValueOverEndDate(final String option) {
        getValueOverTimeEndDateDropDownButton().click();
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(ENDDATE_OPTION, option))).click();
    }

    @Override
    public void selectAssetGrowthCustomEndDate(final String year, final String month) {
        selectAssetGrowthEndDate("Custom");
        selectCustomDate(year, month);
        getOkButton().click();
        getDriver().waitUntilClickable(getEndDateButton());
    }

    @Override
    public void selectValueOverCustomEndDate(final String year, final String month) {
        selectValueOverEndDate("Custom");
        selectCustomDate(year, month);
        getDriver().waitUntilClickable(getEndDateButton());
    }

    @Override
    public void selectCustomDate(final String year, final String month) {
        getDriver().waitUntilVisible(getYear_Calendar()).click();
        getDriver().swipeScreen(Direction.DOWN);
        getDriver().swipeScreen(Direction.DOWN);
        getDriver().scrollTo(AppiumBy.androidUIAutomator(String.format(YEAR_LOCATOR, year)),
                Direction.UP_SMALL).click();
        getDriver().waitUntilCondition(
                ExpectedConditions.textToBe(By.xpath(SELECTED_YEAR), year));
        getDriver().waitUntilVisible(getMonth_Calendar()).click();
        getDriver().waitUntilVisible(
                        AppiumBy.androidUIAutomator(String.format(CUSTOM_MONTH_LOCATOR, month.toUpperCase())))
                .click();
    }

    @Override
    public void selectCustomBeginDate(final String year, final String month) {
        selectBeginDate("Custom");
        selectCustomDate(year, month);
        getOkButton().click();
        getDriver().waitUntilClickable(getValueOverTimeBeginDateButton());
    }

    @Override
    public void selectFees(String option) {
        tapFeesButton();
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(FEES_OPTION, option))).click();
    }

    @Override
    public void tapCustomDate(final String Month) {
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(CUSTOM_MONTH_LOCATOR, Month))).click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilNotVisible(AppiumBy
                        .androidUIAutomator("new UiSelector().className(\"android.widget.ProgressBar\")"),
                MAXIMUM_WAIT_TIMEOUT);
        ExpectedConditions.or(ExpectedConditions.elementToBeClickable(getPortfolioValue()),
                ExpectedConditions.visibilityOf(getNoResults()));
        getDriver().waitUntilNotVisible(AppiumBy
                        .androidUIAutomator("new UiSelector().className(\"android.widget.ProgressBar\")"),
                MAXIMUM_WAIT_TIMEOUT);
    }

    @Override
    public boolean isFutureDateAvailable(final String year, final String month) {
        try {
            selectCustomDate(year, month);
            return true;
        } catch (NoSuchElementException | TimeoutException e) {
            return false;
        }
    }

    public void validateFiltersAppliedByNumberOfAccounts() {
        getDriver().tap(filterIcon);
        getDriver().waitUntilVisible(filterByAccounts).click();
        if (getDriver().findElements(accountsList).size() > 1) {
            int count = getDriver().findElements(accountsList).size();
            getDriver().findElement(accountsList).click();
            getDriver().tap(doneButton);
            getDriver().waitUntilVisible(filterHeader);
            final String locator = "//*[@text='" + (count - 1) + " accounts selected']";
            By selector = By.xpath(locator);
            Assert.assertTrue(getDriver().isElementVisible(selector), "Number accounts selected does not match.");
        } else {
            getDriver().tap(closeDialog);
            Assert.assertTrue(getDriver().isElementVisible(filterByAllAccounts), "Filter By All accounts is not present.");
        }
    }

    public void validateFilterList() {
        getDriver().waitUntilVisible(filterHeader);
        Assert.assertEquals(getDriver().findElements(filterList).size(), 1, "Filter List does not match.");
    }

    public void validateFilterByAccountName() {
        getDriver().tap(filterByAccounts);
        getDriver().tap(allAccountsToggleButton);
        getDriver().tap(doneButton);
        getDriver().tap(filterByAccounts);
        getDriver().tap(allAccountsToggleButton);
        if (getDriver().findAll(accountsList).size() >= 1) {
            String accountName = getDriver().find(accountsNameList).getText();
            getDriver().findElement(accountsList).click();
            getDriver().tap(doneButton);
            getDriver().waitUntilVisible(filterHeader);
            Assert.assertEquals(getDriver().findElement(accountNameInFilterScreen).getText(), accountName, "Number accounts selected does not match.");
        } else {
            getDriver().tap(closeDialog);
            Assert.assertTrue(getDriver().isElementVisible(filterByAllAccounts), "Filter By All accounts is not present.");
        }
    }

    public void validateAllAccountsFilterPill() {
        getDriver().tap(filterByAccounts);
        getDriver().tap(allAccountsToggleButton);
        getDriver().tap(doneButton);
        Assert.assertTrue(getDriver().isElementVisible(filterByAllAccounts), "Filter By All accounts is not present.");
        getDriver().tap(closeDialog);
        Assert.assertTrue(getDriver().isElementVisible(allAccountsFilterPill), "Account Filter Pill is not present.");
    }

    public void verifyFieldsInReportsTab() {
        getDriver().tap(reportsTab);
        getDriver().scrollTo(investmentResults);
        Assert.assertTrue(getDriver().isElementVisible(beginningMarketValue), "Header: Beginning Market Value in section Quarter To Date is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(contributionsWithdrawals), "Header: Beginning Market Value in section Quarter To Date is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(endingMarketValue), "Header: Beginning Market Value in section Quarter To Date is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(investmentResults), "Header: Beginning Market Value in section Quarter To Date is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(yearToDateBeginningMarketValue), "Header: Beginning Market Value in section Year To Date is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(yearToDateEndingMarketValue), "Header: Beginning Market Value in section Year To Date is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(yearToDateContributionsWithdrawals), "Header: Beginning Market Value in section Year To Date is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(yearToDateInvestmentResults), "Header: Beginning Market Value under Year To Date is not visible.");
        getDriver().scrollTo(valueOverTime);
        Assert.assertTrue(getDriver().isElementVisible(inceptionBeginningMarketValue), "Header: Beginning Market Value in section Inception is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(inceptionEndingMarketValue), "Header: Ending Market Value in section Inception is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(inceptionContributionsWithdrawals), "Header: Contributions/Withdrawals in section Inception is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(inceptionInvestmentResults), "Header: Investment Results in section Inception is not visible.");
    }

    public void verifyFieldsInAllocationTab() {
        getDriver().tap(getAllocation());
        getDriver().tap(viewDropDown);
        getDriver().tap(viewDropDownProductType);
        final List<String> fieldsList = Arrays.asList("Product Type", "Value", "%", "Cash & Cash Alternatives", "Stock", "Partnerships", "Rights/Warrants"
                , "Unit Investment Trusts", "Real Estate Investment Trusts", "Funds", "Market-Linked Investments", "Alternatives"
                , "Derivatives", "Fixed Income Products", "Annuities", "Tangible Assets", "Other Products", "Total Asset Value", "Total Value");
        for (String field : fieldsList) {
            By element = (By.xpath("//*[@text='" + field + "']"));
            getDriver().scrollTo(element);
            Assert.assertTrue(getDriver().isElementVisible(element), "Field : " + field + "is not present.");
        }
    }
}
