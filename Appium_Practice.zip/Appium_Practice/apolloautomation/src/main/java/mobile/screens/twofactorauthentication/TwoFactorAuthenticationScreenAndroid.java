package mobile.screens.twofactorauthentication;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.android.AndroidUtils;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class TwoFactorAuthenticationScreenAndroid extends
        TwoFactorAuthenticationScreenBase<AndroidCustomDriver> {

    private static final String PHONE_LOCATOR = "new UiSelector().className(\"android.widget.TextView\").text(\"XXX-XXX-%s\")";
    private static final String MODE_LOCATOR = "new UiSelector().textStartsWith(\"%s\")";

    public TwoFactorAuthenticationScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void submit2FASecurity(final String phone, final String codeSendingMode, final Toggle rememberOnDevice) {
        if (!isPhoneNumberVisible(phone)) {
            getPhoneSelectable().click();
            waitForPhoneNumbersToLoad();
        }
        selectPhoneNumber(phone);
        getMethodSelectable().click();
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(MODE_LOCATOR, codeSendingMode))).click();
        if (getDriver().isElementVisible(getTrustThisDevice())) {
            setRememberOnDeviceToggle(rememberOnDevice.getBoolValue());
        }
        getSubmitButton().click();
    }

    @Override
    public void tapPhoneNumberList() {
        getPhoneSelectable().click();
    }

    @Override
    public void selectPhoneNumber(final String phone) {
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(PHONE_LOCATOR, phone))).click();
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(MODE_LOCATOR, "Text")));
    }

    @Override
    public List<String> getMethodValues() {
        return getMethodValueList()
                .stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    @Override
    public void waitForPhoneNumbersToLoad() {
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(MODE_LOCATOR, "XXX-")));
    }

    @Override
    public boolean isPhoneNumberVisible(final String phoneNumber) {
        return getDriver().isElementVisible(
                AppiumBy.androidUIAutomator(String.format(PHONE_LOCATOR, phoneNumber)));
    }

    @Override
    protected void setRememberOnDeviceToggle(final boolean toggleState) {
        AndroidUtils.setCheckBox(getDriver(), getTrustThisDevice(), toggleState);
    }
}
