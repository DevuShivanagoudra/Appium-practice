package mobile.screens.more.vault;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.constants.ElementDirection;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class VaultScreenAndroid extends
        VaultScreenBase<AndroidCustomDriver> {

    private static final String RECORD_SWIPE_LOCATOR = "//android.widget.TextView[@text = '%s']/..";
    private static final String RECORD_LOCATOR = "new UiSelector().resourceId(\"clickSurface\").childSelector(new UiSelector().textStartsWith(\"%s\"))";
    private static final String RECORD_INFO_LOCATOR = "//*[@resource-id = '%s']/../following-sibling::*/*[@resource-id = 'Folder Information']";
    private static final String ACCOUNT_LOCATOR = "new UiSelector().resourceId(\"name\")";
    private static final String VAULT_DETAILS = "//android.view.View[@resource-id = '%s']/android.widget.TextView";

    @HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Description (Optional)\")")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Description-EditField\")")
    private WebElement descriptionEditable;

    public VaultScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public List<String> getAddItemOptions() {
        return getAddItemOptionsList()
                .stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    @Override
    public void enterFolderDetails(final String name, final String description) {
        getDriver().waitUntilClickable(getFolderNameEditable()).sendKeys(name);
        getDriver().waitUntilClickable(getDescriptionEditable()).sendKeys(description);
    }

    @Override
    public void tapFolderInfo(final String folderName) {
        getDriver().scrollTo(
                AppiumBy.androidUIAutomator(String.format(RECORD_LOCATOR, folderName)),
                Direction.UP_SMALL, 20);
        WebElement element = getDriver().waitUntilVisible(
                By.xpath(String.format(RECORD_SWIPE_LOCATOR, folderName)));
        getDriver().swipeElement(element, ElementDirection.LEFT);
        getDriver().waitUntilVisible(
                By.xpath(String.format(RECORD_INFO_LOCATOR, folderName))).click();
    }

    @Override
    public void tapFolder(final String folderName) {
        getDriver().scrollTo(
                AppiumBy.androidUIAutomator(String.format(RECORD_LOCATOR, folderName)),
                Direction.UP_SMALL,
                20).click();
    }

    @Override
    public void waitForFolderToLoad(final String folderName) {
        getDriver().waitUntilPresent(
                AppiumBy.androidUIAutomator(String.format(RECORD_LOCATOR, folderName)),
                MAXIMUM_WAIT_TIMEOUT);
    }

    @Override
    public boolean isFolderVisible(final String folderName) {
        return getDriver().isElementVisible(
                AppiumBy.androidUIAutomator(String.format(RECORD_LOCATOR, folderName)));
    }

    @Override
    public List<String> getVaultDetails(final String selectedVault) {
        List<WebElement> vaultDetails = getDriver().findElements(
                By.xpath(String.format(VAULT_DETAILS, selectedVault)));
        return vaultDetails.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    /**
     * Fills Description field.
     *
     * @param description string
     */
    public void enterDescription(final String description) {
        getDriver().waitUntilClickable(getDescriptionEditable()).sendKeys(description);
    }
}
