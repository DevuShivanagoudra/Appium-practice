package mobile.screens.codeinputscreen;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CodeInputScreenAndroid extends
        CodeInputScreenBase<AndroidCustomDriver> {

    public CodeInputScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    /**
     * Submits default Answer on Secret Question screen.
     */
    @Override
    public void submitCode(final String code) {
        getDriver().waitUntilClickable(getCodeInputEditable()).sendKeys(code);
    }
}
