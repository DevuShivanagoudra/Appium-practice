package mobile.screens.more.marketresearch.marketresearchhome.symbolquote;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class SymbolQuoteScreenIOS extends
        SymbolQuoteScreenBase<IOSCustomDriver> {

    public SymbolQuoteScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void enterDataInSearchBar(String companyName) {
        getDriver().replaceText(getSearchBar(), companyName);
    }

    @Override
    public WebElement fetchNoRecordsMessage() {
        return getDriver().waitUntilVisible(getNoRecords(),
                MAXIMUM_WAIT_TIMEOUT, "No Records Message is not displayed.");
    }
}
