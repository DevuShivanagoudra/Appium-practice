package mobile.screens.more;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class MoreScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTable/XCUIElementTypeCell/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"moreScreen-title\")")
    protected List<WebElement> tabBarContainer;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeNavigationBar/**/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-Title-More\")")
    private WebElement title;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Notifications\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Notifications\")")
    private WebElement lastOption;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Edit\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-ActionButton-Edit\")")
    private WebElement editButton;

    protected MoreScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Fetches More Screen options as list.
     *
     * @return list of String
     */
    protected abstract List<String> getTabBarNames();

    /**
     * Taps on more screen Option.
     */
    protected abstract void tapMoreOption(final String moreOption);

    /**
     * Taps on Edit button.
     */
    public void tapEdit() {
        editButton.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(lastOption, MAXIMUM_WAIT_TIMEOUT,
                "More Screen is not displayed.");
    }
}
