package mobile.screens.dashboard;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class DashboardScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"slider.vertical.3\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-ActionButton-Edit\")")
    private WebElement editButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeNavigationBar/**/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"TopBar-Title.*\")")
    private WebElement title;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Dashboard\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Dashboard\")")
    private WebElement dashboardHeader;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeCell[`label BEGINSWITH[cd] \"Net Balance\"`]/**/XCUIElementTypeStaticText[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.ScrollView\").childSelector(new UiSelector().textMatches(\".*Balance\"))")
    private WebElement balanceLabel;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Total Assets\")")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"My Holdings\"`]")
    private WebElement totalAssets;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Customize\")")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Customize\"`]")
    private WebElement customize;

    @AndroidFindBy(xpath = "//*[@text='Go to Portfolio']/following-sibling::android.widget.Button")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"portfolio\"]//following-sibling::XCUIElementTypeImage)[1]")
    private WebElement myHoldingsSection;

    @AndroidFindBy(xpath = "//*[@text='Go to All Accounts']/following-sibling::android.widget.Button")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"myAccounts\"]//following-sibling::XCUIElementTypeImage)[1]")
    private WebElement myAccountsSection;

    @AndroidFindBy(xpath = "//*[@text='Go to Activity']/following-sibling::android.widget.Button")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"activity\"]//following-sibling::XCUIElementTypeImage)[1]")
    private WebElement recentActivitySection;

    @AndroidFindBy(xpath = "//*[@text='Go to Accounts']/following-sibling::android.widget.Button")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"cash\"]//following-sibling::XCUIElementTypeImage)[1]")
    private WebElement cashSection;

    @AndroidFindBy(xpath = "//*[@text='Go to Analysis']/following-sibling::android.widget.Button")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"allocations\"]//following-sibling::XCUIElementTypeImage)[1]")
    private WebElement assetAllocationSection;

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc=\"My Holdings\"]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"portfolio\"]")
    private WebElement myHoldingsCheckbox;

    @AndroidFindBy(xpath = "//*[@text=\"My Holdings\"]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"My Holdings\"  and @visible=\"true\"])")
    private WebElement myHoldingsLabel;

    @AndroidFindBy(xpath = "//*[@resource-id='TopBar-ActionButton-Done']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Done\"]")
    private WebElement customiseDashboardDoneButton;

    protected DashboardScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on the Edit button.
     */
    public void tapEdit() {
        editButton.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilPresent(totalAssets, MAXIMUM_WAIT_TIMEOUT);
    }

    public void verifyWidgetsInGrid() {
        getDriver().scrollTo(getCustomize()).click();
        Assert.assertTrue(getDriver().isElementVisible(myHoldingsSection), "My Holdings section is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(myAccountsSection), "My Accounts section is not visible.");
        getDriver().scrollTo(cashSection);
        Assert.assertTrue(getDriver().isElementVisible(recentActivitySection), "Recent Activity section is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(cashSection), "Cash section is not visible.");
        Assert.assertTrue(getDriver().isElementVisible(assetAllocationSection), "Asset Allocation section is not visible.");
    }
}
