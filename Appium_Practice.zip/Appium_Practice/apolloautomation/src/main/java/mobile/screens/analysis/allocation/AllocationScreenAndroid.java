package mobile.screens.analysis.allocation;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AllocationScreenAndroid extends
        AllocationScreenBase<AndroidCustomDriver> {

    private static final String VIEW_TYPE = "new UiSelector().resourceId(\"View-%s-Text\")";

    public AllocationScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void selectViewType(final String viewType) {
        getDriver().scrollTo(getViewType(), Direction.DOWN).click();
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(VIEW_TYPE, viewType))).click();
        getDriver().waitUntilClickable(getViewType());
    }


}
