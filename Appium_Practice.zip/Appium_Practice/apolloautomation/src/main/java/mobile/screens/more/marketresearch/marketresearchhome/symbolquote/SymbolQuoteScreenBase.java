package mobile.screens.more.marketresearch.marketresearchhome.symbolquote;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class SymbolQuoteScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Symbol Quote\"`]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'primaryTabRow-tab-1Text']/..")
    private WebElement symbolQuoteTab;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Symbol/Company Name\")")
    private WebElement searchBar;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"X Circle\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"clearTextIconButton\")")
    private WebElement clearSearchBar;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"No records matched at this time.\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"No results matched at this time\")")
    private WebElement noRecords;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeCell/**/XCUIElementTypeButton")
    @AndroidFindBy(xpath = "//*[@resource-id = 'Symbol/Company Name']/../following-sibling::android.view.View")
    private List<WebElement> searchResults;

    protected SymbolQuoteScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Enter data in Search bar.
     *
     * @param companyName String
     */
    protected abstract void enterDataInSearchBar(final String companyName);

    /**
     * Taps on "x" button of Search bar.
     */
    public void tapClearSearchBar() {
        clearSearchBar.click();
    }

    /**
     * Fetches 'No Records found' error message.
     *
     * @return
     */
    protected abstract WebElement fetchNoRecordsMessage();

    /**
     * s Taps lts.on first record in the resultss
     */
    public void tapFirstRecordInResults() {
        getDriver().waitUntilClickable(clearSearchBar, MAXIMUM_WAIT_TIMEOUT,
                "Clear button is not clickable.");
        searchResults.get(0).click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(searchBar, MAXIMUM_WAIT_TIMEOUT,
                "Market Research Screen is not displayed.");
    }
}
