package mobile.screens.more.marketresearch.marketresearchhome;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class MarketResearchScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Commentary\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Commentary\")")
    private WebElement commentary;

    protected MarketResearchScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on the Market Research option.
     *
     * @param option String
     */
    protected abstract void tapOption(final String option);

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(commentary, MAXIMUM_WAIT_TIMEOUT,
                "Market Research Screen is not displayed.");
    }
}
