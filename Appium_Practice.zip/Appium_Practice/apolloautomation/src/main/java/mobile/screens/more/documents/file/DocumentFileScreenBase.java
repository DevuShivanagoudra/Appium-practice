package mobile.screens.more.documents.file;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class DocumentFileScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"View Document\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.android.printspooler:id/title\")")
    protected WebElement title;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label BEGINSWITH[cd] \"MDL: \"`][1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.android.printspooler:id/page_content\")")
    private WebElement pageContent;

    protected DocumentFileScreenBase(final D driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(title, MAXIMUM_WAIT_TIMEOUT,
                "Print File Screen is not displayed.");
        getDriver().waitUntilPresent(getPageContent(), MAXIMUM_WAIT_TIMEOUT);
    }
}
