package mobile.screens.more.documents;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;

@Slf4j
@Getter
public class DocumentsScreenIOS extends DocumentsScreenBase<IOSCustomDriver> {

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Filter\"]/../XCUIElementTypeStaticText")
    private List<WebElement> recordsList;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"All Accounts\"`]")
    private WebElement allAccountsChip;

    public DocumentsScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
