package mobile.screens.more.documents.filter;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Getter
public class DocumentsFilterScreenAndroid extends
        DocumentsFilterScreenBase<AndroidCustomDriver> {

    private static final String DOCUMENTTYPE_LOCATOR = "new UiSelector().className(\"android.widget.ScrollView\").childSelector(new UiSelector().text(\"%s\"))";
    private static final String YEAR_LOCATOR = "new UiSelector().className(\"android.widget.ScrollView\").childSelector(new UiSelector().text(\"%s\"))";
    private static final String SELECTED_LOCATOR = "new UiSelector().text(\"%s\").fromParent(new UiSelector().className(\"android.view.View\"))";
    private static final String YEARSELECTED_LOCATOR = SELECTED_LOCATOR;
    private static final String ACCOUNTNAMES_LOCATOR = "//android.widget.CheckBox/preceding-sibling::android.widget.TextView";

    @AndroidFindBy(xpath = "//*[@resource-id = 'Accounts']/following-sibling::android.view.View[2]//android.widget.TextView")
    private List<WebElement> accountsList;

    @AndroidFindBy(xpath = "//android.widget.ScrollView/android.view.View[2]//android.widget.TextView[1]")
    private List<WebElement> accountSelected;

    @AndroidFindBy(xpath = "//android.widget.ScrollView/android.view.View[2]/android.view.View")
    private List<WebElement> accountSelectedIcon;

    public DocumentsFilterScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public boolean isDocumentTypeVisible(final String documentType) {
        return getDriver().isElementVisible(AppiumBy.androidUIAutomator(String.format(
                DOCUMENTTYPE_LOCATOR, documentType)));
    }

    @Override
    public boolean isDocumentTypeSelected(String documentType) {
        return getDriver().isElementVisible(AppiumBy.androidUIAutomator(String.format(
                SELECTED_LOCATOR, documentType)));
    }

    @Override
    public void selectDocumentType(final String documentType) {
        getDriver().waitUntilVisible(AppiumBy.androidUIAutomator(String.format(
                DOCUMENTTYPE_LOCATOR, documentType))).click();
    }

    @Override
    public void selectYear(final String year) {
        getDriver().scrollTo(AppiumBy.androidUIAutomator(String.format(
                YEAR_LOCATOR, year))).click();
    }

    public boolean isYearSelected(final String year) {
        getDriver().swipeScreen(Direction.UP);
        return getDriver().isElementVisible(
                AppiumBy.androidUIAutomator(String.format(YEARSELECTED_LOCATOR, year)));
    }

    @Override
    public void verifyAccountsSelected() {
        List<String> accounts = accountsList.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        for (String account : accounts) {
            Assert.assertTrue(getDriver().isElementVisible(
                            AppiumBy.androidUIAutomator(String.format(SELECTED_LOCATOR, account))),
                    String.format("Account %s is not selected.", account));
        }
    }

    @Override
    public void waitUntilAccountsLoaded() {
        getDriver().waitUntilCondition(
                ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(ACCOUNTNAMES_LOCATOR), 2));
    }
}
