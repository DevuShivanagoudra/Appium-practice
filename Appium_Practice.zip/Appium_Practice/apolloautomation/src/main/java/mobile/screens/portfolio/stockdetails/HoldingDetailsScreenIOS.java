package mobile.screens.portfolio.stockdetails;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class HoldingDetailsScreenIOS extends
        HoldingDetailsScreenBase<IOSCustomDriver> {

    public HoldingDetailsScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
