package mobile.screens.analysis.filter;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static jarvis.mobile.appium.Utils.letScreenSettle;
import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class AnalysisFilterScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    List<String> accountGroupsNames = Arrays.asList("Assets", "Closed Accounts", "Liabilities");

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeStaticText[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(0)")
    private WebElement accountsSection;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Assets\" OR label == \"Closed Accounts\" OR label == \"Liabilities\"`]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Assets' or @text = 'Closed Accounts' or @text = 'Liabilities']")
    private List<WebElement> accountGroups;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Value Over Time\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"group.*\")")
    private List<WebElement> groupIcon;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Done\"`]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Done']/..")
    private WebElement doneButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Liabilities\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Liabilities\")")
    private WebElement liabilitiesGroup;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label BEGINSWITH[cd] \"Select Accounts\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Liabilities\")")
    private WebElement allAccounts;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Please select at least one (1) account\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Liabilities\")")
    private WebElement noAccountSelectedErrorMessage;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"All Accounts\" OR label BEGINSWITH \"Accounts (\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Filter by Accounts\")")
    private WebElement filterByAccounts;

    protected AnalysisFilterScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on Back button.
     */
    protected abstract void tapBack();

    /**
     * Taps on Done button.
     */
    public void tapDone() {
        doneButton.click();
    }

    /**
     * Taps on 'All Accounts' button.
     */
    public void tapAllAccounts() {
        allAccounts.click();
    }

    /**
     * Taps on 'Filter By Accounts' button.
     */
    public void tapFilterByAccounts() {
        getDriver().waitUntilClickable(filterByAccounts).click();
    }

    /**
     * Fetches Selected Icon of a Account.
     *
     * @param accountName String
     * @return Mobile Element
     */
    protected abstract WebElement getAccountSelectedIcon(final String accountName);

    /**
     * Select/UnSelect an account.
     *
     * @param accountName String
     */
    protected abstract void selectDeselectAccount(final String accountName, final boolean state);

    /**
     * Verifies whether an account is selected.
     *
     * @param accountName String.
     * @return boolean
     */
    protected abstract boolean isAccountSelectedIconVisible(final String accountName);

    /**
     * Waits until Liabilites group is loaded.
     */
    protected abstract void waitUntilAccountsLoaded();

    /**
     * Fetches list of Account groups.     *
     *
     * @return List of String
     */
    public List<String> fetchAccountGroups() {
        return getAccountGroups()
                .stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(accountsSection, MAXIMUM_WAIT_TIMEOUT,
                "Analysis Filter Screen is not displayed.");
    }

    public void waitForFiltersToLoad() {
        letScreenSettle(Duration.ofSeconds(4));
        getDriver().waitUntilClickable(filterByAccounts, MAXIMUM_WAIT_TIMEOUT,
                "Analysis Filters Screen is not displayed.");
    }
}
