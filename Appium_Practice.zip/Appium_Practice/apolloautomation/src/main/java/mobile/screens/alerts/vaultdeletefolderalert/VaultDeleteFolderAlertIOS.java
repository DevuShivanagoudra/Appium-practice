package mobile.screens.alerts.vaultdeletefolderalert;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.screens.alerts.AlertDialogBase;

@Slf4j
@Getter
public class VaultDeleteFolderAlertIOS extends
        AlertDialogBase<IOSCustomDriver> {

    public VaultDeleteFolderAlertIOS(final IOSCustomDriver driver) {
        super(driver);
    }
}
