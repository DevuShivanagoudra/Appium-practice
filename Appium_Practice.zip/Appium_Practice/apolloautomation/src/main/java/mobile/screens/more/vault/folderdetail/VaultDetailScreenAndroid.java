package mobile.screens.more.vault.folderdetail;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.screens.more.vault.VaultScreenAndroid;

@Slf4j
@Getter
public class VaultDetailScreenAndroid extends
        VaultScreenAndroid {

    public VaultDetailScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
