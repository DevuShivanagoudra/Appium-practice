package mobile.screens.disclosures;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class FeatureDisclosuresScreenAndroid extends
        FeatureDisclosuresScreenBase<AndroidCustomDriver> {

    private static final String CHILD_LOCATOR = "new UiSelector().className(\"android.widget.TextView\")";

    public FeatureDisclosuresScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    /**
     * Fetches Disclosures text.
     *
     * @return List of string
     */
    public List<String> getDisclosuresTexts() {
        List<WebElement> elements = getDriver().findAll(getDisclosuresText(),
                AppiumBy.androidUIAutomator(CHILD_LOCATOR));
        return elements.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }
}
