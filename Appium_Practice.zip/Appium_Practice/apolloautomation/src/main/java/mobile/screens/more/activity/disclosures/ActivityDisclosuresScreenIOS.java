package mobile.screens.more.activity.disclosures;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class ActivityDisclosuresScreenIOS extends
        ActivityDisclosuresScreenBase<IOSCustomDriver> {

    public ActivityDisclosuresScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
