package mobile.screens.f5access;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class F5AccessScreenIOS extends F5AccessScreenBase<IOSCustomDriver> {


    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Buttons\"`]")
    private WebElement buttons;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"UIKitCatalog\"`]")
    private WebElement uiKitCatalog;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Page Control\"`]")
    private WebElement pageControl;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSwitch")
    private WebElement connectionToggle;

    public F5AccessScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    /**
     * Taps on OK button.
     */
    public void tapButtons() {
        buttons.click();
    }

    /**
     * Taps on OK button.
     */
    public void tapPageControl() {
        pageControl.click();
    }

    /**
     * Taps on App button.
     */
    public void tapUiKitCatalog() {
        uiKitCatalog.click();
    }

    @Override
    public void getConnection() {
        getDriver().waitUntilVisible(getStatusLabel(), MAXIMUM_WAIT_TIMEOUT,
                "V5 access is not opened yet.");
        if (connectionToggle.getAttribute("value").equals("0")) {
            log.info("Trying to connect to F5 Access.");
            connectionToggle.click();
            getDriver().waitUntilCondition(
                    ExpectedConditions.attributeToBe(connectionToggle, "value", "1"));
            getDriver().waitUntilVisible(getConnectionStatus(), MAXIMUM_WAIT_TIMEOUT,
                    "Connection failed.");
            log.info("F5 Access connection successful.");
        } else {
            log.info("F5 Access connection already connected.");
        }
    }
}
