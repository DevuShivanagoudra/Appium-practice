package mobile.screens.portfolio.portfoliofilter;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.appium.SwipeAction;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.ios.IOSUtils;
import mobile.common.constants.Toggle;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Getter
public class PortfolioFilterScreenIOS extends
        PortfolioFilterScreenBase<IOSCustomDriver> {

    private static final String GAINLOSS_LOCATOR = "**/XCUIElementTypeButton[`label == \"%s\"`]";
    private static final String FILTEROPTION_SELECTED_LOCATOR = "**/XCUIElementTypeButton[`label == \"%s\"`]/XCUIElementTypeImage";
    private static final String SELECTED_LOCATOR = "**/XCUIElementTypeScrollView[1]/**/XCUIElementTypeOther[`label == \"%s\"`]/XCUIElementTypeImage";
    private static final String ACCOUNTNAMES_LOCATOR = "**/XCUIElementTypeScrollView[1]/**/XCUIElementTypeButton[`label == \"%s\"`]";
    private static final String ACCOUNT_LOCATOR = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";
    private static final String EXPANDCOLLAPSE_SECURITYGROUP_LOCATOR = "//XCUIElementTypeStaticText[@name=\"%s\"]/following-sibling::XCUIElementTypeButton";

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypePickerWheel[1]")
    private WebElement monthPicker;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypePickerWheel[2]")
    private WebElement yearPicker;

    @HowToUseLocators(iOSXCUITAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`name CONTAINS 'key: \"Current Value\"'`]/XCUIElementTypeButton/XCUIElementTypeStaticText")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView[1]/**/XCUIElementTypeOther/XCUIElementTypeStaticText")
    private List<WebElement> accountsList;

    public PortfolioFilterScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    public void setAllSecurities(final boolean state) {
        IOSUtils.setRadioToggle(getDriver(), getAllSecuritiesToggle(), state);
    }

    @Override
    public void selectGainLossType(final String viewOption) {
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(GAINLOSS_LOCATOR, viewOption))).click();
    }

    @Override
    public void expandCollapseSecurityGroup(final String securityGroupName) {
        By by = By.xpath(String.format(EXPANDCOLLAPSE_SECURITYGROUP_LOCATOR, securityGroupName));
        final WebElement expandButton = getDriver().waitUntilVisible(by);
        expandButton.click();
        getDriver().waitUntilClickable(expandButton);
    }

    @Override
    public List<String> fetchAccounts() {
        List<String> accounts = accountsList.stream()
                .map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
        accounts.removeAll(getAccountGroupsNames());
        return accounts;
    }

    @Override
    protected void deSelectAllAccounts() {
        List<String> accounts = accountsList.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        for (String account : accounts) {
            if (getDriver().isElementVisible(
                    AppiumBy.iOSClassChain(String.format(SELECTED_LOCATOR, account)))) {
                getDriver().waitUntilVisible(
                        AppiumBy.iOSClassChain(String.format(ACCOUNT_LOCATOR, account))).click();
            }
        }
    }

    @Override
    public void tapAllSecurities(final Toggle state) {
        IOSUtils.setToggle(getDriver(), getAllSecuritiesToggle(), state.getBoolValue());
    }

    @Override
    public List<String> getSecurityGroupsList() {
        return getSecurityGroups().stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    public void selectDeselectAccount(final String accountName, final boolean state) {
        int i = 0;
        while ((state && !getDriver().waitUntilVisible(
                        AppiumBy.iOSClassChain(String.format(SELECTED_LOCATOR, accountName)))
                .getAttribute("label").equalsIgnoreCase("Selected") ||
                !state && !getDriver().waitUntilVisible(
                                AppiumBy.iOSClassChain(String.format(SELECTED_LOCATOR, accountName)))
                        .getAttribute("label").equalsIgnoreCase("Square")) && i < 2) {
            getDriver().waitUntilVisible(
                    AppiumBy.iOSClassChain(String.format(ACCOUNT_LOCATOR, accountName))).click();
        }
    }

    @Override
    public void verifyAccountsSelected() {
        List<String> accounts = getAccountsList().stream()
                .map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
        accounts.removeAll(getAccountGroupsNames());
        for (String account : accounts) {
            Assert.assertTrue(getDriver().isElementVisible(
                            AppiumBy.iOSClassChain(String.format(SELECTED_LOCATOR, account))),
                    String.format("Account %s is not selected.", account));

        }
    }

    public void verifySecurityGroupNotDisplayed(final String securityGroup) {
        List<String> Securities = getSecurityGroups().stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        Assert.assertFalse(Securities.contains(securityGroup),
                String.format("Security Group %s is displayed.", securityGroup));
    }

    public boolean isAccountSelected(final String accountName) {
        return getDriver().waitUntilVisible(AppiumBy.iOSClassChain(
                        String.format(SELECTED_LOCATOR, accountName))).getAttribute("label")
                .equalsIgnoreCase("Selected");
    }

    public boolean isOptionSelected(final String option) {
        return getDriver().waitUntilVisible(AppiumBy.iOSClassChain(
                        String.format(FILTEROPTION_SELECTED_LOCATOR, option))).getAttribute("label")
                .equalsIgnoreCase("Selected");
    }

    public boolean isOptionVisible(final String option) {
        return getDriver()
                .isElementVisible(AppiumBy.iOSClassChain(String.format(GAINLOSS_LOCATOR, option)));
    }

    public void selectClosingDate(final String year, final String month) {
        getClosingdateFromSelectable().click();
        getYearDropdown().click();
        //FIXME: SetValue is not working for PickerWheel Element.
        Point fromPoint = new Point(yearPicker.getLocation().getX(),
                yearPicker.getLocation().getY());
        Point toPoint = new Point(yearPicker.getLocation().getX(),
                yearPicker.getLocation().getY() + 50);
        SwipeAction.swipe(getDriver(), fromPoint, toPoint);
        getDriver().tap(getClosingdateFromSelectable());
    }

    public void verifyDatesSelected() {
        getClosingdateFromSelectable().click();
        getFromDateSelectedFilterScreen().click();
        getDriver().swipeScreen(5, 10);
        getClosingdateToSelectable().click();
        getDoneButton().click();
    }
}
