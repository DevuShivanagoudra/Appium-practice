package mobile.screens.more.marketresearch.marketresearchhome;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class MarketResearchScreenAndroid extends
        MarketResearchScreenBase<AndroidCustomDriver> {

    private static final String OPTION_LOCATOR = "new UiSelector().text(\"%s\")";

    public MarketResearchScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapOption(final String option) {
        getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(OPTION_LOCATOR, option))).click();
    }
}
