package mobile.screens.accounts;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.constants.ElementDirection;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;

@Slf4j
public class AccountsScreenAndroid extends
        AccountsScreenBase<AndroidCustomDriver> {

    private static final String RECORD_LOCATOR = "new UiSelector().textStartsWith(\"%s\")";
    private static final String RECORD_SWIPE_LOCATOR = "new UiSelector().text(\"%s\").fromParent(new UiSelector().className(\"android.widget.Button\"))";
    private static final String RECORD_INFO_LOCATOR = "//*[@resource-id = '%s']/../following-sibling::*/*[@resource-id = 'Info']";
    private static final String ACCOUNT_LOCATOR = "new UiSelector().resourceId(\"name\")";
    private static final String AUTHORIZED_REPRESENTATIVE = "new UiSelector().text(\"%s\").fromParent(new UiSelector().className(\"android.view.View\"))";

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Assets\")")
    private WebElement assetAccounts;

    @AndroidFindBy(xpath = "//*[matches(@resource-id,'Liabilities.*expandableSurface')]/following-sibling::*/android.view.View")
    private List<WebElement> liabilityAccounts;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Assets-expandableSurface\")")
    private WebElement assetsSection;

    public AccountsScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapFirstAccount() {
        getFirstAccount().click();
    }

    @Override
    public void tapAccount(final String accountName) {
        selectAccount(accountName);
    }

    /**
     * Fetches Asset Accounts.
     *
     * @return List of Elements
     */
    public List<WebElement> fetchAssetAccounts() {
        return getDriver()
                .findAll(assetAccounts, AppiumBy.androidUIAutomator(ACCOUNT_LOCATOR));
    }

    /**
     * Fetches Liabilities Accounts.
     *
     * @return List of Elements
     */
    public List<WebElement> fetchLiabilitiesAccounts() {
        getDriver().scrollTo(getLiabilitiesSection());
        getDriver().swipeScreen(Direction.UP);
        return liabilityAccounts;
    }

    @Override
    public void selectAccount(final String accountName) {
        getDriver().scrollTo(
                AppiumBy.androidUIAutomator(String.format(RECORD_LOCATOR, accountName)),
                Direction.UP_SMALL, 20);
        WebElement element = getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(RECORD_SWIPE_LOCATOR, accountName)));
        getDriver().swipeElement(element, ElementDirection.LEFT);
        getDriver().waitUntilVisible(
                By.xpath(String.format(RECORD_INFO_LOCATOR, accountName))).click();
    }

    /**
     * Verifies whether Info icon is available for an Account.
     *
     * @param accountName String
     * @return boolean
     */
    public boolean isInfoIconVisible(final String accountName) {
        AppiumBy by = (AppiumBy) AppiumBy
                .androidUIAutomator(String.format(RECORD_LOCATOR, accountName));
        getDriver().scrollTo(by, Direction.UP_SMALL, 20);
        WebElement element = getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(RECORD_SWIPE_LOCATOR, accountName)));
        getDriver().swipeElement(element, ElementDirection.LEFT);

        return getDriver()
                .isElementVisible(By.xpath(String.format(RECORD_INFO_LOCATOR, accountName)));
    }

    @Override
    public void verifyAuthorizedRepresentativeVisible(final String accountName) {
        Assert.assertTrue(getDriver().scrollTo(
                                AppiumBy.androidUIAutomator(String.format(AUTHORIZED_REPRESENTATIVE, accountName)))
                        .isDisplayed(),
                String.format("Authorized Representative Icon is not visible", accountName));
    }
}
