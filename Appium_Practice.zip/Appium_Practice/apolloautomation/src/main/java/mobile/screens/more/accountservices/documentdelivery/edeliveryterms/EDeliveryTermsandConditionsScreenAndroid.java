package mobile.screens.more.accountservices.documentdelivery.edeliveryterms;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EDeliveryTermsandConditionsScreenAndroid extends
        EDeliveryTermsandConditionsScreenBase<AndroidCustomDriver> {

    public EDeliveryTermsandConditionsScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
