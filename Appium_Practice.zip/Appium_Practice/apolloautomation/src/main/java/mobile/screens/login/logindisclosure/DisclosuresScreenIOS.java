package mobile.screens.login.logindisclosure;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class DisclosuresScreenIOS extends DisclosuresScreenBase<IOSCustomDriver> {

    public DisclosuresScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
