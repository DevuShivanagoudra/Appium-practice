package mobile.screens.more.activity;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ActivityScreenAndroid extends
        ActivityScreenBase<AndroidCustomDriver> {

    public ActivityScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
