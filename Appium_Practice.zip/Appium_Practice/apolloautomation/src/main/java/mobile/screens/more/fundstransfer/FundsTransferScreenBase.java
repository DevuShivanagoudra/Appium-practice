package mobile.screens.more.fundstransfer;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.common.exceptions.InvalidOptionException;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class FundsTransferScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"New Transfer\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"New Transfer\")")
    private WebElement newTransfer;

    @iOSXCUITFindBy(xpath = "//*[@label = 'New Transfer']/following-sibling::*")
    @AndroidFindBy(xpath = "//*[@text = 'New Transfer']/following-sibling::*")
    private WebElement newTransferSubText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Pending\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Pending\")")
    private WebElement pending;

    @iOSXCUITFindBy(xpath = "//*[@label = 'Pending']/following-sibling::*")
    @AndroidFindBy(xpath = "//*[@text = 'Pending']/following-sibling::*")
    private WebElement pendingSubText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"History\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"History\")")
    private WebElement history;

    @iOSXCUITFindBy(xpath = "//*[@label = 'History']/following-sibling::*")
    @AndroidFindBy(xpath = "//*[@text = 'History']/following-sibling::*")
    private WebElement historySubText;

    @iOSXCUITFindBy(xpath = "//android.widget.TextView[@content-desc='Transfer Funds")
    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Transfer Funds\")")
    private WebElement fundTransferIcon;

    @iOSXCUITFindBy(xpath = "//*[@text()='From']")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"From\")")
    private WebElement fromField;

    @iOSXCUITFindBy(xpath = "//*[contains(@text,'$')]")
    @AndroidFindBy(xpath = "new UiSelector().textContains(\"$\")")
    private WebElement accountHavingAmount;

    @iOSXCUITFindBy(xpath = "//*[contains(@text,'No Accounts Selected')]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"No Accounts Selected\")")
    private WebElement noAccountsSelected;

    protected FundsTransferScreenBase(final D driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(history, MAXIMUM_WAIT_TIMEOUT,
                "Funds Transfer Screen is not displayed.");
    }

    /**
     * Taps on the Transfer Type.
     *
     * @param option String
     */
    public void tapOption(final String option) {
        switch (option) {
            case "New Transfer":
                newTransfer.click();
                break;
            case "Pending":
                pending.click();
                break;
            case "History":
                history.click();
                break;
            default:
                throw new InvalidOptionException("Delivery Type is invalid.");
        }
    }
}
