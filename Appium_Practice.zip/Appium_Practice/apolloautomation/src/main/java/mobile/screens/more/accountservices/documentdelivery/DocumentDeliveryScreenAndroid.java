package mobile.screens.more.accountservices.documentdelivery;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.android.AndroidUtils;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;

import java.time.Duration;

import static jarvis.mobile.appium.Utils.letScreenSettle;

@Getter
@Slf4j
public class DocumentDeliveryScreenAndroid extends
        DocumentDeliveryScreenBase<AndroidCustomDriver> {

    private static final String ACCOUNT_LOCATOR = "new UiSelector().text(\"%s\")";

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"TopBar-Title-.*\")")
    public WebElement title;

    public DocumentDeliveryScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @SneakyThrows
    @Override
    public void setEDeliveryToggle(Toggle state) {
        // very much necessary as toggle is getting enabled some time after page loads.
        letScreenSettle(Duration.ofSeconds(5));
        getDriver().scrollTo(getEDeliveryAllOptions(), Direction.DOWN);
        AndroidUtils.setToggle(getDriver(), getEDeliveryAllOptions(), state.getBoolValue());
    }

    @Override
    public void tapAccount(final String name) {
        getDriver()
                .scrollTo(AppiumBy.androidUIAutomator(String.format(ACCOUNT_LOCATOR, name)))
                .click();
    }

    @Override
    public void tapDocumentType(final String name) {
        getDriver()
                .scrollTo(AppiumBy.androidUIAutomator(String.format(ACCOUNT_LOCATOR, name)))
                .click();
    }

    @Override
    public boolean isAccountVisible(final String account) {
        getDriver()
                .scrollTo(AppiumBy.androidUIAutomator(String.format(ACCOUNT_LOCATOR, account)));
        return getDriver()
                .isElementVisible(AppiumBy.androidUIAutomator(String.format(ACCOUNT_LOCATOR, account)));
    }
}
