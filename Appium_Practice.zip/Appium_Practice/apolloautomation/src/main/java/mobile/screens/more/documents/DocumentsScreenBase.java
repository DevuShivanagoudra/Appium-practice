package mobile.screens.more.documents;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class DocumentsScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeNavigationBar[`name == \"More\"`]/**/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-Title-Documents\")")
    private WebElement title;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"More\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-IconButton\")")
    private WebElement backButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Disclosures\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Disclosures\")")
    private WebElement disclosuresLink;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"There are no recent documents to show\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textStartsWith(\"There are no documents available\")")
    private WebElement noDocumentsText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"Not getting your email\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textStartsWith(\"Not getting your email\")")
    private WebElement notGettingEmailNotificationsHeader;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"To ensure the following email addresses\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textStartsWith(\"To ensure the following email addresses \")")
    private WebElement notGettingEmailNotificationsText;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"To ensure the following email addresses\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textContains(\"notifyinvestor@RaymondJames.com\")")
    private WebElement notGettingEmailNotificationsEmailIDs;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Filter\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"ToFilter\").childSelector(new UiSelector().className(\"android.widget.Button\"))")
    private WebElement filter;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Filter\"]/preceding-sibling::*//XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"Chip.*Text\")")
    private List<WebElement> filterChips;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Linked Summary Statement\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Linked Summary Statement\")")
    private WebElement documentRecord;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label CONTAINS \"-202\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textMatches(\".*, 202.*\")")
    private List<WebElement> statementDates;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Statements\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Statements\")")
    private List<WebElement> documentTypes;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"Shareholder Documents are available in Client\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textStartsWith(\"Shareholder Documents are available in Client\")")
    private WebElement shareHolderDocumentText;

    protected DocumentsScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on Back button.
     */
    public void tapBack() {
        backButton.click();
    }

    /**
     * Taps on Disclosures Link.
     */
    public void tapDisclosuresLink() {
        getDriver().scrollTo(disclosuresLink).click();
    }

    /**
     * Taps on Filter button.
     */
    public void tapFilter() {
        filter.click();
    }

    /**
     * Taps on Document record.
     */
    public void tapDocumentRecord() {
        documentRecord.click();
    }

    public List<String> getFilterChips() {
        List<String> chips = filterChips.stream().filter(WebElement::isDisplayed)
                .map(x -> x.getText())
                .collect(Collectors.toList());
        return chips;
    }

    public void tapTermsAndConditions() {
        getDriver().tap(getShareHolderDocumentText(), 100, 286);
    }

    @Override
    public void waitToLoad() {
        getDriver()
                .waitUntilVisible(filter, MAXIMUM_WAIT_TIMEOUT,
                        "Filter Icon is not displayed.");
        getDriver()
                .scrollTo(notGettingEmailNotificationsEmailIDs);
    }
}
