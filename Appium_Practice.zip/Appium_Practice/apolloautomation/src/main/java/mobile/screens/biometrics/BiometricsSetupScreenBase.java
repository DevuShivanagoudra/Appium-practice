package mobile.screens.biometrics;

import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public abstract class BiometricsSetupScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    protected BiometricsSetupScreenBase(final D driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {

    }
}
