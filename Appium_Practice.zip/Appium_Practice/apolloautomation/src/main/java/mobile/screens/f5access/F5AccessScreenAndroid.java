package mobile.screens.f5access;

import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
public class F5AccessScreenAndroid extends F5AccessScreenBase<AndroidCustomDriver> {

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.f5.edge.client_ics:id/connection_time_elapsed\")")
    private WebElement connectionTimeElapsed;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.f5.edge.client_ics:id/connect_button_text\")")
    private WebElement connect;

    public F5AccessScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void getConnection() {
        getDriver().waitUntilVisible(getStatusLabel(), MAXIMUM_WAIT_TIMEOUT,
                "V5 access is not opened yet.");
        if (!getDriver().isElementVisible(connectionTimeElapsed)) {
            log.info("Trying to connect to F5 Access.");
            connect.click();
            getDriver().waitUntilVisible(connectionTimeElapsed, MAXIMUM_WAIT_TIMEOUT,
                    "Connection failed.");
            log.info("F5 Access connection successful.");
        } else {
            log.info("F5 Access connection already connected.");
        }
    }
}
