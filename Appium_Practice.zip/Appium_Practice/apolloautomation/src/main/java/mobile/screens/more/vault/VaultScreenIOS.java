package mobile.screens.more.vault;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.constants.ElementDirection;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class VaultScreenIOS extends VaultScreenBase<IOSCustomDriver> {

    private static final String RECORD_LOCATOR = "**/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"%s\"`]";
    private static final String RECORD_SWIPE_LOCATOR = "**/XCUIElementTypeButton[`label BEGINSWITH[cd] \"%s\"`]";
    private static final String RECORD_INFO_LOCATOR = "**/XCUIElementTypeButton[`label == \"Info\"`]";
    private static final String SELECTED_SORT_OPTION = "//XCUIElementTypeButton[@name=\"%s Ascending - PickerOption\"]";
    private static final String VAULT_DETAILS = "//XCUIElementTypeButton[@name=\"%s\"]/following-sibling::XCUIElementTypeStaticText";

    public VaultScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    protected void enterFolderDetails(String name, String description) {
        //implemented in child class
    }

    @Override
    public void tapFolderInfo(final String folderName) {
        getDriver().scrollTo(
                AppiumBy.iOSClassChain(String.format(RECORD_LOCATOR, folderName)), Direction.UP_SMALL,
                20);
        WebElement element = getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(RECORD_SWIPE_LOCATOR, folderName)));
        getDriver().swipeElement(element, ElementDirection.LEFT);
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(RECORD_INFO_LOCATOR, folderName))).click();
    }

    @Override
    public void tapFolder(final String folderName) {
        getDriver().scrollTo(
                AppiumBy.iOSClassChain(String.format(RECORD_LOCATOR, folderName)), Direction.UP_SMALL,
                20).click();
    }

    public void tapSort() {
        getDefaultSort().click();
    }

    @Override
    public List<String> getAddItemOptions() {
        return getAddItemOptionsList()
                .stream()
                .map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
    }

    @Override
    public void waitForFolderToLoad(final String folderName) {
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(RECORD_LOCATOR, folderName)),
                MAXIMUM_WAIT_TIMEOUT,
                String.format("Folder [%s] is not Visible.", folderName));
    }

    @Override
    public boolean isFolderVisible(final String folderName) {
        return getDriver()
                .isElementVisible(AppiumBy.iOSClassChain(String.format(RECORD_LOCATOR, folderName)));
    }

    /**
     * Verifies whether the Sort option is selected.
     *
     * @param option String
     * @return boolean
     */
    public boolean isSortOptionSelected(final String option) {
        return getDriver().isElementVisible(By.xpath(String.format(SELECTED_SORT_OPTION, option)));
    }

    @Override
    public List<String> getVaultDetails(final String selectedVault) {
        List<WebElement> vaultDetails = getDriver().findElements(
                By.xpath(String.format(VAULT_DETAILS, selectedVault)));
        return vaultDetails.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }
}
