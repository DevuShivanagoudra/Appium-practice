package mobile.screens.login.logindisclosure;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;

import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class DisclosuresScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name BEGINSWITH[cd] \"If online delivery of the\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.ImageView\")")
    protected List<WebElement> tabBarContainer;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Disclosures\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-Title-Disclosures\")")
    private WebElement disclosuresHeader;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeStaticText[`label CONTAINS \" Raymond James & Associates\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.ScrollView\")")
    private WebElement disclosuresText1;

    protected DisclosuresScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Get Disclosures Header.
     *
     * @return boolean
     */
    public boolean getDisclosuresHeader() {
        return disclosuresHeader.isDisplayed();
    }

    /**
     * Get Disclosures Text.
     *
     * @return string
     */
    public String getLoginDisclosuresText() {
        return disclosuresText1.getText();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(disclosuresHeader, DEFAULT_WAIT_TIMEOUT,
                "Disclosures Screen is not displayed.");
    }
}
