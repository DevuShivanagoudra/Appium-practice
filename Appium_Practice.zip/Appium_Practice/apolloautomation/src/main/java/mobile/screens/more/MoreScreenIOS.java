package mobile.screens.more;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Getter
public class MoreScreenIOS extends MoreScreenBase<IOSCustomDriver> {

    private static final String MORE_OPTION = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";
    private static final String MORE_BACKBUTTON = "**/XCUIElementTypeNavigationBar/XCUIElementTypeButton[`label == \"More\"`]";

    public MoreScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public List<String> getTabBarNames() {
        List<String> tabBarNames = tabBarContainer.stream()
                .map(t -> t.getText())
                .collect(Collectors.toList());
        return tabBarNames;
    }

    @Override
    public void tapMoreOption(final String moreOption) {
        if (getDriver().isElementVisible(AppiumBy.iOSClassChain(MORE_BACKBUTTON))) {
            getDriver().findElement(AppiumBy.iOSClassChain(MORE_BACKBUTTON)).click();
        }
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(MORE_OPTION, moreOption))).click();
    }
}
