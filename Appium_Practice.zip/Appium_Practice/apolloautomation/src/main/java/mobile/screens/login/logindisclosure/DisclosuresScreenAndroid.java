package mobile.screens.login.logindisclosure;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class DisclosuresScreenAndroid extends
        DisclosuresScreenBase<AndroidCustomDriver> {

    public DisclosuresScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    /**
     * Get Disclosures Text
     *
     * @return
     */
    public List<String> getDisclosuresText() {
        List<WebElement> elements = getDriver().findAll(getDisclosuresText1(),
                AppiumBy.androidUIAutomator("new UiSelector().className(\"android.view.View\")"));
        return elements.stream()
                .map(x -> x.getAttribute("text"))
                .collect(Collectors.toList());
    }
}
