package mobile.screens.alerts.exitappalert;

import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.screens.alerts.AlertDialogBase;
import org.openqa.selenium.WebElement;

@Slf4j
@Getter
public class ExitAppAlertAndroid extends
        AlertDialogBase<AndroidCustomDriver> {

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Exit the App\")")
    private WebElement exitApp;

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Yes\")")
    private WebElement yesButton;

    public ExitAppAlertAndroid(final AndroidCustomDriver driver) {
        super(driver);
    }

    /**
     * Taps on Yes button.
     */
    public void tapYes() {
        yesButton.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(exitApp, "Alert is not displayed.");
    }
}
