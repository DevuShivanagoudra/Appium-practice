package mobile.screens.more.documents.filter;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.List;
import java.util.stream.Collectors;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class DocumentsFilterScreenIOS extends
        DocumentsFilterScreenBase<IOSCustomDriver> {

    private static final String ACCOUNTSELECTED_ICON_LOCATOR = "**/XCUIElementTypeScrollView[1]/XCUIElementTypeOther/XCUIElementTypeOther[`label == \"%s\"`]/XCUIElementTypeImage";
    private static final String GROUPSELECTED_ICON_LOCATOR = "**/XCUIElementTypeScrollView[1]/**/XCUIElementTypeStaticText[`label == \"%s\"`]/XCUIElementTypeImage";
    private static final String ACCOUNTNAMES_LOCATOR = "**/XCUIElementTypeScrollView[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText";
    private static final String ACCOUNTNAME_LOCATOR = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";
    private static final String DOCUMENTTYPE_LOCATOR = "**/XCUIElementTypeButton[`label == \"%s\"`]";
    private static final String YEAR_LOCATOR = "**/XCUIElementTypeButton[`label == \"%s\"`]";
    //TODO: Blocked by Task 1354673.
    private static final String SELECTED_LOCATOR = "**/XCUIElementTypeScrollView[1]/XCUIElementTypeOther/XCUIElementTypeOther[`label == \"%s\"`]/XCUIElementTypeImage";
    private static final String YEARSELECTED_LOCATOR = "";

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeStaticText")
    private List<WebElement> accountsList;

    public DocumentsFilterScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public boolean isDocumentTypeVisible(final String documentType) {
        return getDriver().isElementVisible(
                AppiumBy.iOSClassChain(String.format(DOCUMENTTYPE_LOCATOR, documentType)));
    }

    //TODO: Blocked by Task 1354673
    @Override
    public boolean isDocumentTypeSelected(final String documentType) {
        return getDriver().isElementVisible(
                AppiumBy.iOSClassChain(String.format(SELECTED_LOCATOR, documentType)));
    }

    @Override
    public void selectDocumentType(final String documentType) {
        getDriver().scrollTo(getYearHeader());
        getDriver().waitUntilVisible(AppiumBy.iOSClassChain(String.format(
                DOCUMENTTYPE_LOCATOR, documentType))).click();
    }

    @Override
    public void selectYear(final String year) {
        getDriver().scrollTo(AppiumBy.iOSClassChain(String.format(
                YEAR_LOCATOR, year))).click();
    }

    public boolean isAccountSelected(final String accountName) {
        return getDriver().isElementVisible(AppiumBy.iOSClassChain(
                String.format(SELECTED_LOCATOR, accountName)));
    }

    //TODO: Blocked by Task 1354673
    @Override
    public boolean isYearSelected(final String year) {
        return getDriver().isElementVisible(
                AppiumBy.iOSClassChain(String.format(YEARSELECTED_LOCATOR, year)));
    }

    @Override
    public void waitUntilAccountsLoaded() {
        getDriver().waitUntilCondition(
                ExpectedConditions
                        .numberOfElementsToBeMoreThan(AppiumBy.iOSClassChain(ACCOUNTNAMES_LOCATOR), 3));
        getDriver().waitUntilClickable(getDriver().findElement(
                        AppiumBy.iOSClassChain(String.format(GROUPSELECTED_ICON_LOCATOR, "Assets"))),
                MAXIMUM_WAIT_TIMEOUT, "Assets Tristate checkbox is not enabled.");
    }

    @Override
    public void verifyAccountsSelected() {
        List<String> accounts = accountsList.stream()
                .map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
        for (String account : accounts) {
            Assert.assertTrue(getDriver().isElementVisible(
                            AppiumBy.iOSClassChain(String.format(SELECTED_LOCATOR, account))),
                    String.format("Account %s is not selected.", account));
        }
    }
}
