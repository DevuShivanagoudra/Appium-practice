package mobile.screens.homescreen;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HomeScreenAndroid extends
        HomeScreenBase<AndroidCustomDriver> {

    public HomeScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
