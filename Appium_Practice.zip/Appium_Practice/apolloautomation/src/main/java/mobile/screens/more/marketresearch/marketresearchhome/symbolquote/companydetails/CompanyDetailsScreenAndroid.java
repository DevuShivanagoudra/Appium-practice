package mobile.screens.more.marketresearch.marketresearchhome.symbolquote.companydetails;

import jarvis.mobile.common.driver.AndroidCustomDriver;

public class CompanyDetailsScreenAndroid extends CompanyDetailsScreenBase
        <AndroidCustomDriver> {

    public CompanyDetailsScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
