package mobile.screens.more.activity;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class ActivityScreenIOS extends ActivityScreenBase<IOSCustomDriver> {

    private static final String MORE_OPTION = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";

    public ActivityScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

}
