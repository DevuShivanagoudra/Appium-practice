package mobile.screens.portfolio.portfoliofilter;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class PortfolioFilterScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    protected List<String> accountGroupsNames = Arrays
            .asList("Assets", "Closed Accounts", "Liabilities");

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Default\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Default\").childSelector(new UiSelector().className(\"android.widget.RadioButton\"))")
    private WebElement defaultGroupBy;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Filter Portfolio\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Filter\")")
    private WebElement portfolioFilterTitle;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Done\"`]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Done']/..")
    private WebElement doneButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Gain/(Loss)\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Investment Gain or (Loss) radio button\")")
    private WebElement gainLossSection;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Gain/(Loss)\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Capital Gains & Losses\")")
    private WebElement capitalGainsAndLossesSection;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label MATCHES \".*Securities.*\"`]")
    @AndroidFindBy(xpath = "//*[@text = 'Filter by Securities']/..")
    private WebElement allSecurities;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"All Accounts\" OR label MATCHES \"Accounts (.*)\"`]")
    @AndroidFindBy(xpath = "//*[@text = 'Filter by Accounts']/..")
    private WebElement allAccounts;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeSwitch[`label == \"All Securities\"`]/XCUIElementTypeSwitch")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"All Securities-switch\")")
    private WebElement allSecuritiesToggle;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`name CONTAINS 'key: \"Current Value\"'`]/XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().descriptionStartsWith(\"Expandable Arrow\").fromParent(new UiSelector().className(\"android.widget.TextView\"))")
    private List<WebElement> securityGroups;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Variable Annuities\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Variable Annuities\")")
    private WebElement variableAnnuitiesSecurityName;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeImage[`label == \"Forward\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"groupAnnuities\")")
    private WebElement expandButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Cash\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Cash\")")
    private WebElement cashSecurityButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Common Shares\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Common Shares\")")
    private WebElement commonSharesSecurityButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"group\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().descriptionStartsWith(\"Expandable Arrow\").fromParent(new UiSelector().className(\"android.widget.TextView\"))")
    private List<WebElement> accountgroups;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cancel\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(0)")
    private WebElement cancelButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Back\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-IconButton\")")
    private WebElement backButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeButton[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.CheckBox\").instance(0)")
    private WebElement firstGroup;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Please select at least one (1) security\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TextError\")")
    private WebElement allSecuritiesErrorMessage;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Cash\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Cash\")")
    private WebElement cash;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Open-End Mutual Funds\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Open-End Mutual Funds\")")
    private WebElement openEndMutualFunds;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Common Shares\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Common Shares\")")
    private WebElement commonShares;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == \"Cash\"`]/**/XCUIElementTypeImage[`label == \"Selected\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Cash\").fromParent(new UiSelector().description(\"Cash\"))")
    private WebElement cashSelected;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Cash Alternatives\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Cash Alternatives\")")
    private WebElement cashAlternatives;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Cash & Cash Alternatives\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"groupCash & Cash Alternatives\")")
    private WebElement cashAlternativesSecurityType;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Funds\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"groupFunds\")")
    private WebElement fundsSecurityType;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == \"Cash Alternatives\"`]/**/XCUIElementTypeImage[`label == \"Selected\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Cash Alternatives\").fromParent(new UiSelector().description(\"Cash Alternatives\"))")
    private WebElement cashAlternativesSelected;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Closing Date\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Closing Date\")")
    private WebElement closingDateHeader;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeDatePicker[`name == \"fromDatePicker\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"From\")")
    private WebElement closingdateFromSelectable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Show year picker\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().description(\"Drop Up Button\")")
    private WebElement yearDropdown;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cash Alternatives\"`]/**/XCUIElementTypeImage[`label == \"Selected\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"OK\")")
    private WebElement dateSelectorOKButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cost Basis Gain/(Loss)\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Cost Basis Gain or (Loss)\")")
    private WebElement costBasisGainLossButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Investment Gain/(Loss)\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Investment Gain or (Loss)\")")
    private WebElement investmentGainLossButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Filter by\"]/following::XCUIElementTypeButton[2]")
    private WebElement productTypeFilterField;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeCollectionView/XCUIElementTypeButton[contains(@label,'1')]")
    @AndroidFindBy(xpath = "(//android.widget.TextView)[22]")
    private WebElement fromDateSelectedFilterScreen;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeCollectionView/XCUIElementTypeButton[contains(@label,'1')]")
    @AndroidFindBy(xpath = "(//android.widget.TextView)[23]")
    private WebElement toDateSelectedFilterScreen;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeDatePicker[`name == \"toDatePicker\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"To\")")
    private WebElement closingdateToSelectable;

    protected PortfolioFilterScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on Cost Basis Gain or (Loss) to select the View.
     */
    public void tapCostBasis() {
        costBasisGainLossButton.click();
    }

    /**
     * Taps on Investment Gain or (Loss) to select the View.
     */
    public void tapInvestmentGainLoss() {
        investmentGainLossButton.click();
    }

    public abstract List<String> getSecurityGroupsList();

    /**
     * Taps on All Securities button.
     */
    public void tapAllSecurities() {
        getDriver().waitUntilClickable(allSecurities).click();
    }

    /**
     * Checks whether the Securities error message is present.
     *
     * @return boolean
     */
    public boolean isSecuritiesErrorMessageVisible() {
        return getDriver().isElementPresent(getAllSecuritiesErrorMessage());
    }

    /**
     * Taps on All Accounts.
     */
    public void tapAllAccounts() {
        getDriver().waitUntilClickable(allAccounts).click();
    }

    /**
     * Selects GainLoss Type.
     *
     * @param viewOption String
     */
    protected abstract void selectGainLossType(final String viewOption);

    /**
     * Taps on Cash Security.
     */
    public void tapCash() {
        cash.click();
    }

    /**
     * Taps on Cash Alternatives security.
     */
    public void tapCashAlternatives() {
        cashAlternatives.click();
    }

    /**
     * Taps on Done button.
     */
    public void tapDone() {
        getDriver()
                .waitUntilClickable(doneButton, MAXIMUM_WAIT_TIMEOUT, "Done button not Enabled")
                .click();
    }

    public void dismissFilterScreen() {
        if (getDoneButton().isEnabled()) {
            tapDone();
        } else {
            tapCancel();
        }
    }

    /**
     * Taps on All Secutities Toggle.
     */
    public abstract void tapAllSecurities(final Toggle state);

    /**
     * Select closing dates.
     *
     * @param year String
     */
    public abstract void selectClosingDate(final String year, final String month);

    /**
     * Verifies Security group is NOT displayed.
     *
     * @param securityGroup String
     */
    public abstract void verifySecurityGroupNotDisplayed(final String securityGroup);

    /**
     * Verify all accounts are selected.
     */
    protected abstract void verifyAccountsSelected();

    /**
     * Verifies whether an account is selected.
     *
     * @param accountName String.
     * @return boolean
     */
    public abstract boolean isAccountSelected(final String accountName);

    /**
     * Expand / Collapse Security Group.
     */
    protected abstract void expandCollapseSecurityGroup(final String securityGroupName);

    /**
     * Tap Cancel on Filter Screen.
     */
    public void tapCancel() {
        cancelButton.click();
    }

    /**
     * Tap Cancel on Filter Screen.
     */
    public void tapBack() {
        backButton.click();
    }

    /**
     * Tap Done on Filter Screen.
     */
    public void tapFilterDone() {
        doneButton.click();
    }


    public List<String> fetchAccountGroups() {
        return accountgroups.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    protected abstract List<String> fetchAccounts();

    protected abstract void deSelectAllAccounts();

    /**
     * Waits for Filter screen to load for Realized Gain Loss.
     */
    public void waitForRealizedGLFilterToLoad() {
        getDriver().scrollTo(closingdateFromSelectable, Direction.UP, 2);
        getDriver().waitUntilClickable(closingdateFromSelectable);
    }

    public void waitForSecurityToggleToLoad() {
        getDriver().waitUntilClickable(allSecuritiesToggle, MAXIMUM_WAIT_TIMEOUT,
                "Portfolio Securities filter screen is not Clickable.");
    }

    public void waitForAllAccountsToLoad() {
        getDriver().waitUntilClickable(firstGroup, MAXIMUM_WAIT_TIMEOUT,
                "Portfolio Accounts filter screen is not Clickable.");
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilClickable(gainLossSection, MAXIMUM_WAIT_TIMEOUT,
                "Portfolio Filter screen not displayed.");
    }

    public void verifyProductTypesFieldInPortfolioFilterScreen() {
        Assert.assertEquals(productTypeFilterField.getText(), "All Product Types", "Product Type Field is visible as  the second field.");
    }
}
