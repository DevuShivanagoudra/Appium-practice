package mobile.screens.more.accountservices.documentdelivery.edeliveryterms;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class EDeliveryTermsandConditionsScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"I Agree\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Password and Security\")")
    private WebElement agreeButton;

    protected EDeliveryTermsandConditionsScreenBase(D driver) {
        super(driver);
    }

    /**
     * Taps on I Agree button.
     */
    public void tapIAgree() {
        agreeButton.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(agreeButton, DEFAULT_WAIT_TIMEOUT,
                "Terms and Conditions Screen is not displayed.");
    }
}
