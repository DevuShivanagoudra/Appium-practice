package mobile.screens.more.morereorder;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Getter
public class MoreReorderScreenIOS extends MoreReorderScreenBase<IOSCustomDriver> {

    public MoreReorderScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public List<String> getTabBarNames() {
        List<String> tabBarNames = tabBarContainer.stream().filter(WebElement::isDisplayed)
                .map(t -> t.getText())
                .collect(Collectors.toList());
        return tabBarNames;
    }

    @Override
    public WebElement getTabbarDragIcon(final String tabbarName) {
        final int indexDragIcon = getTabBarNames().indexOf(tabbarName) + 1;
        return tabBarContainer.get(indexDragIcon);
    }

    @Override
    public boolean isTabbarNameVisible(final String tabbarName) {
        return getTabBarNames().contains(tabbarName);
    }
}
