package mobile.screens.codeinputscreen;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class CodeInputScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.EditText\")")
    private WebElement codeInputEditable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Verify\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"mfaValidateButton\")")
    private WebElement submitButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Security Verification\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textStartsWith(\"We sent a code to XXX-XXX-\")")
    private WebElement codeInputMessage;

    protected CodeInputScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Enters the code in the textbox and clicks on submit button.
     *
     * @param codeInput string
     */
    protected abstract void submitCode(final String codeInput);

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(codeInputMessage, MAXIMUM_WAIT_TIMEOUT,
                "Code input Screen is not displayed.");
    }
}
