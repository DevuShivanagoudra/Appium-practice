package mobile.screens.more.fundstransfer.transfersummary;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class TransferSummaryScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Transfer Date\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Transfer Date\")")
    private WebElement transferDateLabel;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Your transfer was successfully scheduled!\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Your transfer was successfully scheduled!\")")
    private WebElement successfulMessage;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Confirmation code\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Confirmation code\")")
    private WebElement confirmationCodeLabel;

    @iOSXCUITFindBy(xpath = "//*[@name = 'Confirmation code']/following-sibling::*")
    @AndroidFindBy(xpath = "//*[@resource-id = 'Confirmation code']/following-sibling::*[1]")
    private WebElement confirmationCodeValue;

    @iOSXCUITFindBy(xpath = "//*[@name = 'From']/following-sibling::*[1]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'From']/following-sibling::*[1]")
    private WebElement fromAccount;

    @iOSXCUITFindBy(xpath = "//*[@name = 'To']/following-sibling::*[1]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'To']/following-sibling::*[1]")
    private WebElement toAccount;

    @iOSXCUITFindBy(xpath = "//*[@name = 'Transfer Date']/following-sibling::*[1]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'Transfer Date']/following-sibling::*[1]")
    private WebElement transferDate;

    @iOSXCUITFindBy(xpath = "//*[@name = 'Gross Amount to be Withdrawn']/following-sibling::*[1]")
    @AndroidFindBy(xpath = "//*[@resource-id = 'Gross Amount to be Withdrawn']/following-sibling::*[1]")
    private WebElement grossAmount;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"New Transfer\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"New Transfer\")")
    private WebElement newTransfer;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"For transfers to or from\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().textStartsWith(\"For transfers to or from\")")
    private WebElement raymondJamesCopy;

    protected TransferSummaryScreenBase(final D driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(successfulMessage, MAXIMUM_WAIT_TIMEOUT,
                "Funds Transfer Screen is not displayed.");
    }
}
