package mobile.screens.more.fundstransfer.transfersummary;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class TransferSummaryScreenAndroid extends
        TransferSummaryScreenBase<AndroidCustomDriver> {

    public TransferSummaryScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
