package mobile.screens.more.marketresearch.marketresearchhome;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class MarketResearchScreenIOS extends
        MarketResearchScreenBase<IOSCustomDriver> {

    private static final String OPTION_LOCATOR = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";

    public MarketResearchScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapOption(final String option) {
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(OPTION_LOCATOR, option))).click();
    }
}
