package mobile.screens.biometrics;

import io.appium.java_client.pagefactory.AndroidFindBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class BiometricsSetupScreenAndroid extends
        CommonScreenBase<AndroidCustomDriver> {

    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"No Thanks\")")
    private WebElement noThanks;

    public BiometricsSetupScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(noThanks, MAXIMUM_WAIT_TIMEOUT,
                "Biometrics Setup Screen is not displayed.");
    }

    /**
     * Taps on 'No Thanks' link/button.
     */
    public void tapNoThanks() {
        noThanks.click();
    }
}
