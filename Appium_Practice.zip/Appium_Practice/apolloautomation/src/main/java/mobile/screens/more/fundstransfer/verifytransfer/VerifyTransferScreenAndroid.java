package mobile.screens.more.fundstransfer.verifytransfer;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class VerifyTransferScreenAndroid extends
        VerifyTransferScreenBase<AndroidCustomDriver> {

    public VerifyTransferScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }
}
