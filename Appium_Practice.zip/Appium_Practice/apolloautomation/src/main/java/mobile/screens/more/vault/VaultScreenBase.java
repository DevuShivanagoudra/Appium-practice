package mobile.screens.more.vault;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class VaultScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeCollectionView/XCUIElementTypeCell[1]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"clickSurface\").instance(0)")
    private WebElement clickSurface;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"There are no items to show\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"There are no items to show\")")
    private WebElement noItemsMessage;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeNavigationBar/**/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-Title-Vault\")")
    private WebElement title;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Sort\"]/preceding-sibling::*[1]//XCUIElementTypeImage")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"icon\")")
    private WebElement expandableAdditionalInfo;
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"icon\")")

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Sort\"]/preceding-sibling::*[1]//XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"title\")")
    private WebElement selectedVault;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label BEGINSWITH[cd] \"Collaborators \\(\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceIdMatches(\"Collaborators \\(.*\")")
    private WebElement collaborators;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Sort\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"SortType-Text\")")
    private WebElement defaultSort;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Add\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Add Item\")")
    private WebElement addItem;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\")")
    private List<WebElement> addItemOptionsList;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Create New Folder\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Create New Folder\")")
    private WebElement createNewFolder;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeTextField")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Folder Name-EditField\")")
    private WebElement folderNameEditable;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cancel\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Cancel\")")
    private WebElement cancelButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeNavigationBar/XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(0)")
    private WebElement backButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Create\" OR label == \"Save\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Save\")")
    private WebElement saveButton;

    protected VaultScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Tap on Add Item Icon.
     */
    public void tapAddItem() {
        getDriver().waitUntilVisible(addItem).click();
    }

    /**
     * Tap on Create New Folder Item Button.
     */
    public void tapCreateNewFolder() {
        createNewFolder.click();
    }

    /**
     * Taps on Save Button.
     */
    public void tapSaveButton() {
        saveButton.click();
    }

    /**
     * Taps Expandable Arrow.
     */
    public void expandAdditionalInfo() {
        expandableAdditionalInfo.click();
        getDriver().waitUntilVisible(collaborators, MAXIMUM_WAIT_TIMEOUT,
                "Additional Information is not Displayed.");
    }

    /**
     * Taps Collapsable Arrow.
     */
    public void CollapseAdditionalInfo() {
        expandableAdditionalInfo.click();
    }

    /**
     * Taps on Cancel button.
     */
    public void tapCancelButton() {
        cancelButton.click();
    }

    /**
     * Taps on back button.
     */
    public void tapBackButton() {
        backButton.click();
    }

    /**
     * Enters folder name.
     */
    public void enterFolderName(final String name) {
        folderNameEditable.sendKeys(name);
    }

    /**
     * Creates a folder with name and description.
     *
     * @param name        String
     * @param description String
     */
    protected abstract void enterFolderDetails(final String name, final String description);

    /**
     * Slides folder to the left and selects 'info' icon.
     *
     * @param folderName String
     */
    protected abstract void tapFolderInfo(final String folderName);

    /**
     * Taps on a folder.
     *
     * @param folderName String
     */
    protected abstract void tapFolder(final String folderName);

    /**
     * Waits for Folder to load.
     *
     * @param folderName String
     */
    protected abstract void waitForFolderToLoad(final String folderName);

    /**
     * Verifies Whether folder is visible.
     *
     * @param folderName String
     * @return boolean
     */
    protected abstract boolean isFolderVisible(final String folderName);

    /**
     * Fetches Vault details.
     *
     * @param selectedVault String
     * @return List of String
     */
    protected abstract List<String> getVaultDetails(final String selectedVault);

    /**
     * Fetches Add Item Options.
     *
     * @return List of String
     */
    protected abstract List<String> getAddItemOptions();

    @Override
    public void waitToLoad() {
        getDriver().waitUntilCondition(100,
                ExpectedConditions.or(ExpectedConditions.visibilityOf(clickSurface),
                        ExpectedConditions.visibilityOf(noItemsMessage)),
                "Vault/Folder detail screen is not displayed. ");
    }
}
