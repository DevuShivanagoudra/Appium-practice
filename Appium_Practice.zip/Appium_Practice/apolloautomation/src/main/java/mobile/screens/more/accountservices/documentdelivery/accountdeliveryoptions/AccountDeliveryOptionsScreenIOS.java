package mobile.screens.more.accountservices.documentdelivery.accountdeliveryoptions;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import mobile.appium.ios.IOSUtils;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.Map;

@Slf4j
@Getter
public class AccountDeliveryOptionsScreenIOS extends
        AccountDeliveryOptionsScreenBase<IOSCustomDriver> {

    private static final String DELIVERYTYPE_TOGGLE = "**/XCUIElementTypeSwitch[`label == \"%s\"`]/XCUIElementTypeSwitch";

    public AccountDeliveryOptionsScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void setDeliveryTypes(final Map<String, String> deliveryTypes) {
        setToggle(getAllDocumentsOptions(), Toggle.OFF.getBoolValue());
        for (String key : deliveryTypes.keySet()) {
            WebElement element = getDriver().waitUntilPresent(
                    AppiumBy.iOSClassChain(String.format(DELIVERYTYPE_TOGGLE, key)));
            if (deliveryTypes.get(key).equalsIgnoreCase("paper")) {
                setToggle(element, Toggle.OFF.getBoolValue());
            } else {
                setToggle(element, Toggle.ON.getBoolValue());
            }
        }
    }

    public void setToggle(final WebElement toggleElement,
                          final boolean toggleState) {
        CommonUtils.scrollToElement(getDriver(), toggleElement, Direction.UP, 10);
        if (toggleState && toggleElement.getAttribute("value").equals("0")) {
            //FIXME: Click is not working on TypeSwitch(IOS16).
            getDriver().tap(toggleElement);
            getDriver()
                    .waitUntilCondition(ExpectedConditions.attributeToBe(toggleElement, "value", "1"));
        } else if (!toggleState && toggleElement.getAttribute("value").equals("1")) {
            //FIXME: Click is not working on TypeSwitch(IOS16).
            getDriver().tap(toggleElement);
            getDriver()
                    .waitUntilCondition(ExpectedConditions.attributeToBe(toggleElement, "value", "0"));
        }
    }

    public boolean isDeliveryTypeSelected(final String accountName) {
        final WebElement element = getDriver().waitUntilPresent(
                AppiumBy.iOSClassChain(String.format(DELIVERYTYPE_TOGGLE, accountName)));
        return IOSUtils.getToggleState(element);
    }
}
