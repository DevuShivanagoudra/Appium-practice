package mobile.screens.more.fundstransfer.history;

import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class HistoryScreenAndroid extends
        HistoryScreenBase<AndroidCustomDriver> {

    public HistoryScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public String fetchHistoryCopy() {
        return getDriver().scrollTo(getHistoryCopy()).getAttribute("content-desc");
    }
}
