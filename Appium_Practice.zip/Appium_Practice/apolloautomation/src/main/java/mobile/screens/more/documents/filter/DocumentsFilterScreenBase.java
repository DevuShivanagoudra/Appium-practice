package mobile.screens.more.documents.filter;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class DocumentsFilterScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Cancel\" OR label == \"Back\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(0)")
    private WebElement backButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeNavigationBar[`name ENDSWITH \"UIHosting\"`]/**/XCUIElementTypeStaticText")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-Title-Filter\")")
    private WebElement title;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Done\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-ActionButton-Done\").childSelector(new UiSelector().className(\"android.widget.Button\"))")
    private WebElement done;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeStaticText[`label == \"Accounts\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.ScrollView\").childSelector(new UiSelector().text(\"All Accounts\"))")
    private WebElement accountsHeader;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"All Accounts\" OR label MATCHES \"Accounts (.*)\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"Filter by Accounts\")")
    private WebElement filterByAccounts;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeStaticText[`label == \"Document Type\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.ScrollView\").childSelector(new UiSelector().text(\"Document Type\"))")
    private WebElement documentTypeHeader;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeStaticText[`label == \"Year\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.ScrollView\").childSelector(new UiSelector().text(\"Year\"))")
    private WebElement YearHeader;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeScrollView/**/XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.TextView\")")
    private List<WebElement> textElements;

    //FIXME: This should be fixed after consistent  tags are implemented.
    @AndroidFindBy(xpath = "//android.widget.ScrollView/android.view.View[3]//android.widget.TextView[1]")
    private List<WebElement> accountList;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeImage[`label == \"Forward\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Liabilities\")")
    private WebElement allAccounts;

    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"All Accounts\")")
    private WebElement filterByAccountsAllAccounts;

    @AndroidFindBy(xpath = "//*[@text='Statements']//..")
    private WebElement statementsCheckboxContainer;

    @AndroidFindBy(xpath = "//*[@text='Most Recent']//..")
    private WebElement mostRecentCheckboxContainer;

    protected DocumentsFilterScreenBase(final D driver) {
        super(driver);
    }

    /**
     * Taps on Back button.
     */
    public void tapBack() {
        backButton.click();
    }

    /**
     * Taps on Done button.
     */
    public void tapDone() {
        done.click();
    }

    /**
     * Taps on All Accounts.
     */
    public void tapFilterByAccounts() {
        getDriver().waitUntilClickable(filterByAccounts).click();
    }

    /**
     * Verifies whether 'Document Type' is visible.
     *
     * @param documentType String
     * @return boolean
     */
    protected abstract boolean isDocumentTypeVisible(final String documentType);

    /**
     * Verifies whether 'Document Type' is selected.
     *
     * @param documentType String
     * @return boolean
     */
    protected abstract boolean isDocumentTypeSelected(final String documentType);

    /**
     * Selects a 'Document Type'.
     *
     * @param documentType String
     */
    protected abstract void selectDocumentType(final String documentType);

    /**
     * Selects a 'Year'.
     *
     * @param year String
     */
    protected abstract void selectYear(final String year);

    /**
     * Verifies whether a year is selected.
     *
     * @param year String
     * @return boolean
     */
    public abstract boolean isYearSelected(final String year);

    /**
     * Verify all accounts are selected.
     */
    protected abstract void verifyAccountsSelected();

    /**
     * Waits until accounts loaded.
     */
    protected abstract void waitUntilAccountsLoaded();

    /**
     * Taps on 'All Accounts' button.
     */
    public void tapAllAccounts() {
        allAccounts.click();
    }

    @Override
    public void waitToLoad() {
        CommonUtils.scrollToElement(getDriver(), getDocumentTypeHeader(), Direction.UP, 5);
        getDriver().waitUntilPresent(getDocumentTypeHeader(), MAXIMUM_WAIT_TIMEOUT);
    }

    public void verifyDefaultsOnDocumentsFilterScreen() {
        Assert.assertTrue(getDriver().isElementVisible(filterByAccountsAllAccounts), "All Account is not selected as default.");
        Assert.assertEquals(mostRecentCheckboxContainer.getAttribute("checkable"), "true", "Most Recent is not selected by default.");
        Assert.assertEquals(mostRecentCheckboxContainer.getAttribute("checked"), "true", "Most Recent is not selected by default.");
        Assert.assertEquals(mostRecentCheckboxContainer.getAttribute("clickable"), "false", "Most Recent is not selected by default.");
        Assert.assertEquals(statementsCheckboxContainer.getAttribute("checkable"), "true", "Statements is not selected by default.");
        Assert.assertEquals(statementsCheckboxContainer.getAttribute("checked"), "true", "Statements is not selected by default.");
        Assert.assertEquals(statementsCheckboxContainer.getAttribute("clickable"), "false", "Statements is not selected by default.");
    }
}
