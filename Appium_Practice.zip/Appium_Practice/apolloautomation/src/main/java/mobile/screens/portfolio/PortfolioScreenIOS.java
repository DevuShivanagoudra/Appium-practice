package mobile.screens.portfolio;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.MobileBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static io.appium.java_client.pagefactory.LocatorGroupStrategy.ALL_POSSIBLE;
import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class PortfolioScreenIOS extends PortfolioScreenBase<IOSCustomDriver> {

    private static final String MYPORTFOLIOHOLDING_VIEWOPTION = "**/XCUIElementTypeButton[`label == \"%s\"`]";
    private static final String MYPORTFOLIOHOLDING_GROUPBYOPTION = MYPORTFOLIOHOLDING_VIEWOPTION;
    private static final String VIEW_OPTION = MYPORTFOLIOHOLDING_VIEWOPTION;
    private static final String CUSIP_LOCATOR = "//XCUIElementTypeStaticText[@name=\"%s\"]";
    private static final String NORESULTS_MESSAGE = "**/XCUIElementTypeStaticText[`label == \"No results match the selected criteria\"`][1]";
    private static final String SHORTTERMTEXT_LOCATOR = "**/XCUIElementTypeStaticText[`label == \"Short-Term\"`]";
    private static final String LONGTERMTEXT_LOCATOR = "**/XCUIElementTypeStaticText[`label == \"Long-Term\"`]";
    private static final String STOCKDESCRIPTION_LOCATOR = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";

    @HowToUseLocators(iOSXCUITAutomation = ALL_POSSIBLE)
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Realized Gain / (Loss) Summary\"]/following-sibling::*")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Realized Gain/(Loss) Summary\"]/following-sibling::*")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Unrealized Gain/(Loss) Summary\"]/following-sibling::*")
    protected List<WebElement> gainLossDetails;

    @iOSXCUITFindBy(xpath = "((//XCUIElementTypeStaticText[@name=\"Short-Term\"]//following::XCUIElementTypeStaticText[@name=\"Gain\"] )[1]//following-sibling:: XCUIElementTypeOther/XCUIElementTypeStaticText)[1]")
    private WebElement shortTermGainIntegralPart;

    @iOSXCUITFindBy(xpath = "((//XCUIElementTypeStaticText[@name=\"Short-Term\"]//following::XCUIElementTypeStaticText[@name=\"Loss\"] )[1]//following-sibling:: XCUIElementTypeOther/XCUIElementTypeStaticText)[1]")
    private WebElement shortTermLossIntegralPart;

    @iOSXCUITFindBy(xpath = "((//XCUIElementTypeStaticText[@name=\"Short-Term\"]//following::XCUIElementTypeStaticText[@name=\"Subtotal\"] )[1]//following-sibling:: XCUIElementTypeOther/XCUIElementTypeStaticText)[1]")
    private WebElement shortTermSubTotalIntegralPart;

    @iOSXCUITFindBy(xpath = "((//XCUIElementTypeStaticText[@name=\"Long-Term\"]//following::XCUIElementTypeStaticText[@name=\"Gain\"] )[1]/following-sibling:: XCUIElementTypeOther/XCUIElementTypeStaticText)[1]")
    private WebElement longTermGainIntegralPart;

    @iOSXCUITFindBy(xpath = "((//XCUIElementTypeStaticText[@name=\"Long-Term\"]//following::XCUIElementTypeStaticText[@name=\"Loss\"] )[1]/following-sibling:: XCUIElementTypeOther/XCUIElementTypeStaticText)[1]")
    private WebElement longTermLossIntegralPart;

    @iOSXCUITFindBy(xpath = "((//XCUIElementTypeStaticText[@name=\"Long-Term\"]//following::XCUIElementTypeStaticText[@name=\"Subtotal\"] )[1]/following-sibling:: XCUIElementTypeOther/XCUIElementTypeStaticText)[1]")
    private WebElement longTermSubTotalAmountIntegralPart;

    @iOSXCUITFindBy(xpath = "(//*[@name=\"Net Gain / (Loss) Total\"]//following-sibling:: XCUIElementTypeOther/XCUIElementTypeStaticText)[1]")
    private WebElement netGainLossTotalAmountIntegralPart;

    public PortfolioScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void selectMyPortFolioHoldingView(final String viewOption) {
        getDriver().scrollTo(
                AppiumBy.iOSClassChain(String.format(MYPORTFOLIOHOLDING_VIEWOPTION, viewOption)),
                Direction.DOWN, 3).click();
    }

    @Override
    public void selectView(final String viewOption) {
        this.tapFilterButton();
        getDriver().waitUntilVisible(AppiumBy.iOSClassChain(String.format(VIEW_OPTION, viewOption)))
                .click();
    }

    @Override
    public WebElement getCurrentValue(final String cusipName) {
        final String siblingLocator = "/XCUIElementTypeStaticText";
        getDriver().scrollTo(By.xpath(String.format(CUSIP_LOCATOR, cusipName)), Direction.UP_SMALL,
                5);
        return getDriver().waitUntilPresent(By.xpath(
                String.format(CUSIP_LOCATOR, String.format("%s%s", cusipName, " - currentValue"))));
    }

    @Override
    public WebElement getCurrentValueChange(final String cusipName) {
        final String siblingLocator = "/XCUIElementTypeOther";
        return CommonUtils.getSiblingUsingxPath(getDriver(),
                String.format(CUSIP_LOCATOR, cusipName), siblingLocator, 0);
    }

    @Override
    public WebElement getpriceChange(final String cusipName) {
        final String siblingLocator = "/XCUIElementTypeOther";
        return CommonUtils.getSiblingUsingxPath(getDriver(),
                String.format(CUSIP_LOCATOR, cusipName), siblingLocator, 1);
    }

    public WebElement getPercentageChange(final String cusipName) {
        final String siblingLocator = "/XCUIElementTypeStaticText";
        return CommonUtils.getSiblingUsingxPath(getDriver(),
                String.format(CUSIP_LOCATOR, cusipName), siblingLocator, 3);
    }

    @Override
    public void selectMyPortFolioHoldingGroupBy(final String viewOption) {
        getMyPortFolioHoldings_GroupBySelectable().click();
        getDriver().waitUntilVisible(
                        AppiumBy.iOSClassChain(String.format(MYPORTFOLIOHOLDING_VIEWOPTION, viewOption)))
                .click();
    }

    @Override
    public WebElement getTotalValue(final String text) {
        final String siblingLocator = "/XCUIElementTypeStaticText";
        return CommonUtils.getSiblingUsingxPath(getDriver(), String.format(CUSIP_LOCATOR, text),
                siblingLocator, 1);
    }

    @Override
    public WebElement getRecordDescription(final String cusipName) {
        final String siblingLocator = "/XCUIElementTypeStaticText";
        CommonUtils.scrollToElement(getDriver(), By.xpath(String.format(CUSIP_LOCATOR, cusipName)),
                Direction.UP_SMALL, 3);
        return CommonUtils.getSiblingUsingxPath(getDriver(),
                String.format(CUSIP_LOCATOR, cusipName), siblingLocator, 1);
    }

    public void tapUnrealizedGainLoss() {
        //FIXME:Ticket 1354549: Unrealized Gain / (Loss) static text is not visible, should be working fine  after bug is fixed
        getDriver().tap(getUnrealizedGainLossSection());
    }

    @Override
    public Map<String, String> fetchGainLossDetails() {
        Map<String, String> unrealizedGainLoss = new LinkedHashMap<>();
        unrealizedGainLoss.put(gainLossDetails.get(0).getAttribute("name"), "");
        unrealizedGainLoss.put(gainLossDetails.get(1).getAttribute("label").split(", ")[0],
                gainLossDetails.get(1).getAttribute("label").split(", ")[1]);
        unrealizedGainLoss.put(gainLossDetails.get(2).getAttribute("label").split(", ")[0],
                gainLossDetails.get(2).getAttribute("label").split(", ")[1]);
        unrealizedGainLoss.put(gainLossDetails.get(3).getAttribute("label").split(", ")[0],
                gainLossDetails.get(3).getAttribute("label").split(", ")[1]);
        unrealizedGainLoss.put(gainLossDetails.get(4).getAttribute("name"), "");
        unrealizedGainLoss.put(String.format("longTerm%s",
                        gainLossDetails.get(5).getAttribute("label").split(", ")[0]),
                gainLossDetails.get(5).getAttribute("label").split(", ")[1]);
        unrealizedGainLoss.put(String.format("longTerm%s",
                        gainLossDetails.get(6).getAttribute("label").split(", ")[0]),
                gainLossDetails.get(6).getAttribute("label").split(", ")[1]);
        unrealizedGainLoss.put(String.format("longTerm%s",
                        gainLossDetails.get(7).getAttribute("label").split(", ")[0]),
                gainLossDetails.get(7).getAttribute("label").split(", ")[1]);
        unrealizedGainLoss.put(gainLossDetails.get(8).getAttribute("label").split(", ")[0],
                gainLossDetails.get(8).getAttribute("label").split(", ")[1]);
        return unrealizedGainLoss;
    }

    @Override
    public void waitForRealizedGLToLoad() {
        getDriver().waitUntilCondition(70, ExpectedConditions.or(
                        ExpectedConditions.presenceOfElementLocated(
                                AppiumBy.iOSClassChain(SHORTTERMTEXT_LOCATOR)),
                        ExpectedConditions.presenceOfElementLocated(
                                AppiumBy.iOSClassChain(LONGTERMTEXT_LOCATOR)),
                        ExpectedConditions.presenceOfElementLocated(
                                AppiumBy.iOSClassChain(String.format(NORESULTS_MESSAGE)))),
                "No Result Message/Realized Gain/Loss Details not displayed.");
    }

    @Override
    public void tapARecordUsingCusip(final String cusipName) {
        getRecordDescription(cusipName).click();
    }

    public void tapARecord(final String cusipName) {
        WebElement record = CommonUtils.scrollToElement(getDriver(),
                AppiumBy.iOSClassChain(String.format(STOCKDESCRIPTION_LOCATOR, cusipName)),
                Direction.UP_SMALL, 5);
        //Utils.tapElement(getDriver(), record);
        getDriver().tap(record);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.attributeToBe(getCurrentValue(), "enabled", "true"),
                                ExpectedConditions.visibilityOf(getMyPortFolioHoldings_GroupBySelectable()),
                                ExpectedConditions.presenceOfElementLocated(
                                        MobileBy.iOSClassChain(String.format(NORESULTS_MESSAGE)))),
                "No Result message or the first holding record is not displayed.");
    }


    public void verifyColorAmountInUnrealizedSummary() {
        getDriver().swipeScreen(Direction.DOWN);


        if (shortTermGainAmt > 0) {
            Assert.assertEquals(returnFirstCharacterByValue(shortTermGainIntegralPart), '$', "Short-Term Gain amount is not in green color.");
        } else {
            Assert.assertEquals(shortTermGainAmt, 0, "Short-Term Gain amount is not in black color.");
            Assert.assertEquals(returnFirstCharacterByValue(shortTermGainIntegralPart), '$', "Short-Term Gain amount is not in black color.");
        }

        if (shortTermLossAmt < 0) {
            Assert.assertEquals(returnFirstCharacterByValue(shortTermLossIntegralPart) == '(', "Short-Term Loss amount is not in red color.");
        } else {
            Assert.assertEquals(shortTermLossAmt, 0, "Short-Term Loss amount is not in black color.");
            Assert.assertEquals(returnFirstCharacterByValue(shortTermLossIntegralPart), '$', "Short-Term Loss amount is not in black color.");
        }

        if (shortTermSubTotalAmt > 0) {
            Assert.assertEquals(returnFirstCharacterByValue(shortTermSubTotalIntegralPart), '$', "Short-Term Sub Total amount is not in green color.");
        } else if (shortTermSubTotalAmt < 0) {
            Assert.assertEquals(returnFirstCharacterByValue(shortTermSubTotalIntegralPart), '(', "Short-Term Sub Total amount is not in red color.");
        } else {
            Assert.assertEquals(returnFirstCharacterByValue(shortTermSubTotalIntegralPart), '$', "Short-Term Sub Total amount is not in black color.");
        }

        if (longTermGainAmt > 0) {
            Assert.assertEquals(returnFirstCharacterByValue(longTermGainIntegralPart), '$', "Long-Term Gain amount is not in green color.");
        } else {
            Assert.assertEquals(longTermGainAmt, 0, "Long-Term gain amount is not in black color.");
            Assert.assertEquals(returnFirstCharacterByValue(longTermGainIntegralPart), '$', "Long-Term gain amount is not in black color.");
        }

        if (longTermLossAmt < 0) {
            Assert.assertEquals(returnFirstCharacterByValue(longTermLossIntegralPart), '(', "Long-Term Loss amount is not in red color.");
        } else {
            Assert.assertEquals(longTermLossAmt, 0, "Long-Term Loss amount is not in black color.");
            Assert.assertEquals(returnFirstCharacterByValue(longTermLossIntegralPart), '$', "Long-Term Loss amount is not in black color.");
        }

        if (longTermSubTotalAmt > 0) {
            Assert.assertEquals(returnFirstCharacterByValue(longTermSubTotalAmountIntegralPart), '$', "Long-Term Sub Total amount is not in green color.");
        } else if (shortTermSubTotalAmt < 0) {
            Assert.assertEquals(returnFirstCharacterByValue(longTermSubTotalAmountIntegralPart), '(', "Long-Term Sub Total amount is not in red color.");
        } else {
            Assert.assertEquals(returnFirstCharacterByValue(longTermSubTotalAmountIntegralPart), '$', "Long-Term Sub Total amount is not in black color.");
        }

        if (netGainLossTotalAmt > 0) {
            Assert.assertEquals(returnFirstCharacterByValue(netGainLossTotalAmountIntegralPart), '$', "Net Gain Loss Total amount is not in green color.");
        } else if (netGainLossTotalAmt < 0) {
            Assert.assertEquals(returnFirstCharacterByValue(netGainLossTotalAmountIntegralPart), '(', "Net Gain Loss Total amount is not in red color.");
        } else {
            Assert.assertEquals(returnFirstCharacterByValue(netGainLossTotalAmountIntegralPart), '$', "Net Gain Loss Total amount is not in black color.");
        }
    }

    public void verifyColorAmountInPortfolioHoldings() {
        getDriver().scrollTo(getValueChangeButton()).click();
        Assert.assertEquals(returnFirstCharacterByValue(getDailyValueChangeSubHeaderAmount()), '$', "Amount in value is not 0 or positive as required.");
        Assert.assertEquals(returnFirstCharacterByValue(getDvcFirstRecordChangedAmount()), '$', "Amount in value is not 0 or positive as required.");
        final char dvcValueInPercent = returnFirstCharacterByText(getDvcFirstRecordChangeInAmountPercent());
        switch (returnFirstCharacterByValue(getDvcFirstRecordChangeInAmount())) {
            case '$':
                Assert.assertEquals(dvcValueInPercent, '$', "Amount in value is not 0 or positive as required.");
                break;
            case '(':
                Assert.assertEquals(dvcValueInPercent, '(', "Amount in % is not a negative value as required.");
                break;
            default:
                Assert.fail("Error while verifying color of amounts in Position Holdings.");
        }
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT, ExpectedConditions.or(
                        ExpectedConditions.attributeToBe(getCurrentValue(), "enabled", "true"),
                        ExpectedConditions.visibilityOf(getMyPortFolioHoldings_GroupBySelectable()),
                        ExpectedConditions.presenceOfElementLocated(
                                AppiumBy.iOSClassChain(String.format(NORESULTS_MESSAGE)))),
                "No Result message or the first holding record is not displayed.");
    }

    public boolean verifyAccountsSelected(final int i) {
        return getDriver().isElementVisible(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`label == \"Accounts (" + i + ")\"`]"));
    }
}
