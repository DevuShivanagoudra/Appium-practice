package mobile.screens.twofactorauthentication;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.ios.IOSUtils;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Getter
public class TwoFactorAuthenticationScreenIOS extends
        TwoFactorAuthenticationScreenBase<IOSCustomDriver> {

    private static final String PHONE_LOCATOR = "**/XCUIElementTypeButton[`label == \"XXX-XXX-%s\"`]";
    private static final String MODE_LOCATOR = "**/XCUIElementTypeButton[`label CONTAINS[cd] \"%s\"`]";

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label BEGINSWITH[cd] \"XXX-\"`]")
    private WebElement phoneNumberWildCard;

    public TwoFactorAuthenticationScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    /**
     * Submits default Answer on Secret Question screen.
     */
    @Override
    public void submit2FASecurity(final String phone, final String codeSendingMode, final Toggle state) {
        if (!isPhoneNumberVisible(phone)) {
            getPhoneSelectable().click();
            waitForPhoneNumbersToLoad();
            selectPhoneNumber(phone);
        }
        getMethodSelectable().click();
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(MODE_LOCATOR, codeSendingMode))).click();
        if (getDriver().isElementVisible(getTrustThisDevice())) {
            setRememberOnDeviceToggle(state.getBoolValue());
        }
        getSubmitButton().click();
    }

    @Override
    public void setRememberOnDeviceToggle(final boolean toggleState) {
        IOSUtils.setToggle(getDriver(), getTrustThisDevice(), toggleState);
    }

    public boolean isTextMoBileOnlyChecked() {
        return getTextMobileOnly().getAttribute("value") == "0" ? false : true;
    }

    @Override
    public void selectPhoneNumber(final String phone) {
        getDriver().waitUntilVisible(
                AppiumBy.iOSClassChain(String.format(PHONE_LOCATOR, phone))).click();
    }

    @Override
    public List<String> getMethodValues() {
        return getMethodValueList()
                .stream()
                .map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
    }

    @Override
    public void tapPhoneNumberList() {
        getPhoneSelectable().click();
    }

    @Override
    public void waitForPhoneNumbersToLoad() {
        getDriver().waitUntilVisible(phoneNumberWildCard,
                "Phone Numbers Dropdown is not displayed.");
    }

    @Override
    public boolean isPhoneNumberVisible(final String phoneNumber) {
        return getDriver()
                .isElementVisible(AppiumBy.iOSClassChain(String.format(PHONE_LOCATOR, phoneNumber)));
    }
}
