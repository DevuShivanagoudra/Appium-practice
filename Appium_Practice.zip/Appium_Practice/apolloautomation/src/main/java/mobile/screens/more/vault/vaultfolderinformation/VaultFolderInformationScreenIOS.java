package mobile.screens.more.vault.vaultfolderinformation;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class VaultFolderInformationScreenIOS extends
        VaultFolderInformationScreenBase<IOSCustomDriver> {

    public VaultFolderInformationScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
