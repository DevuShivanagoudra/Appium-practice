package mobile.screens.more.morereorder;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import java.util.List;

import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class MoreReorderScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Documents\"]/../XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"name\")")
    protected List<WebElement> tabBarContainer;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Documents\"]/../XCUIElementTypeButton")
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"trailingIcon\")")
    protected List<WebElement> tabBarMoveIcons;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Preferences\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").instance(0)")
    private WebElement backButton;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"Done\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().text(\"Save\")")
    private WebElement saveButton;

    protected MoreReorderScreenBase(final D driver) {
        super(driver);
    }

    public abstract List<String> getTabBarNames();

    public abstract WebElement getTabbarDragIcon(final String tabbarName);

    public abstract boolean isTabbarNameVisible(final String tabbarName);

    /**
     * Taps on Save button.
     */
    public void tapSave() {
        saveButton.click();
    }

    /**
     * Taps on Back button.
     */
    public void tapBack() {
        backButton.click();
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(saveButton, DEFAULT_WAIT_TIMEOUT,
                "More ReOrder Screen is not displayed.");
    }
}
