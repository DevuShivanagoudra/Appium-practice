package mobile.screens.disclosures;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.screens.CommonScreenBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;

import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;

@Slf4j
@Getter
public abstract class FeatureDisclosuresScreenBase<D extends CustomDriver> extends
        CommonScreenBase<D> {

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name CONTAINS \"Raymond James & Associates\"`]")
    @AndroidFindBy(uiAutomator = "new UiSelector().descriptionContains(\"Raymond James & Associates\")")
    private WebElement disclosuresText;

    protected FeatureDisclosuresScreenBase(final D driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilPresent(disclosuresText, DEFAULT_WAIT_TIMEOUT);
    }
}
