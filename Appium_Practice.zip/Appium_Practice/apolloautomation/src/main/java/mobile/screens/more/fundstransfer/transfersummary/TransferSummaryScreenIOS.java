package mobile.screens.more.fundstransfer.transfersummary;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
public class TransferSummaryScreenIOS extends
        TransferSummaryScreenBase<IOSCustomDriver> {

    public TransferSummaryScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }
}
