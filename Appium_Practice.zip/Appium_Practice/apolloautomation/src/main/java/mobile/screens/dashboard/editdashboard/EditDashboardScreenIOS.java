package mobile.screens.dashboard.editdashboard;

import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
@Getter
public class EditDashboardScreenIOS extends EditDashboardScreenBase<IOSCustomDriver> {

    public EditDashboardScreenIOS(IOSCustomDriver driver) {
        super(driver);
    }

    @Override
    public void waitToLoad() {
        getDriver().waitUntilVisible(getDragIcon(), MAXIMUM_WAIT_TIMEOUT,
                "Edit Dashboard Screen is not displayed.");
    }
}
