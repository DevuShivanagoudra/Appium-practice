package mobile.screens.widgets.tabbar;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import mobile.common.constants.TabBarOption;
import org.openqa.selenium.WebElement;

public class TabBarAndroid extends TabBarBase<AndroidCustomDriver> {

    private final String TABBAR_LOCATOR = "new UiSelector().text(\"%s\")";

    public TabBarAndroid(
            AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    protected WebElement getOption(TabBarOption option) {
        // Will be re-factored back after re-work in the script files completes
        if (option.toString().equalsIgnoreCase("analysis")) {
            getDriver().waitUntilVisible(AppiumBy.
                    androidUIAutomator(String.format(TABBAR_LOCATOR, "More"))).click();
            return getDriver().waitUntilVisible(AppiumBy.
                    androidUIAutomator(String.format(TABBAR_LOCATOR, "Analysis")));
        } else {
            return getDriver().waitUntilVisible(
                    AppiumBy.androidUIAutomator(String.format(TABBAR_LOCATOR, option.toString())));
        }
    }
}
