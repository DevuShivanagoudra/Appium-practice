package mobile.screens.analysis.filter;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class AnalysisFilterScreenAndroid extends
        AnalysisFilterScreenBase<AndroidCustomDriver> {

    private static final String GROUPHEADER_LOCATOR = "//*[@text='%s']";
    private static final String ACCOUNTNAMES_LOCATOR = "//android.widget.CheckBox/preceding-sibling::android.widget.TextView";
    private static final String ACCOUNTSELECTEDICON_LOCATOR = "new UiSelector().text(\"%s\").fromParent(new UiSelector().className(\"android.view.View\"))";
    private static final String ACCOUNTNAME_LOCATOR = "new UiSelector().text(\"%s\")";
    private static final String ACCOUNTS_IN_GROUP = "//*[@text = '%s']/../following-sibling::*[1]//android.widget.TextView";

    @HowToUseLocators(androidAutomation = LocatorGroupStrategy.ALL_POSSIBLE)
    @AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"TopBar-IconButton\")")
    @AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\")")
    private WebElement backButton;

    public AnalysisFilterScreenAndroid(AndroidCustomDriver driver) {
        super(driver);
    }

    @Override
    public void tapBack() {
        backButton.click();
    }

    /**
     * Fetches Account group's Expand/Collapse icons.
     *
     * @param GroupName String
     * @return
     */
    public WebElement getGroupExpandableIcon(final String GroupName) {
        return CommonUtils
                .getSiblingUsingxPath(getDriver(), String.format(GROUPHEADER_LOCATOR, GroupName), 1);
    }

    /**
     * Fetches Account names that are visible.
     *
     * @return
     */
    public List<WebElement> getAccounts() {
        return getDriver().findElements(By.xpath(ACCOUNTNAMES_LOCATOR));
    }

    /**
     * Fetches Account Names.
     *
     * @return List of String
     */
    public List<String> getAccountNames() {
        return getDriver().findAll(By.xpath(ACCOUNTNAMES_LOCATOR))
                .stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    /**
     * Fetches Account Names in Group.
     *
     * @return List of String
     */
    public List<String> getAccountsInGroup(final String groupName) {
        return getDriver().findAll(By.xpath(String.format(ACCOUNTS_IN_GROUP, groupName)))
                .stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
    }

    @Override
    public void selectDeselectAccount(final String accountName, final boolean state) {
        if (state && !getDriver().isElementVisible(
                AppiumBy.androidUIAutomator(String.format(ACCOUNTSELECTEDICON_LOCATOR, accountName))) ||
                !state && getDriver().isElementVisible(
                        AppiumBy
                                .androidUIAutomator(String.format(ACCOUNTSELECTEDICON_LOCATOR, accountName)))) {
            getDriver().waitUntilVisible(
                            AppiumBy.androidUIAutomator(String.format(ACCOUNTNAME_LOCATOR, accountName)))
                    .click();
        }
    }

    @Override
    public WebElement getAccountSelectedIcon(final String accountName) {
        return getDriver().waitUntilVisible(
                AppiumBy.androidUIAutomator(String.format(ACCOUNTSELECTEDICON_LOCATOR, accountName)));
    }

    @Override
    public boolean isAccountSelectedIconVisible(final String accountName) {
        return getDriver().isElementVisible(
                AppiumBy.androidUIAutomator(String.format(ACCOUNTSELECTEDICON_LOCATOR, accountName)));
    }

    @Override
    public void waitUntilAccountsLoaded() {
        getDriver().waitUntilCondition(
                ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(ACCOUNTNAMES_LOCATOR), 2));
    }
}
