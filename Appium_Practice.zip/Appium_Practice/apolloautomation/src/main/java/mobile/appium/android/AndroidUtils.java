package mobile.appium.android;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import jarvis.mobile.common.driver.CustomDriver;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;

import java.util.List;

public class AndroidUtils {

    private static final String APP_PACKAGE = "com.raymondjames.investoraccessalpha";
    private static final String MAIN_ACTIVITY = "com.raymondjames.apollo.MainActivity";
    private static final int MAXIMUM_WAIT_TIMEOUT = 30;

    private AndroidUtils() {
    }

    public static void setCheckBox(final AndroidCustomDriver driver,
                                   final WebElement toggleElement, final boolean toggleState) {
        driver.waitUntilClickable(toggleElement, MAXIMUM_WAIT_TIMEOUT, "Element Not Ready.");
        if (toggleState && !driver.isElementChecked(toggleElement) ||
                !toggleState && driver.isElementChecked(toggleElement)) {
            toggleElement.click();
            driver.waitUntilClickable(toggleElement);
            driver.waitUntilCheckedState(toggleElement, toggleState);
        }
    }

    public static void setToggle(final AndroidCustomDriver driver,
                                 final WebElement toggleElement, final boolean toggleState) {
        setCheckBox(driver, toggleElement, toggleState);
    }

    public static WebElement getSibling(final CustomDriver driver, final String elementLocator,
                                        int siblingIndex) {
        List<WebElement> elements = driver
                .findElements(AppiumBy.androidUIAutomator(String.format("%s%s", elementLocator,
                        ".fromParent(new UiSelector().classNameMatches(\"android.*\"))")));
        return elements.get(siblingIndex);
    }

    public static List<WebElement> getChildren(final CustomDriver driver,
                                               final WebElement element) {
        final String childLocator = "new UiSelector().classNameMatches(\"android.*\")";
        return driver.findAll(element, AppiumBy.androidUIAutomator(childLocator));
    }

    public static boolean isElementInteractive(final WebElement element) {
        try {
            return Boolean.parseBoolean(element.getAttribute("clickable"));
        } catch (NoSuchElementException | StaleElementReferenceException e) {
            return false;
        }
    }
}
