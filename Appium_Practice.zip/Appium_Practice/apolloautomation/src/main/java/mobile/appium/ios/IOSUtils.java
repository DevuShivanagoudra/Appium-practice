package mobile.appium.ios;

import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.CustomDriver;
import mobile.appium.CommonUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.ArrayList;
import java.util.List;

public class IOSUtils {

    private static final int MAXIMUM_WAIT_TIME = 30;

    private IOSUtils() {
    }

    public static void setToggle(final CustomDriver driver, final WebElement toggleElement,
                                 final boolean toggleState) {
        //FIXME: TypeSwitch "Visible" property is set to "false"(IOS16).
        //driver.scrollToElement(toggleElement);
        CommonUtils.scrollToElement(driver, toggleElement, Direction.UP, 10);
        if (toggleState && toggleElement.getAttribute("value").equals("0")) {
            toggleElement.click();
            driver
                    .waitUntilCondition(ExpectedConditions.attributeToBe(toggleElement, "value", "1"));
        } else if (!toggleState && toggleElement.getAttribute("value").equals("1")) {
            toggleElement.click();
            driver
                    .waitUntilCondition(ExpectedConditions.attributeToBe(toggleElement, "value", "0"));
        }
    }

    public static boolean getToggleState(final WebElement toggleElement) {
        if (toggleElement.getAttribute("value").equalsIgnoreCase("1")) {
            return true;
        }
        return false;
    }

    public static void setRadioToggle(final CustomDriver driver, final WebElement toggleElement,
                                      final boolean toggleState) {
        driver.scrollTo(toggleElement);
        if (toggleState && !hasAttribute(toggleElement, "value")) {
            toggleElement.click();
            driver.waitUntilClickable(toggleElement, MAXIMUM_WAIT_TIME,
                    "Element is not clickable yet.");
            driver
                    .waitUntilCondition(
                            ExpectedConditions.attributeToBe(toggleElement, "value", "selected"));
        } else if (!toggleState && hasAttribute(toggleElement, "value")) {
            toggleElement.click();
        }
    }

    public static List<WebElement> getChildren(final CustomDriver driver,
                                               final WebElement element) {
        List<WebElement> elements = new ArrayList<>();
        List<WebElement> children = element.findElements(By.xpath("//*"));
        for (WebElement e : children) {
            elements.add(e);
        }
        return elements;
    }

    public static boolean isElementSelected(final WebElement element) {
        return hasAttribute(element, "value");
    }

    /**
     * Checks whether an element has a attribute.
     *
     * @param element IOSElement
     * @return boolean
     */
    public static boolean hasAttribute(final WebElement element, final String value) {
        try {
            if (null == element.getAttribute(value)) {
                return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}