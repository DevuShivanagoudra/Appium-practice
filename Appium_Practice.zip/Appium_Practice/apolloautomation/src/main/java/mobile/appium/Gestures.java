package mobile.appium;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import jarvis.mobile.appium.Utils;
import jarvis.mobile.common.driver.DriverFactory;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.Point;

import java.time.Duration;

@Slf4j
public class Gestures extends DriverFactory {
    //works for only android as iOS has Javascript executor methods.

    private static final double traySizeMultiplyFactor = 1.068;

    private Gestures() {
    }

    private static void swipe(AppiumDriver driver, Point start, Point end) {
        TouchAction touchAction = new TouchAction((PerformsTouchActions) driver);
        try {
            touchAction.press(PointOption.point(start))
                    .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1L)))
                    .moveTo(PointOption.point(end)).release().perform();
        } catch (Exception var5) {
            log.error("Swiping Up failed. Start and End coordinates used {{}, {}}", start, end);
        }
        jarvis.mobile.appium.Utils.letScreenSettle();
    }

    // FIXME: switch to Actions API after my investigation
    private static void swipeWithLag(AppiumDriver driver, Point start,
                                     Point end) {
        TouchAction touchAction = new TouchAction((PerformsTouchActions) driver);
        try {
            touchAction.press(PointOption.point(start))
                    .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1L)))
                    .moveTo(PointOption.point(end))
                    .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1L))).release()
                    .perform();
        } catch (Exception var5) {
            log.error("Swiping Up failed. Start and End coordinates used {{}, {}}", start, end);
        }

        Utils.letScreenSettle();
    }

    public void backgroundApp() {
        Point startPoint = new Point(
                getDriver().manage().window().getPosition().getX()
                        + getDriver().manage().window().getSize().width / 2,
                (int) (getDriver().manage().window().getSize().getHeight() * traySizeMultiplyFactor));
        Point endPoint = new Point(getDriver().manage().window().getSize().width / 2,
                getDriver().manage().window().getSize().height / 2);
        getDriver().swipeScreen(startPoint, endPoint);
        swipe(getDriver(), startPoint, endPoint);
    }

    public void closeApp() {
        launchSwitcher();
        Point startPoint = new Point(getDriver().manage().window().getSize().width / 2,
                (int) (getDriver().manage().window().getSize().height * 0.7));
        Point endPoint = new Point(
                getDriver().manage().window().getPosition().getX()
                        + getDriver().manage().window().getSize().width / 2,
                (int) (getDriver().manage().window().getSize().height * 0.2));
        swipe(getDriver(), startPoint, endPoint);
    }

    // FIXME: switch to Actions API after my investigation
    public void activateLastApp() {
        launchSwitcher();
        Point clickPoint = new Point(getDriver().manage().window().getSize().width / 2,
                getDriver().manage().window().getSize().height / 2);
        TouchAction touchAction = new TouchAction((PerformsTouchActions) getDriver());
        touchAction.tap(PointOption.point(getDriver().manage().window().getSize().width / 2,
                getDriver().manage().window().getSize().height / 2)).perform();
    }

    public void launchSwitcher() {
        double screenHeight =
                getDriver().manage().window().getSize().getHeight() * traySizeMultiplyFactor;
        Point startPoint = new Point(
                getDriver().manage().window().getPosition().getX()
                        + getDriver().manage().window().getSize().width / 2,
                (int) (screenHeight));
        Point endPoint = new Point(getDriver().manage().window().getSize().width / 2,
                (int) (getDriver().manage().window().getSize().height * 0.8));
        swipeWithLag(getDriver(), startPoint, endPoint);
    }
}
