package mobile.appium;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.InteractsWithApps;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.CustomDriver;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

@Slf4j
@Getter
public class CommonUtils {

    private CommonUtils() {

    }

    // selenium clear() is not clearing the leading space.
    public static boolean replaceText(CustomDriver driver, final WebElement element,
                                      final String text) {
        driver.scrollTo(element).click();
        element.clear();
        while (element.getText().contains(" ")) {
            element.sendKeys(Keys.BACK_SPACE);
        }
        element.sendKeys(text);
        driver.waitUntilClickable(element);
        return (Boolean) driver
                .waitUntilCondition(5, ExpectedConditions
                                .or(ExpectedConditions.attributeToBeNotEmpty(element, "value"),
                                        ExpectedConditions.attributeToBeNotEmpty(element, "text")),
                        String
                                .format("Could not replace text in element.%nElement: %s%nText to replace: %s",
                                        element, text));
    }

    public static void dragDropElement(AppiumDriver driver, final WebElement elementToDrag,
                                       final WebElement elementToDragOnto) {
        Actions actions = new Actions(driver);
        actions.dragAndDrop(elementToDrag, elementToDragOnto);
    }

    /*DISCLAIMER:
     To be used when the property of the element "visible" is not working as expected.
     Some of the elements do have their "visible" property set to "false" all the time (app issue).
     */
    public static WebElement scrollToElement(CustomDriver driver, WebElement element,
                                             Direction direction, int matTryout) {
        for (int attempt = 0; attempt < matTryout; ++attempt) {
            if (driver.isElementPresent(element)) {
                return driver.find(element);
            }
            driver.swipeScreen(direction);
        }
        throw new NotFoundException(String.format("Could not scroll to element: %s", element));
    }

    /*DISCLAIMER:
    To be used when the property of the element "visible" is not working as expected.
    Some of the elements do have their "visible" property set to "false" all the time (app issue).
    */
    public static WebElement scrollToElement(CustomDriver driver, By by,
                                             Direction direction, int matTryout) {
        for (int attempt = 0; attempt < matTryout; ++attempt) {
            if (driver.isElementPresent(by)) {
                return driver.find(by);
            }
            driver.swipeScreen(direction);
        }
        throw new NotFoundException(
                String.format("Could not scroll to element with locator: %s", by));
    }

    public static WebElement getSiblingUsingxPath(final CustomDriver driver,
                                                  final String elementLocator,
                                                  int siblingIndex) {
        List<WebElement> elements = driver
                .findElements(By.xpath(String.format("%s%s", elementLocator,
                        "/../*")));
        return elements.get(siblingIndex);
    }

    public static WebElement getSiblingUsingxPath(final CustomDriver driver,
                                                  final String elementLocator, final String siblingLocator,
                                                  int siblingIndex) {
        List<WebElement> elements = driver
                .findElements(By.xpath(String.format("%s%s%s", elementLocator,
                        "/..", siblingLocator)));
        return elements.get(siblingIndex);
    }

    public static WebElement getSiblingUsingxPath(final WebElement element,
                                                  int siblingIndex) {
        List<WebElement> elements = element.findElements(By.xpath("/../*"));
        return elements.get(siblingIndex);
    }

    public static List<WebElement> getChildrenUsingxPath(final CustomDriver driver,
                                                         final WebElement element) {

        return driver.findAll(element, By.xpath("//*"));
    }

    public static void terminateApp(CustomDriver driver, final String appPackageOrBundleID) {
        try {
            ((InteractsWithApps) driver).terminateApp(appPackageOrBundleID);
        } catch (Exception e) {
            ((InteractsWithApps) driver).terminateApp(appPackageOrBundleID);
        }
    }
}
