package api.utils;

public enum Accounts {
    USERNAME1("quacky1"),
    USERNAME2("testdoc"),
    USERNAME3("atimitest"),
    USERNAME31("atimitest2"),
    USERNAME4("myclient14"),
    USERNAME5("to_king_camp"),
    USERNAME6("rjbank_multi"),
    USERNAME7("rsatest_7"),
    USERNAME8("at_ba_rjbanktest"),
    USERNAME9("docmgmt1"),
    USERNAME10("fullaccessdoc"),
    USERNAME11("vault001"),
    USERNAME12("do_wilson_bob_62_005"),
    USERNAME_NO_LIABILITIES("at_ba_enroll"),
    CKGUSER("banktype46"),
    PASSWORD("P@ssw0rd1");

    private final String value;

    Accounts(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}
