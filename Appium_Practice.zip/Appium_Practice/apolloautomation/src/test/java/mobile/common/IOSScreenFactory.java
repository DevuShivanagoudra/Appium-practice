package mobile.common;

import jarvis.mobile.common.ScreenFactory;
import jarvis.mobile.common.driver.IOSCustomDriver;
import mobile.screens.SupportWebPageScreen.SupportWebPageScreenIOS;
import mobile.screens.accounts.AccountsScreenIOS;
import mobile.screens.accounts.accountdetail.AccountDetailScreenIOS;
import mobile.screens.alerts.vaultdeletefolderalert.VaultDeleteFolderAlertIOS;
import mobile.screens.analysis.AnalysisScreenIOS;
import mobile.screens.analysis.allocation.AllocationScreenIOS;
import mobile.screens.analysis.allocation.description.AllocationDescriptionScreenIOS;
import mobile.screens.analysis.filter.AnalysisFilterScreenIOS;
import mobile.screens.codeinputscreen.CodeInputScreenIOS;
import mobile.screens.dashboard.DashboardScreenIOS;
import mobile.screens.dashboard.editdashboard.EditDashboardScreenIOS;
import mobile.screens.devicehome.DeviceHomeScreenIOS;
import mobile.screens.disclosures.FeatureDisclosuresScreenIOS;
import mobile.screens.f5access.F5AccessScreenIOS;
import mobile.screens.homescreen.HomeScreenIOS;
import mobile.screens.login.LoginScreenIOS;
import mobile.screens.login.logindisclosure.DisclosuresScreenIOS;
import mobile.screens.more.MoreScreenIOS;
import mobile.screens.more.accountservices.AccountServicesScreenIOS;
import mobile.screens.more.accountservices.documentdelivery.DocumentDeliveryScreenIOS;
import mobile.screens.more.accountservices.documentdelivery.accountdeliveryoptions.AccountDeliveryOptionsScreenIOS;
import mobile.screens.more.accountservices.documentdelivery.edeliveryterms.EDeliveryTermsandConditionsScreenIOS;
import mobile.screens.more.activity.ActivityScreenIOS;
import mobile.screens.more.activity.disclosures.ActivityDisclosuresScreenIOS;
import mobile.screens.more.documents.DocumentsScreenIOS;
import mobile.screens.more.documents.diclosures.DocumentsDisclosuresScreenIOS;
import mobile.screens.more.documents.file.DocumentFileScreenIOS;
import mobile.screens.more.documents.filter.DocumentsFilterScreenIOS;
import mobile.screens.more.documents.termsandconditions.TermsAndConditionsScreenIOS;
import mobile.screens.more.fundstransfer.FundsTransferScreenIOS;
import mobile.screens.more.fundstransfer.history.HistoryScreenIOS;
import mobile.screens.more.fundstransfer.newtransfer.NewTransferScreenIOS;
import mobile.screens.more.fundstransfer.pending.PendingTransferScreenIOS;
import mobile.screens.more.fundstransfer.pendingsummary.PendingTransferSummaryScreenIOS;
import mobile.screens.more.fundstransfer.transfersummary.TransferSummaryScreenIOS;
import mobile.screens.more.fundstransfer.verifytransfer.VerifyTransferScreenIOS;
import mobile.screens.more.marketresearch.marketresearchhome.MarketResearchScreenIOS;
import mobile.screens.more.marketresearch.marketresearchhome.symbolquote.SymbolQuoteScreenIOS;
import mobile.screens.more.marketresearch.marketresearchhome.symbolquote.companydetails.CompanyDetailsScreenIOS;
import mobile.screens.more.morereorder.MoreReorderScreenIOS;
import mobile.screens.more.vault.VaultNewFolderScreenIOS;
import mobile.screens.more.vault.VaultScreenIOS;
import mobile.screens.more.vault.folderdetail.VaultDetailScreenIOS;
import mobile.screens.more.vault.vaultfolderinformation.VaultFolderInformationScreenIOS;
import mobile.screens.notifications.NotificationsScreenIOS;
import mobile.screens.portfolio.PortfolioScreenIOS;
import mobile.screens.portfolio.filteraccounts.PortfolioFilterAccountsScreenIOS;
import mobile.screens.portfolio.portfoliofilter.PortfolioFilterScreenIOS;
import mobile.screens.portfolio.stockdetails.HoldingDetailsScreenIOS;
import mobile.screens.secretquestion.SecretQuestionScreenIOS;
import mobile.screens.signout.SignOutScreenIOS;
import mobile.screens.twofactorauthentication.TwoFactorAuthenticationScreenIOS;
import mobile.screens.widgets.tabbar.TabBarIOS;

public class IOSScreenFactory implements ScreenFactory {

    private final IOSCustomDriver driver;

    public IOSScreenFactory(final IOSCustomDriver driver) {
        this.driver = driver;
    }

    public F5AccessScreenIOS getF5AccessScreen() {
        return new F5AccessScreenIOS(driver);
    }

    public HomeScreenIOS getHomeScreen() {
        return new HomeScreenIOS(driver);
    }

    public TabBarIOS getTabBar() {
        return new TabBarIOS(driver);
    }

    public SecretQuestionScreenIOS getSecretQuestionScreen() {
        return new SecretQuestionScreenIOS(driver);
    }

    public LoginScreenIOS getLoginScreen() {
        return new LoginScreenIOS(driver);
    }

    public DashboardScreenIOS getDashboardScreen() {
        return new DashboardScreenIOS(driver);
    }

    public AccountsScreenIOS getAccountsScreen() {
        return new AccountsScreenIOS(driver);
    }

    public DeviceHomeScreenIOS getDeviceHomeScreen() {
        return new DeviceHomeScreenIOS(driver);
    }

    public SupportWebPageScreenIOS getSupportWebPageScreen() {
        return new SupportWebPageScreenIOS(driver);
    }

    public PortfolioScreenIOS getPortfolioScreen() {
        return new PortfolioScreenIOS(driver);
    }

    public AnalysisScreenIOS getAnalysisScreen() {
        return new AnalysisScreenIOS(driver);
    }

    public MoreScreenIOS getMoreScreen() {
        return new MoreScreenIOS(driver);
    }

    public MoreReorderScreenIOS getMoreReorderScreen() {
        return new MoreReorderScreenIOS(driver);
    }

    public TwoFactorAuthenticationScreenIOS getTwoFactorAuthenticationScreen() {
        return new TwoFactorAuthenticationScreenIOS(driver);
    }

    public CodeInputScreenIOS getCodeInputScreen() {
        return new CodeInputScreenIOS(driver);
    }

    public AccountDetailScreenIOS getAccountDetailScreen() {
        return new AccountDetailScreenIOS(driver);
    }

    public AccountServicesScreenIOS getAccountServicesScreen() {
        return new AccountServicesScreenIOS(driver);
    }

    public DocumentDeliveryScreenIOS getDocumentDeliveryScreen() {
        return new DocumentDeliveryScreenIOS(driver);
    }

    public EditDashboardScreenIOS getEditDashboardScreen() {
        return new EditDashboardScreenIOS(driver);
    }

    public DocumentsScreenIOS getDocumentsScreen() {
        return new DocumentsScreenIOS(driver);
    }

    public DocumentsFilterScreenIOS getDocumentsFilterScreen() {
        return new DocumentsFilterScreenIOS(driver);
    }

    public PortfolioFilterScreenIOS getPortfolioFilterScreen() {
        return new PortfolioFilterScreenIOS(driver);
    }

    public DisclosuresScreenIOS getDisclosuresScreen() {
        return new DisclosuresScreenIOS(driver);
    }

    public DocumentsDisclosuresScreenIOS getDocumentsDisclosuresScreen() {
        return new DocumentsDisclosuresScreenIOS(driver);
    }

    public AllocationScreenIOS getAllocationScreen() {
        return new AllocationScreenIOS(driver);
    }

    public AllocationDescriptionScreenIOS getAllocationDescriptionScreen() {
        return new AllocationDescriptionScreenIOS(driver);
    }


    public DocumentFileScreenIOS getDocumentFileScreen() {
        return new DocumentFileScreenIOS(driver);
    }

    public HoldingDetailsScreenIOS getHoldingDetailsScreen() {
        return new HoldingDetailsScreenIOS(driver);
    }

    public AnalysisFilterScreenIOS getAnalysisFilterScreen() {
        return new AnalysisFilterScreenIOS(driver);
    }

    public AccountDeliveryOptionsScreenIOS getAccountDeliveryOptionsScreen() {
        return new AccountDeliveryOptionsScreenIOS(driver);
    }

    public ActivityScreenIOS getActivityScreen() {
        return new ActivityScreenIOS(driver);
    }

    public ActivityDisclosuresScreenIOS getActivityDisclosuresScreen() {
        return new ActivityDisclosuresScreenIOS(driver);
    }

    public VaultScreenIOS getVaultScreen() {
        return new VaultScreenIOS(driver);
    }

    public VaultNewFolderScreenIOS getVaultFolderScreen() {
        return new VaultNewFolderScreenIOS(driver);
    }

    public TermsAndConditionsScreenIOS getTermsAndConditionsScreen() {
        return new TermsAndConditionsScreenIOS(driver);
    }

    public VaultFolderInformationScreenIOS getVaultFolderInformationScreen() {
        return new VaultFolderInformationScreenIOS(driver);
    }

    public VaultDeleteFolderAlertIOS getVaultDeleteFolderAlert() {
        return new VaultDeleteFolderAlertIOS(driver);
    }

    public VaultDetailScreenIOS getVaultDetailScreen() {
        return new VaultDetailScreenIOS(driver);
    }

    public FundsTransferScreenIOS getFundsTransferScreen() {
        return new FundsTransferScreenIOS(driver);
    }

    public NewTransferScreenIOS getNewTransferScreen() {
        return new NewTransferScreenIOS(driver);
    }

    public VerifyTransferScreenIOS getVerifyTransferScreen() {
        return new VerifyTransferScreenIOS(driver);
    }

    public TransferSummaryScreenIOS getTransferSummaryScreen() {
        return new TransferSummaryScreenIOS(driver);
    }

    public PendingTransferSummaryScreenIOS getPendingTransferSummaryScreen() {
        return new PendingTransferSummaryScreenIOS(driver);
    }

    public PendingTransferScreenIOS getPendingTransferScreen() {
        return new PendingTransferScreenIOS(driver);
    }

    public HistoryScreenIOS getHistoryScreen() {
        return new HistoryScreenIOS(driver);
    }

    public FeatureDisclosuresScreenIOS getFeatureDisclosuresScreen() {
        return new FeatureDisclosuresScreenIOS(driver);
    }

    public MarketResearchScreenIOS getMarketResearchScreen() {
        return new MarketResearchScreenIOS(driver);
    }

    public SymbolQuoteScreenIOS getSymbolQuoteScreen() {
        return new SymbolQuoteScreenIOS(driver);
    }

    public CompanyDetailsScreenIOS getCompanyDetailsScreen() {
        return new CompanyDetailsScreenIOS(driver);
    }

    public EDeliveryTermsandConditionsScreenIOS getEDeliveryTermsandConditionsScreen() {
        return new EDeliveryTermsandConditionsScreenIOS(driver);
    }

    public NotificationsScreenIOS getNotificationsScreen() {
        return new NotificationsScreenIOS(driver);
    }

    public PortfolioFilterAccountsScreenIOS getPortfolioFilterAccountsScreen() {
        return new PortfolioFilterAccountsScreenIOS(driver);
    }

    public SignOutScreenIOS getSignOutScreen() {
        return new SignOutScreenIOS(driver);
    }
}
