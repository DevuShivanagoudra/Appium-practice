package mobile.common;

import jarvis.mobile.common.ScreenFactory;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import mobile.screens.SupportWebPageScreen.SupportWebPageScreenAndroid;
import mobile.screens.accounts.AccountsScreenAndroid;
import mobile.screens.accounts.accountdetail.AccountDetailScreenAndroid;
import mobile.screens.alerts.exitappalert.ExitAppAlertAndroid;
import mobile.screens.alerts.incorrectverificationcode.IncorrectVerificationCodeAlertAndroid;
import mobile.screens.alerts.uninstallalert.UninstallAlertAndroid;
import mobile.screens.alerts.vaultdeletefolderalert.VaultDeleteFolderAlertAndroid;
import mobile.screens.analysis.AnalysisScreenAndroid;
import mobile.screens.analysis.allocation.AllocationScreenAndroid;
import mobile.screens.analysis.allocation.description.AllocationDescriptionScreenAndroid;
import mobile.screens.analysis.filter.AnalysisFilterScreenAndroid;
import mobile.screens.biometrics.BiometricsSetupScreenAndroid;
import mobile.screens.codeinputscreen.CodeInputScreenAndroid;
import mobile.screens.dashboard.DashboardScreenAndroid;
import mobile.screens.devicehome.DeviceHomeScreenAndroid;
import mobile.screens.disclosures.FeatureDisclosuresScreenAndroid;
import mobile.screens.f5access.F5AccessScreenAndroid;
import mobile.screens.homescreen.HomeScreenAndroid;
import mobile.screens.login.LoginScreenAndroid;
import mobile.screens.login.logindisclosure.DisclosuresScreenAndroid;
import mobile.screens.more.MoreScreenAndroid;
import mobile.screens.more.accountservices.AccountServicesScreenAndroid;
import mobile.screens.more.accountservices.documentdelivery.DocumentDeliveryScreenAndroid;
import mobile.screens.more.accountservices.documentdelivery.accountdeliveryoptions.AccountDeliveryOptionsScreenAndroid;
import mobile.screens.more.accountservices.documentdelivery.edeliveryterms.EDeliveryTermsandConditionsScreenAndroid;
import mobile.screens.more.activity.ActivityScreenAndroid;
import mobile.screens.more.activity.disclosures.ActivityDisclosuresScreenAndroid;
import mobile.screens.more.documents.DocumentsScreenAndroid;
import mobile.screens.more.documents.diclosures.DocumentsDisclosuresScreenAndroid;
import mobile.screens.more.documents.file.DocumentFileScreenAndroid;
import mobile.screens.more.documents.filter.DocumentsFilterScreenAndroid;
import mobile.screens.more.documents.termsandconditions.TermsAndConditionsScreenAndroid;
import mobile.screens.more.fundstransfer.FundsTransferScreenAndroid;
import mobile.screens.more.fundstransfer.history.HistoryScreenAndroid;
import mobile.screens.more.fundstransfer.newtransfer.NewTransferScreenAndroid;
import mobile.screens.more.fundstransfer.pending.PendingTransferScreenAndroid;
import mobile.screens.more.fundstransfer.pendingsummary.PendingTransferSummaryScreenAndroid;
import mobile.screens.more.fundstransfer.transfersummary.TransferSummaryScreenAndroid;
import mobile.screens.more.fundstransfer.verifytransfer.VerifyTransferScreenAndroid;
import mobile.screens.more.marketresearch.marketresearchhome.MarketResearchScreenAndroid;
import mobile.screens.more.marketresearch.marketresearchhome.symbolquote.SymbolQuoteScreenAndroid;
import mobile.screens.more.marketresearch.marketresearchhome.symbolquote.companydetails.CompanyDetailsScreenAndroid;
import mobile.screens.more.morereorder.MoreReorderScreenAndroid;
import mobile.screens.more.vault.VaultScreenAndroid;
import mobile.screens.more.vault.folderdetail.VaultDetailScreenAndroid;
import mobile.screens.more.vault.vaultfolderinformation.VaultFolderInformationScreenAndroid;
import mobile.screens.notifications.NotificationsScreenAndroid;
import mobile.screens.portfolio.PortfolioScreenAndroid;
import mobile.screens.portfolio.filteraccounts.PortfolioFilterAccountsScreenAndroid;
import mobile.screens.portfolio.portfoliofilter.PortfolioFilterScreenAndroid;
import mobile.screens.portfolio.stockdetails.HoldingDetailsScreenAndroid;
import mobile.screens.secretquestion.SecretQuestionScreenAndroid;
import mobile.screens.signout.SignOutScreenAndroid;
import mobile.screens.twofactorauthentication.TwoFactorAuthenticationScreenAndroid;
import mobile.screens.widgets.tabbar.TabBarAndroid;

public class AndroidScreenFactory implements ScreenFactory {

    private final AndroidCustomDriver driver;

    public AndroidScreenFactory(final AndroidCustomDriver driver) {
        this.driver = driver;
    }

    public F5AccessScreenAndroid getF5AccessScreen() {
        return new F5AccessScreenAndroid(driver);
    }

    public HomeScreenAndroid getHomeScreen() {
        return new HomeScreenAndroid(driver);
    }

    public LoginScreenAndroid getLoginScreen() {
        return new LoginScreenAndroid(driver);
    }

    public TabBarAndroid getTabBar() {
        return new TabBarAndroid(driver);
    }

    public SecretQuestionScreenAndroid getSecretQuestionScreen() {
        return new SecretQuestionScreenAndroid(driver);
    }

    public DashboardScreenAndroid getDashboardScreen() {
        return new DashboardScreenAndroid(driver);
    }

    public AccountsScreenAndroid getAccountsScreen() {
        return new AccountsScreenAndroid(driver);
    }

    public DeviceHomeScreenAndroid getDeviceHomeScreen() {
        return new DeviceHomeScreenAndroid(driver);
    }

    public SupportWebPageScreenAndroid getSupportWebPageScreen() {
        return new SupportWebPageScreenAndroid(driver);
    }

    public BiometricsSetupScreenAndroid getBiometricsSetupScreen() {
        return new BiometricsSetupScreenAndroid(driver);
    }

    public PortfolioScreenAndroid getPortfolioScreen() {
        return new PortfolioScreenAndroid(driver);
    }

    public AnalysisScreenAndroid getAnalysisScreen() {
        return new AnalysisScreenAndroid(driver);
    }

    public MoreScreenAndroid getMoreScreen() {
        return new MoreScreenAndroid(driver);
    }

    public UninstallAlertAndroid getUninstallAlert() {
        return new UninstallAlertAndroid(driver);
    }

    public MoreReorderScreenAndroid getMoreReorderScreen() {
        return new MoreReorderScreenAndroid(driver);
    }

    public TwoFactorAuthenticationScreenAndroid getTwoFactorAuthenticationScreen() {
        return new TwoFactorAuthenticationScreenAndroid(driver);
    }

    public CodeInputScreenAndroid getCodeInputScreen() {
        return new CodeInputScreenAndroid(driver);
    }

    public IncorrectVerificationCodeAlertAndroid getIncorrectVerificationCodeAlert() {
        return new IncorrectVerificationCodeAlertAndroid(driver);
    }

    public ExitAppAlertAndroid getExitAppAlert() {
        return new ExitAppAlertAndroid(driver);
    }

    public AccountDetailScreenAndroid getAccountDetailScreen() {
        return new AccountDetailScreenAndroid(driver);
    }

    public AccountServicesScreenAndroid getAccountServicesScreen() {
        return new AccountServicesScreenAndroid(driver);
    }

    public DocumentDeliveryScreenAndroid getDocumentDeliveryScreen() {
        return new DocumentDeliveryScreenAndroid(driver);
    }

    public DisclosuresScreenAndroid getDisclosuresScreen() {
        return new DisclosuresScreenAndroid(driver);
    }

    public DocumentsDisclosuresScreenAndroid getDocumentsDisclosuresScreen() {
        return new DocumentsDisclosuresScreenAndroid(driver);
    }

    public DocumentsScreenAndroid getDocumentsScreen() {
        return new DocumentsScreenAndroid(driver);
    }

    public DocumentsFilterScreenAndroid getDocumentsFilterScreen() {
        return new DocumentsFilterScreenAndroid(driver);
    }

    public PortfolioFilterScreenAndroid getPortfolioFilterScreen() {
        return new PortfolioFilterScreenAndroid(driver);
    }

    public AllocationScreenAndroid getAllocationScreen() {
        return new AllocationScreenAndroid(driver);
    }

    public AllocationDescriptionScreenAndroid getAllocationDescriptionScreen() {
        return new AllocationDescriptionScreenAndroid(driver);
    }

    public DocumentFileScreenAndroid getDocumentFileScreen() {
        return new DocumentFileScreenAndroid(driver);
    }

    public HoldingDetailsScreenAndroid getHoldingDetailsScreen() {
        return new HoldingDetailsScreenAndroid(driver);
    }

    public AnalysisFilterScreenAndroid getAnalysisFilterScreen() {
        return new AnalysisFilterScreenAndroid(driver);
    }

    public AccountDeliveryOptionsScreenAndroid getAccountDeliveryOptionsScreen() {
        return new AccountDeliveryOptionsScreenAndroid(driver);
    }

    public ActivityScreenAndroid getActivityScreen() {
        return new ActivityScreenAndroid(driver);
    }

    public ActivityDisclosuresScreenAndroid getActivityDisclosuresScreen() {
        return new ActivityDisclosuresScreenAndroid(driver);
    }

    public VaultScreenAndroid getVaultScreen() {
        return new VaultScreenAndroid(driver);
    }

    public TermsAndConditionsScreenAndroid getTermsAndConditionsScreen() {
        return new TermsAndConditionsScreenAndroid(driver);
    }

    public VaultFolderInformationScreenAndroid getVaultFolderInformationScreen() {
        return new VaultFolderInformationScreenAndroid(driver);
    }

    public VaultDeleteFolderAlertAndroid getVaultDeleteFolderAlert() {
        return new VaultDeleteFolderAlertAndroid(driver);
    }

    public VaultDetailScreenAndroid getVaultDetailScreen() {
        return new VaultDetailScreenAndroid(driver);
    }

    public FundsTransferScreenAndroid getFundsTransferScreen() {
        return new FundsTransferScreenAndroid(driver);
    }

    public NewTransferScreenAndroid getNewTransferScreen() {
        return new NewTransferScreenAndroid(driver);
    }

    public VerifyTransferScreenAndroid getVerifyTransferScreen() {
        return new VerifyTransferScreenAndroid(driver);
    }

    public TransferSummaryScreenAndroid getTransferSummaryScreen() {
        return new TransferSummaryScreenAndroid(driver);
    }

    public PendingTransferSummaryScreenAndroid getPendingTransferSummaryScreen() {
        return new PendingTransferSummaryScreenAndroid(driver);
    }

    public PendingTransferScreenAndroid getPendingTransferScreen() {
        return new PendingTransferScreenAndroid(driver);
    }

    public HistoryScreenAndroid getHistoryScreen() {
        return new HistoryScreenAndroid(driver);
    }

    public FeatureDisclosuresScreenAndroid getFeatureDisclosuresScreen() {
        return new FeatureDisclosuresScreenAndroid(driver);
    }

    public MarketResearchScreenAndroid getMarketResearchScreen() {
        return new MarketResearchScreenAndroid(driver);
    }

    public SymbolQuoteScreenAndroid getSymbolQuoteScreen() {
        return new SymbolQuoteScreenAndroid(driver);
    }

    public CompanyDetailsScreenAndroid getCompanyDetailsScreen() {
        return new CompanyDetailsScreenAndroid(driver);
    }

    public EDeliveryTermsandConditionsScreenAndroid getEDeliveryTermsandConditionsScreen() {
        return new EDeliveryTermsandConditionsScreenAndroid(driver);
    }

    public NotificationsScreenAndroid getNotificationsScreen() {
        return new NotificationsScreenAndroid(driver);
    }

    public PortfolioFilterAccountsScreenAndroid getPortfolioFilterAccountsScreen() {
        return new PortfolioFilterAccountsScreenAndroid(driver);
    }

    public SignOutScreenAndroid getSignOutScreen() {
        return new SignOutScreenAndroid(driver);
    }
}
