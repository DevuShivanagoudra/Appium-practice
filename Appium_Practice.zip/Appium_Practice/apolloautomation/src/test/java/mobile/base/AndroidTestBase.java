package mobile.base;

import io.appium.java_client.InteractsWithApps;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import jarvis.mobile.appium.Utils;
import jarvis.mobile.common.MobileTestBase;
import jarvis.mobile.common.ScreenFactory;
import jarvis.mobile.common.constants.Direction;
import jarvis.mobile.common.driver.AndroidCustomDriver;
import lombok.extern.slf4j.Slf4j;
import mobile.common.AndroidScreenFactory;
import mobile.common.constants.Toggle;
import mobile.screens.SupportWebPageScreen.SupportWebPageScreenAndroid;
import mobile.screens.accounts.AccountsScreenAndroid;
import mobile.screens.accounts.accountdetail.AccountDetailScreenAndroid;
import mobile.screens.alerts.exitappalert.ExitAppAlertAndroid;
import mobile.screens.alerts.incorrectverificationcode.IncorrectVerificationCodeAlertAndroid;
import mobile.screens.alerts.uninstallalert.UninstallAlertAndroid;
import mobile.screens.alerts.vaultdeletefolderalert.VaultDeleteFolderAlertAndroid;
import mobile.screens.analysis.AnalysisScreenAndroid;
import mobile.screens.analysis.allocation.AllocationScreenAndroid;
import mobile.screens.analysis.allocation.description.AllocationDescriptionScreenAndroid;
import mobile.screens.analysis.filter.AnalysisFilterScreenAndroid;
import mobile.screens.biometrics.BiometricsSetupScreenAndroid;
import mobile.screens.codeinputscreen.CodeInputScreenAndroid;
import mobile.screens.dashboard.DashboardScreenAndroid;
import mobile.screens.dashboard.editdashboard.EditDashboardScreenAndroid;
import mobile.screens.devicehome.DeviceHomeScreenAndroid;
import mobile.screens.disclosures.FeatureDisclosuresScreenAndroid;
import mobile.screens.f5access.F5AccessScreenAndroid;
import mobile.screens.homescreen.HomeScreenAndroid;
import mobile.screens.login.LoginScreenAndroid;
import mobile.screens.login.logindisclosure.DisclosuresScreenAndroid;
import mobile.screens.more.MoreScreenAndroid;
import mobile.screens.more.accountservices.AccountServicesScreenAndroid;
import mobile.screens.more.accountservices.documentdelivery.DocumentDeliveryScreenAndroid;
import mobile.screens.more.accountservices.documentdelivery.accountdeliveryoptions.AccountDeliveryOptionsScreenAndroid;
import mobile.screens.more.accountservices.documentdelivery.edeliveryterms.EDeliveryTermsandConditionsScreenAndroid;
import mobile.screens.more.activity.ActivityScreenAndroid;
import mobile.screens.more.activity.disclosures.ActivityDisclosuresScreenAndroid;
import mobile.screens.more.documents.DocumentsScreenAndroid;
import mobile.screens.more.documents.diclosures.DocumentsDisclosuresScreenAndroid;
import mobile.screens.more.documents.file.DocumentFileScreenAndroid;
import mobile.screens.more.documents.filter.DocumentsFilterScreenAndroid;
import mobile.screens.more.documents.termsandconditions.TermsAndConditionsScreenAndroid;
import mobile.screens.more.fundstransfer.FundsTransferScreenAndroid;
import mobile.screens.more.fundstransfer.history.HistoryScreenAndroid;
import mobile.screens.more.fundstransfer.newtransfer.NewTransferScreenAndroid;
import mobile.screens.more.fundstransfer.pending.PendingTransferScreenAndroid;
import mobile.screens.more.fundstransfer.pendingsummary.PendingTransferSummaryScreenAndroid;
import mobile.screens.more.fundstransfer.transfersummary.TransferSummaryScreenAndroid;
import mobile.screens.more.fundstransfer.verifytransfer.VerifyTransferScreenAndroid;
import mobile.screens.more.marketresearch.marketresearchhome.MarketResearchScreenAndroid;
import mobile.screens.more.marketresearch.marketresearchhome.symbolquote.SymbolQuoteScreenAndroid;
import mobile.screens.more.marketresearch.marketresearchhome.symbolquote.companydetails.CompanyDetailsScreenAndroid;
import mobile.screens.more.morereorder.MoreReorderScreenAndroid;
import mobile.screens.more.vault.VaultScreenAndroid;
import mobile.screens.more.vault.folderdetail.VaultDetailScreenAndroid;
import mobile.screens.more.vault.vaultfolderinformation.VaultFolderInformationScreenAndroid;
import mobile.screens.notifications.NotificationsScreenAndroid;
import mobile.screens.portfolio.PortfolioScreenAndroid;
import mobile.screens.portfolio.filteraccounts.PortfolioFilterAccountsScreenAndroid;
import mobile.screens.portfolio.portfoliofilter.PortfolioFilterScreenAndroid;
import mobile.screens.portfolio.stockdetails.HoldingDetailsScreenAndroid;
import mobile.screens.secretquestion.SecretQuestionScreenAndroid;
import mobile.screens.signout.SignOutScreenAndroid;
import mobile.screens.twofactorauthentication.TwoFactorAuthenticationScreenAndroid;
import mobile.screens.widgets.tabbar.TabBarAndroid;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
public class AndroidTestBase extends MobileTestBase<AndroidCustomDriver> {

    protected static final String APP_PACKAGE = "com.raymondjames.investoraccess";
    protected static final String APPSTORE_PACKAGE = "com.android.vending";
    protected static final String CHROME_APPPACKAGE = "com.android.chrome";
    protected static final String F5ACCESS = "Work F5 Access";
    private static final String SERVER_NAME = Utils.getProperty("appium.server");
    private static final String TESTENV_NAME = Utils.getProperty("appium.environment");
    public static String build = null;

    public AndroidTestBase() {
    }

    public String getAppPackage() {
        final String server = System.getProperty("appium.server").toLowerCase();
        return String.format("%s%s", APP_PACKAGE, server);
    }

    private void unlockDevice() {
        final String devicePassword = System.getProperty("appium.password");
        if (getDriver().isDeviceLocked()) {
            getDriver().pressKey(new KeyEvent(AndroidKey.HOME));
            getDriver().swipeScreen(Direction.UP);
            getDriver()
                    .executeShellCommand(String.format("adb shell input text %s", devicePassword));
            getDriver().executeShellCommand("adb shell input keyevent KEYCODE_ENTER");
        }
    }

    @BeforeSuite(
            alwaysRun = true
    )
    public final void beforeSuite() {
        unlockDevice();
        (getDriver()).terminateApp(getAppPackage());
        (getDriver()).terminateApp(APPSTORE_PACKAGE);
    }

    @BeforeMethod(
            alwaysRun = true
    )
    public final void beforeMethod() {
        try {
            getDeviceHomeScreen().terminateApp(getAppPackage());
            ((InteractsWithApps) getDriver()).terminateApp(getAppPackage());
            ((InteractsWithApps) getDriver()).terminateApp(APPSTORE_PACKAGE);
        } catch (WebDriverException e) {
            getDeviceHomeScreen().terminateApp(getAppPackage());
            ((InteractsWithApps) getDriver()).terminateApp(getAppPackage());
            ((InteractsWithApps) getDriver()).terminateApp(APPSTORE_PACKAGE);
        }
        getDeviceHomeScreen().findAndlaunchApp(F5ACCESS);
        getF5AccessScreen().getConnection();
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();
        this.build = String.format("%s#%s %s", SERVER_NAME,
                getLoginScreen().getBuild().getText(), TESTENV_NAME);
    }

    @AfterMethod(
            alwaysRun = true
    )
    public final void tearDownApp() {
        try {
            ((InteractsWithApps) getDriver()).terminateApp(getAppPackage());
            ((InteractsWithApps) getDriver()).terminateApp(APPSTORE_PACKAGE);
            getDeviceHomeScreen().terminateApp(getAppPackage());
        } catch (WebDriverException e) {
            ((InteractsWithApps) getDriver()).terminateApp(getAppPackage());
            ((InteractsWithApps) getDriver()).terminateApp(APPSTORE_PACKAGE);
            getDeviceHomeScreen().terminateApp(getAppPackage());
        }
    }

    public final void login(final String username, final String password,
                            final String secretAnswer) {
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(getBiometricsSetupScreen().getNoThanks())
                                , ExpectedConditions.visibilityOf(getSecretQuestionScreen().getSecretAnswerEditable()),
                                ExpectedConditions.visibilityOf(getDashboardScreen().getDashboardHeader())),
                "Biometrics/Challenge/Dashboard Screen is not displayed.");
        if (getDriver().isElementVisible(getSecretQuestionScreen().getSecretAnswerEditable())) {
            getSecretQuestionScreen().submitSecretAnswer(secretAnswer, Toggle.OFF);
        }
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(getBiometricsSetupScreen().getNoThanks())
                                , ExpectedConditions.visibilityOf(getDashboardScreen().getDashboardHeader())),
                "Biometrics/Dashboard Screen is not displayed.");
        if (getDriver().isElementVisible(getBiometricsSetupScreen().getNoThanks())) {
            getBiometricsSetupScreen().tapNoThanks();
        }
        getDashboardScreen().waitToLoad();
    }

    public void login(final String username, final String password) {
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);
    }

    @Override
    protected ScreenFactory getScreenFactory(final AndroidCustomDriver driver) {
        return new AndroidScreenFactory(driver);
    }

    protected F5AccessScreenAndroid getF5AccessScreen() {
        return getScreenRegistry().getScreen(F5AccessScreenAndroid.class);
    }

    protected HomeScreenAndroid getHomeScreen() {
        return getScreenRegistry().getScreen(HomeScreenAndroid.class);
    }

    protected LoginScreenAndroid getLoginScreen() {
        return getScreenRegistry().getScreen(LoginScreenAndroid.class);
    }

    protected TabBarAndroid getTabBar() {
        return getScreenRegistry().getScreen(TabBarAndroid.class);
    }

    protected SecretQuestionScreenAndroid getSecretQuestionScreen() {
        return getScreenRegistry().getScreen(SecretQuestionScreenAndroid.class);
    }

    protected DashboardScreenAndroid getDashboardScreen() {
        return getScreenRegistry().getScreen(DashboardScreenAndroid.class);
    }

    protected AccountsScreenAndroid getAccountsScreen() {
        return getScreenRegistry().getScreen(AccountsScreenAndroid.class);
    }

    protected DeviceHomeScreenAndroid getDeviceHomeScreen() {
        return getScreenRegistry().getScreen(DeviceHomeScreenAndroid.class);
    }

    protected SupportWebPageScreenAndroid getSupportWebPageScreen() {
        return getScreenRegistry().getScreen(SupportWebPageScreenAndroid.class);
    }

    protected BiometricsSetupScreenAndroid getBiometricsSetupScreen() {
        return getScreenRegistry().getScreen(BiometricsSetupScreenAndroid.class);
    }

    protected PortfolioScreenAndroid getPortfolioScreen() {
        return getScreenRegistry().getScreen(PortfolioScreenAndroid.class);
    }

    protected AnalysisScreenAndroid getAnalysisScreen() {
        return getScreenRegistry().getScreen(AnalysisScreenAndroid.class);
    }

    protected MoreScreenAndroid getMoreScreen() {
        return getScreenRegistry().getScreen(MoreScreenAndroid.class);
    }

    protected UninstallAlertAndroid getUninstallAlert() {
        return getScreenRegistry().getScreen(UninstallAlertAndroid.class);
    }

    protected ExitAppAlertAndroid getExitAppAlert() {
        return getScreenRegistry().getScreen(ExitAppAlertAndroid.class);
    }

    protected MoreReorderScreenAndroid getMoreReorderScreen() {
        return getScreenRegistry().getScreen(MoreReorderScreenAndroid.class);
    }

    protected TwoFactorAuthenticationScreenAndroid getTwoFactorAuthenticationScreen() {
        return getScreenRegistry().getScreen(TwoFactorAuthenticationScreenAndroid.class);
    }

    protected CodeInputScreenAndroid getCodeInputScreen() {
        return getScreenRegistry().getScreen(CodeInputScreenAndroid.class);
    }

    protected IncorrectVerificationCodeAlertAndroid getIncorrectVerificationCodeAlert() {
        return getScreenRegistry().getScreen(IncorrectVerificationCodeAlertAndroid.class);
    }

    protected AccountDetailScreenAndroid getAccountDetailScreen() {
        return getScreenRegistry().getScreen(AccountDetailScreenAndroid.class);
    }

    protected AccountServicesScreenAndroid getAccountServicesScreen() {
        return getScreenRegistry().getScreen(AccountServicesScreenAndroid.class);
    }

    protected DocumentDeliveryScreenAndroid getDocumentDeliveryScreen() {
        return getScreenRegistry().getScreen(DocumentDeliveryScreenAndroid.class);
    }

    protected EditDashboardScreenAndroid getEditDashboardScreen() {
        return getScreenRegistry().getScreen(EditDashboardScreenAndroid.class);
    }

    protected DocumentsScreenAndroid getDocumentsScreen() {
        return getScreenRegistry().getScreen(DocumentsScreenAndroid.class);
    }

    protected DocumentsFilterScreenAndroid getDocumentsFilterScreen() {
        return getScreenRegistry().getScreen(DocumentsFilterScreenAndroid.class);
    }

    protected AllocationScreenAndroid getAllocationScreen() {
        return getScreenRegistry().getScreen(AllocationScreenAndroid.class);
    }

    protected AllocationDescriptionScreenAndroid getAllocationDescriptionScreen() {
        return getScreenRegistry().getScreen(AllocationDescriptionScreenAndroid.class);
    }

    protected PortfolioFilterScreenAndroid getPortfolioFilterScreen() {
        return getScreenRegistry().getScreen(PortfolioFilterScreenAndroid.class);
    }

    protected DisclosuresScreenAndroid getDisclosuresScreen() {
        return getScreenRegistry().getScreen(DisclosuresScreenAndroid.class);
    }

    protected DocumentsDisclosuresScreenAndroid getDocumentsDisclosuresScreen() {
        return getScreenRegistry().getScreen(DocumentsDisclosuresScreenAndroid.class);
    }

    protected DocumentFileScreenAndroid getDocumentFileScreen() {
        return getScreenRegistry().getScreen(DocumentFileScreenAndroid.class);
    }

    protected HoldingDetailsScreenAndroid getHoldingDetailsScreen() {
        return getScreenRegistry().getScreen(HoldingDetailsScreenAndroid.class);
    }

    protected AnalysisFilterScreenAndroid getAnalysisFilterScreen() {
        return getScreenRegistry().getScreen(AnalysisFilterScreenAndroid.class);
    }

    protected AccountDeliveryOptionsScreenAndroid getAccountDeliveryOptionsScreen() {
        return getScreenRegistry().getScreen(AccountDeliveryOptionsScreenAndroid.class);
    }

    protected ActivityScreenAndroid getActivityScreen() {
        return getScreenRegistry().getScreen(ActivityScreenAndroid.class);
    }

    protected ActivityDisclosuresScreenAndroid getActivityDisclosuresScreen() {
        return getScreenRegistry().getScreen(ActivityDisclosuresScreenAndroid.class);
    }

    protected VaultScreenAndroid getVaultScreen() {
        return getScreenRegistry().getScreen(VaultScreenAndroid.class);
    }

    protected TermsAndConditionsScreenAndroid getTermsAndConditionsScreen() {
        return getScreenRegistry().getScreen(TermsAndConditionsScreenAndroid.class);
    }

    protected VaultFolderInformationScreenAndroid getVaultFolderInformationScreen() {
        return getScreenRegistry().getScreen(VaultFolderInformationScreenAndroid.class);
    }

    protected VaultDeleteFolderAlertAndroid getVaultDeleteFolderAlert() {
        return getScreenRegistry().getScreen(VaultDeleteFolderAlertAndroid.class);
    }

    protected VaultDetailScreenAndroid getVaultDetailScreen() {
        return getScreenRegistry().getScreen(VaultDetailScreenAndroid.class);
    }

    protected FundsTransferScreenAndroid getFundsTransferScreen() {
        return getScreenRegistry().getScreen(FundsTransferScreenAndroid.class);
    }

    protected NewTransferScreenAndroid getNewTransferScreen() {
        return getScreenRegistry().getScreen(NewTransferScreenAndroid.class);
    }

    protected VerifyTransferScreenAndroid getVerifyTransferScreen() {
        return getScreenRegistry().getScreen(VerifyTransferScreenAndroid.class);
    }

    protected TransferSummaryScreenAndroid getTransferSummaryScreen() {
        return getScreenRegistry().getScreen(TransferSummaryScreenAndroid.class);
    }

    protected PendingTransferScreenAndroid getPendingTransferScreen() {
        return getScreenRegistry().getScreen(PendingTransferScreenAndroid.class);
    }

    protected PendingTransferSummaryScreenAndroid getPendingTransferSummaryScreen() {
        return getScreenRegistry().getScreen(PendingTransferSummaryScreenAndroid.class);
    }

    protected HistoryScreenAndroid getHistoryScreen() {
        return getScreenRegistry().getScreen(HistoryScreenAndroid.class);
    }

    protected FeatureDisclosuresScreenAndroid getFeatureDisclosuresScreen() {
        return getScreenRegistry().getScreen(FeatureDisclosuresScreenAndroid.class);
    }

    protected MarketResearchScreenAndroid getMarketResearchScreen() {
        return getScreenRegistry().getScreen(MarketResearchScreenAndroid.class);
    }

    protected SymbolQuoteScreenAndroid getSymbolQuoteScreen() {
        return getScreenRegistry().getScreen(SymbolQuoteScreenAndroid.class);
    }

    protected CompanyDetailsScreenAndroid getCompanyDetailsScreen() {
        return getScreenRegistry().getScreen(CompanyDetailsScreenAndroid.class);
    }

    protected EDeliveryTermsandConditionsScreenAndroid getEDeliveryTermsandConditionsScreen() {
        return getScreenRegistry().getScreen(EDeliveryTermsandConditionsScreenAndroid.class);
    }

    protected NotificationsScreenAndroid getNotificationsScreenAndroid() {
        return getScreenRegistry().getScreen(NotificationsScreenAndroid.class);
    }

    protected PortfolioFilterAccountsScreenAndroid getPortfolioFilterAccountsScreen() {
        return getScreenRegistry().getScreen(PortfolioFilterAccountsScreenAndroid.class);
    }

    protected SignOutScreenAndroid getSignOutScreen() {
        return getScreenRegistry().getScreen(SignOutScreenAndroid.class);
    }
}
