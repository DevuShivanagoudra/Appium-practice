package mobile.base;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.InteractsWithApps;
import jarvis.mobile.appium.Utils;
import jarvis.mobile.common.MobileTestBase;
import jarvis.mobile.common.ScreenFactory;
import jarvis.mobile.common.driver.IOSCustomDriver;
import lombok.extern.slf4j.Slf4j;
import mobile.common.IOSScreenFactory;
import mobile.common.constants.Toggle;
import mobile.screens.SupportWebPageScreen.SupportWebPageScreenIOS;
import mobile.screens.accounts.AccountsScreenIOS;
import mobile.screens.accounts.accountdetail.AccountDetailScreenIOS;
import mobile.screens.alerts.vaultdeletefolderalert.VaultDeleteFolderAlertIOS;
import mobile.screens.analysis.AnalysisScreenIOS;
import mobile.screens.analysis.allocation.AllocationScreenIOS;
import mobile.screens.analysis.allocation.description.AllocationDescriptionScreenIOS;
import mobile.screens.analysis.filter.AnalysisFilterScreenIOS;
import mobile.screens.codeinputscreen.CodeInputScreenIOS;
import mobile.screens.dashboard.DashboardScreenIOS;
import mobile.screens.dashboard.editdashboard.EditDashboardScreenIOS;
import mobile.screens.devicehome.DeviceHomeScreenIOS;
import mobile.screens.disclosures.FeatureDisclosuresScreenIOS;
import mobile.screens.f5access.F5AccessScreenIOS;
import mobile.screens.homescreen.HomeScreenIOS;
import mobile.screens.login.LoginScreenIOS;
import mobile.screens.login.logindisclosure.DisclosuresScreenIOS;
import mobile.screens.more.MoreScreenIOS;
import mobile.screens.more.accountservices.AccountServicesScreenIOS;
import mobile.screens.more.accountservices.documentdelivery.DocumentDeliveryScreenIOS;
import mobile.screens.more.accountservices.documentdelivery.accountdeliveryoptions.AccountDeliveryOptionsScreenIOS;
import mobile.screens.more.accountservices.documentdelivery.edeliveryterms.EDeliveryTermsandConditionsScreenIOS;
import mobile.screens.more.activity.ActivityScreenIOS;
import mobile.screens.more.activity.disclosures.ActivityDisclosuresScreenIOS;
import mobile.screens.more.documents.DocumentsScreenIOS;
import mobile.screens.more.documents.diclosures.DocumentsDisclosuresScreenIOS;
import mobile.screens.more.documents.file.DocumentFileScreenIOS;
import mobile.screens.more.documents.filter.DocumentsFilterScreenIOS;
import mobile.screens.more.documents.termsandconditions.TermsAndConditionsScreenIOS;
import mobile.screens.more.fundstransfer.FundsTransferScreenIOS;
import mobile.screens.more.fundstransfer.history.HistoryScreenIOS;
import mobile.screens.more.fundstransfer.newtransfer.NewTransferScreenIOS;
import mobile.screens.more.fundstransfer.pending.PendingTransferScreenIOS;
import mobile.screens.more.fundstransfer.pendingsummary.PendingTransferSummaryScreenIOS;
import mobile.screens.more.fundstransfer.transfersummary.TransferSummaryScreenIOS;
import mobile.screens.more.fundstransfer.verifytransfer.VerifyTransferScreenIOS;
import mobile.screens.more.marketresearch.marketresearchhome.MarketResearchScreenIOS;
import mobile.screens.more.marketresearch.marketresearchhome.symbolquote.SymbolQuoteScreenIOS;
import mobile.screens.more.marketresearch.marketresearchhome.symbolquote.companydetails.CompanyDetailsScreenIOS;
import mobile.screens.more.morereorder.MoreReorderScreenIOS;
import mobile.screens.more.vault.VaultNewFolderScreenIOS;
import mobile.screens.more.vault.VaultScreenIOS;
import mobile.screens.more.vault.folderdetail.VaultDetailScreenIOS;
import mobile.screens.more.vault.vaultfolderinformation.VaultFolderInformationScreenIOS;
import mobile.screens.notifications.NotificationsScreenIOS;
import mobile.screens.portfolio.PortfolioScreenIOS;
import mobile.screens.portfolio.filteraccounts.PortfolioFilterAccountsScreenIOS;
import mobile.screens.portfolio.portfoliofilter.PortfolioFilterScreenIOS;
import mobile.screens.portfolio.stockdetails.HoldingDetailsScreenIOS;
import mobile.screens.secretquestion.SecretQuestionScreenIOS;
import mobile.screens.signout.SignOutScreenIOS;
import mobile.screens.twofactorauthentication.TwoFactorAuthenticationScreenIOS;
import mobile.screens.widgets.tabbar.TabBarIOS;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import static jarvis.mobile.common.constants.Constants.DEFAULT_WAIT_TIMEOUT;
import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
public class IOSTestBase extends MobileTestBase<IOSCustomDriver> {

    public static final String RESOURCE_PATH = String
            .format(System.getProperty("user.dir"), "//src//main//resources//ios");
    protected static final String CLIENTACCESS_BUNDLEID = String
            .format("com.raymondjames.investoraccess%s",
                    Utils.getProperty("appium.server").toLowerCase());
    protected static final String CHROME_BUNDLEID = "com.google.chrome.ios";
    protected static final String SAFARI_BUNDLEID = "com.apple.mobilesafari";
    protected static final String TESTFLIGHT_BUNDLEID = "com.apple.TestFlight";
    protected static final String F5ACCESS_BUNDLEID = "com.f5.access.ios";
    private static final String SERVER_NAME = Utils.getProperty("appium.server");
    private static final String TESTENV_NAME = Utils.getProperty("appium.environment");
    private static final String HOLDING_WIDGET_LOCATOR = "**/XCUIElementTypeStaticText[`label == \"Top Holdings\"`]";
    public static String build = null;
    private static boolean installFlag = false;

    public IOSTestBase() {
    }

    @BeforeClass(
            alwaysRun = true
    )
    private void unlockDevice() {

    }

    @BeforeSuite(
            alwaysRun = true
    )
    public final void beforeSuite() {
        getDriver().terminateApp(CLIENTACCESS_BUNDLEID);
        getDriver().terminateApp(F5ACCESS_BUNDLEID);
    }

    @BeforeMethod(
            alwaysRun = true
    )
    public final void beforeMethod() {
        getDriver().launchApp(F5ACCESS_BUNDLEID);
        getF5AccessScreen().getConnection();
        launchApp();
        this.build = String
                .format("%s#%s %s", SERVER_NAME, DeviceHomeScreenIOS.BUILD_VERSION, TESTENV_NAME);
    }

    @AfterMethod(
            alwaysRun = true
    )
    public final void tearDownApp() {
        ((InteractsWithApps) getDriver()).terminateApp(CLIENTACCESS_BUNDLEID);
        ((InteractsWithApps) getDriver()).terminateApp(F5ACCESS_BUNDLEID);
    }

    public void launchApp() {
        final boolean buildUpdate = Boolean.parseBoolean(System.getProperty("appium.buildUpdate"));
        if (buildUpdate && !installFlag) {
            launchFromTestFlight();
            installFlag = true;
        } else {
            getDriver().launchApp(CLIENTACCESS_BUNDLEID);
        }
    }

    public void launchFromTestFlight() {
        ((InteractsWithApps) getDriver()).activateApp(TESTFLIGHT_BUNDLEID);
        getDeviceHomeScreen().launchApp();
        getDriver().waitUntilCondition(DEFAULT_WAIT_TIMEOUT,
                ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(getHomeScreen().getNextButton()),
                                ExpectedConditions.visibilityOf(getLoginScreen().getPassword())),
                "Login/Welcome screen not displayed.");
        getHomeScreen().startTesting();
    }

    public void login(final String username, final String password, final String secretAnswer) {
        launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(getSecretQuestionScreen().getRememberOnDevice()),
                                ExpectedConditions.presenceOfElementLocated(AppiumBy.iOSClassChain(HOLDING_WIDGET_LOCATOR))),
                "Challenge Screen/Dashboard Screen is not displayed.");
        if (getDriver().isElementVisible(getSecretQuestionScreen().getRememberOnDevice())) {
            getSecretQuestionScreen().waitToLoad();
            getSecretQuestionScreen().submitSecretAnswer(secretAnswer, Toggle.OFF);
        }
        getDashboardScreen().waitToLoad();
    }

    public void login(final String username, final String password) {
        launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);
    }

    @Override
    protected ScreenFactory getScreenFactory(final IOSCustomDriver driver) {
        return new IOSScreenFactory(driver);
    }

    protected F5AccessScreenIOS getF5AccessScreen() {
        return getScreenRegistry().getScreen(F5AccessScreenIOS.class);
    }

    protected HomeScreenIOS getHomeScreen() {
        return getScreenRegistry().getScreen(HomeScreenIOS.class);
    }

    protected LoginScreenIOS getLoginScreen() {
        return getScreenRegistry().getScreen(LoginScreenIOS.class);
    }

    protected TabBarIOS getTabBar() {
        return getScreenRegistry().getScreen(TabBarIOS.class);
    }

    protected SecretQuestionScreenIOS getSecretQuestionScreen() {
        return getScreenRegistry().getScreen(SecretQuestionScreenIOS.class);
    }

    protected DashboardScreenIOS getDashboardScreen() {
        return getScreenRegistry().getScreen(DashboardScreenIOS.class);
    }

    protected AccountsScreenIOS getAccountsScreen() {
        return getScreenRegistry().getScreen(AccountsScreenIOS.class);
    }

    protected DeviceHomeScreenIOS getDeviceHomeScreen() {
        return getScreenRegistry().getScreen(DeviceHomeScreenIOS.class);
    }

    protected SupportWebPageScreenIOS getSupportWebPageScreen() {
        return getScreenRegistry().getScreen(SupportWebPageScreenIOS.class);
    }

    protected PortfolioScreenIOS getPortfolioScreen() {
        return getScreenRegistry().getScreen(PortfolioScreenIOS.class);
    }

    protected PortfolioFilterScreenIOS getPortfolioFilterScreen() {
        return getScreenRegistry().getScreen(PortfolioFilterScreenIOS.class);
    }

    protected AnalysisScreenIOS getAnalysisScreen() {
        return getScreenRegistry().getScreen(AnalysisScreenIOS.class);
    }

    protected MoreScreenIOS getMoreScreen() {
        return getScreenRegistry().getScreen(MoreScreenIOS.class);
    }

    protected MoreReorderScreenIOS getMoreReorderScreen() {
        return getScreenRegistry().getScreen(MoreReorderScreenIOS.class);
    }

    protected TwoFactorAuthenticationScreenIOS getTwoFactorAuthenticationScreen() {
        return getScreenRegistry().getScreen(TwoFactorAuthenticationScreenIOS.class);
    }

    protected CodeInputScreenIOS getCodeInputScreen() {
        return getScreenRegistry().getScreen(CodeInputScreenIOS.class);
    }

    protected PortfolioFilterScreenIOS getFilterViewSelected() {
        return getScreenRegistry().getScreen(PortfolioFilterScreenIOS.class);
    }

    protected AccountDetailScreenIOS getAccountDetailScreen() {
        return getScreenRegistry().getScreen(AccountDetailScreenIOS.class);
    }

    protected AccountServicesScreenIOS getAccountServicesScreen() {
        return getScreenRegistry().getScreen(AccountServicesScreenIOS.class);
    }

    protected DocumentDeliveryScreenIOS getDocumentDeliveryScreen() {
        return getScreenRegistry().getScreen(DocumentDeliveryScreenIOS.class);
    }

    protected EditDashboardScreenIOS getEditDashboardScreen() {
        return getScreenRegistry().getScreen(EditDashboardScreenIOS.class);
    }

    protected DocumentsScreenIOS getDocumentsScreen() {
        return getScreenRegistry().getScreen(DocumentsScreenIOS.class);
    }

    protected DocumentsFilterScreenIOS getDocumentsFilterScreen() {
        return getScreenRegistry().getScreen(DocumentsFilterScreenIOS.class);
    }

    protected DocumentsDisclosuresScreenIOS getDocumentsDisclosuresScreen() {
        return getScreenRegistry().getScreen(DocumentsDisclosuresScreenIOS.class);
    }

    protected DisclosuresScreenIOS getDisclosuresScreen() {
        return getScreenRegistry().getScreen(DisclosuresScreenIOS.class);
    }

    protected AllocationScreenIOS getAllocationScreen() {
        return getScreenRegistry().getScreen(AllocationScreenIOS.class);
    }

    protected AllocationDescriptionScreenIOS getAllocationDescriptionScreen() {
        return getScreenRegistry().getScreen(AllocationDescriptionScreenIOS.class);
    }

    protected DocumentFileScreenIOS getDocumentFileScreen() {
        return getScreenRegistry().getScreen(DocumentFileScreenIOS.class);
    }

    protected HoldingDetailsScreenIOS getHoldingDetailsScreen() {
        return getScreenRegistry().getScreen(HoldingDetailsScreenIOS.class);
    }

    protected AnalysisFilterScreenIOS getAnalysisFilterScreen() {
        return getScreenRegistry().getScreen(AnalysisFilterScreenIOS.class);
    }

    protected AccountDeliveryOptionsScreenIOS getAccountDeliveryOptionsScreen() {
        return getScreenRegistry().getScreen(AccountDeliveryOptionsScreenIOS.class);
    }

    protected ActivityScreenIOS getActivityScreen() {
        return getScreenRegistry().getScreen(ActivityScreenIOS.class);
    }

    protected ActivityDisclosuresScreenIOS getActivityDisclosuresScreen() {
        return getScreenRegistry().getScreen(ActivityDisclosuresScreenIOS.class);
    }

    protected VaultScreenIOS getVaultScreen() {
        return getScreenRegistry().getScreen(VaultScreenIOS.class);
    }

    protected VaultNewFolderScreenIOS getVaultNewFolderScreen() {
        return getScreenRegistry().getScreen(VaultNewFolderScreenIOS.class);
    }

    protected TermsAndConditionsScreenIOS getTermsAndConditionsScreen() {
        return getScreenRegistry().getScreen(TermsAndConditionsScreenIOS.class);
    }

    protected VaultFolderInformationScreenIOS getVaultFolderInformationScreen() {
        return getScreenRegistry().getScreen(VaultFolderInformationScreenIOS.class);
    }

    protected VaultDeleteFolderAlertIOS getVaultDeleteFolderAlert() {
        return getScreenRegistry().getScreen(VaultDeleteFolderAlertIOS.class);
    }

    protected VaultDetailScreenIOS getVaultDetailScreen() {
        return getScreenRegistry().getScreen(VaultDetailScreenIOS.class);
    }

    protected FundsTransferScreenIOS getFundsTransferScreen() {
        return getScreenRegistry().getScreen(FundsTransferScreenIOS.class);
    }

    protected NewTransferScreenIOS getNewTransferScreen() {
        return getScreenRegistry().getScreen(NewTransferScreenIOS.class);
    }

    protected VerifyTransferScreenIOS getVerifyTransferScreen() {
        return getScreenRegistry().getScreen(VerifyTransferScreenIOS.class);
    }

    protected TransferSummaryScreenIOS getTransferSummaryScreen() {
        return getScreenRegistry().getScreen(TransferSummaryScreenIOS.class);
    }

    protected PendingTransferSummaryScreenIOS getPendingTransferSummaryScreen() {
        return getScreenRegistry().getScreen(PendingTransferSummaryScreenIOS.class);
    }

    protected PendingTransferScreenIOS getPendingTransferScreen() {
        return getScreenRegistry().getScreen(PendingTransferScreenIOS.class);
    }

    protected HistoryScreenIOS getHistoryScreen() {
        return getScreenRegistry().getScreen(HistoryScreenIOS.class);
    }

    protected FeatureDisclosuresScreenIOS getFeatureDisclosuresScreen() {
        return getScreenRegistry().getScreen(FeatureDisclosuresScreenIOS.class);
    }

    protected MarketResearchScreenIOS getMarketResearchScreen() {
        return getScreenRegistry().getScreen(MarketResearchScreenIOS.class);
    }

    protected SymbolQuoteScreenIOS getSymbolQuoteScreen() {
        return getScreenRegistry().getScreen(SymbolQuoteScreenIOS.class);
    }

    protected CompanyDetailsScreenIOS getCompanyDetailsScreen() {
        return getScreenRegistry().getScreen(CompanyDetailsScreenIOS.class);
    }

    protected EDeliveryTermsandConditionsScreenIOS getEDeliveryTermsandConditionsScreen() {
        return getScreenRegistry().getScreen(EDeliveryTermsandConditionsScreenIOS.class);
    }

    protected NotificationsScreenIOS getNotificationsScreen() {
        return getScreenRegistry().getScreen(NotificationsScreenIOS.class);
    }

    protected PortfolioFilterAccountsScreenIOS getPortfolioFilterAccountsScreen() {
        return getScreenRegistry().getScreen(PortfolioFilterAccountsScreenIOS.class);
    }

    protected SignOutScreenIOS getSignOutScreen() {
        return getScreenRegistry().getScreen(SignOutScreenIOS.class);
    }
}
