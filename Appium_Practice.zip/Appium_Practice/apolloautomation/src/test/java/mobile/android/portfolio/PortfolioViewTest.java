package mobile.android.portfolio;

import api.utils.Accounts;
import jarvis.mobile.common.constants.Direction;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import mobile.common.constants.Messages;
import mobile.common.constants.MyPortfolioHoldingsView;
import mobile.common.constants.TabBarOption;
import mobile.common.constants.Toggle;
import org.openqa.selenium.Point;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.text.DecimalFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class PortfolioViewTest extends AndroidTestBase {

    private static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(description =
            "1206958: Verify that app displays the current value amount for each record If Value Change option is selected"
                    + "1206963: Verify that Gain/Loss option displays the following information if Investment Gain or (Loss) is selected in View section"
                    + "1206967: Verify the Gain/Loss displays the following information if user selects Cost Basis Gain or (Loss) in views filter"
                    + "1206966: Verify the app displays the security group names in alphabetical order (Portfolio filter)", dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestViewSelected(final String username, final String password) {
        final List<String> cusipList = Arrays.asList("ABALX", "AGTHX", "AMECX");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify the Stock details on Current value screen for view 'Value Change'.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        getPortfolioScreen()
                .selectMyPortFolioHoldingView(MyPortfolioHoldingsView.ValueChange.toString());
        verifyStockRecordDetail_ValueChange(cusipList);

        log.info("Verify the Stock details on Current value screen for view 'Gain/Loss'.");
        getPortfolioScreen()
                .selectMyPortFolioHoldingView(MyPortfolioHoldingsView.GainLoss_Android.toString());
        verifyStockRecordDetail_GainLoss(cusipList);

        log.info("Verify the record details on Current value screen for view 'Cost Basis Gain or Loss'.");
        final String viewOption = "Cost Basis Gain or (Loss)";
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioScreen().selectView(viewOption);
        getPortfolioFilterScreen().tapDone();
        getDriver().scrollTo(getPortfolioScreen().getDailyChangeValue(), Direction.DOWN, 5);
        getPortfolioScreen().waitToLoad();
        verifyStockRecordDetail_GainLoss(cusipList);

        log.info("Verify Security groups are displayed in alphabetical order.");
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllSecurities();
        getPortfolioFilterScreen().waitForSecurityToggleToLoad();
        getPortfolioFilterScreen().tapAllSecurities(Toggle.OFF);
        List<String> securityGroups = getPortfolioFilterScreen().getSecurityGroupsList();
        Assert.assertTrue(securityGroups.size() > 0, "Security Groups count should not be less than zero.");
        List<String> securityGroupsBeforeSort = securityGroups;
        Collections.sort(securityGroups, Comparator.reverseOrder());
        Assert.assertEquals(securityGroupsBeforeSort, securityGroups, "Security groups is not in sorted order.");
    }

    @Test(
            description =
                    "1206284: Verify that app displays the following message under Unrealized Gain/Loss<br>"
                            + "1211446: Verify that app displays Short term and Long term held  information under Realized Gain/Loss<br>"
                            + "1242545: Verify Amount Total for Net Gain/Loss sub section<br>", dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestVerifyNetGainLossTotalMessageAndDetails(final String username,
                                                            final String password) {
        List<String> unrealizedLossGainDetails = Arrays
                .asList("Short-Term", "Gain", "Loss", "Subtotal", "Long-Term", "longTermGain",
                        "longTermLoss", "longTermSubtotal", "Net Gain / (Loss) Total");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Unrealized Gain/Loss Details are displayed.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        getPortfolioScreen().tapUnrealizedGainLoss();
        getDriver().waitUntilVisible(getPortfolioScreen().getLongTermText());
        //FIXME: To be refactored once Jarvis method is implemented.
        int x = (getPortfolioScreen().getUnrealizedGainLossSection().getLocation().getX()
                + getPortfolioScreen().getUnrealizedGainLossSection().getSize().getWidth()) / 2;
        int y = (getPortfolioScreen().getUnrealizedGainLossSection().getLocation().getY()
                + getPortfolioScreen().getUnrealizedGainLossSection().getSize().getHeight()) / 2;
        Point fromPoint = new Point(x, y);
        Point toPoint = new Point(x, y - 200);
        getDriver().swipeScreen(fromPoint, toPoint);
        Assert.assertEquals(getPortfolioScreen().fetchGainLossDetails().keySet(), unrealizedLossGainDetails, "UnRealized Gain Loss details not match.");
        final List<String> unrealizedGainLossValues = getPortfolioScreen().fetchGainLossDetails()
                .values()
                .stream().collect(Collectors.toList());
        verifyUnrealizedGainLossDetails(unrealizedGainLossValues);
        verifyUnrealizedGainLossTotalValue(unrealizedGainLossValues);

        log.info("Verify Unrealized Gain/Loss message is displayed.");
        getDriver().scrollTo(getPortfolioScreen().getUnrealizedGainLossMessage(),
                Direction.UP_SMALL);
        Assert.assertTrue(getPortfolioScreen().getUnrealizedGainLossMessage().isDisplayed(),
                "Unrealized Gain/Loss Message is not displayed.");
        Assert.assertEquals(getPortfolioScreen().getUnrealizedGainLossMessage().getText(),
                Messages.UNREALIZEDGAINLOSS_MESSAGE.toString(),
                "Unrealized Gain/Loss Message Not matched.");
    }

    @Test(
            description =
                    "1246264 : Verify the app displays the following info for the All Capital Gains & Losses views of Realized Gain/Loss under portfolio<br>"
                            + "1247481: Verify the \"Closing Date\" will only apply to the Realized G/L screen under Portfolio<br>", dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestVerifyRealizedGainLossDetails(final String username, final String password) {
        List<String> unrealizedLossGainDetails = Arrays
                .asList("Short-Term", "Gain", "Loss", "Subtotal", "Long-Term", "longTermGain",
                        "longTermLoss", "longTermSubtotal", "Net Gain / (Loss) Total");
        final String year = "2021";
        final String month = "1";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Close dates are not available in Current value filter screen.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        Assert.assertFalse(
                getDriver().isElementVisible(getPortfolioFilterScreen().getClosingDateHeader())
                , "Current Value Filter has Closing Date.");

        log.info("Verify Realized Gain/Loss Details are displayed.");
        getPortfolioFilterScreen().tapCancel();
        getPortfolioScreen().waitToLoad();
        getPortfolioScreen().tapRealizedGainLoss();
        getPortfolioScreen().waitForRealizedGLToLoad();
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitForRealizedGLFilterToLoad();
        getPortfolioFilterScreen().selectClosingDate(year, month);
        getPortfolioFilterScreen().tapDone();
        getPortfolioScreen().waitForRealizedGLToLoad();

        getDriver().waitUntilVisible(getPortfolioScreen().getLongTermText());
        Assert.assertEquals(getPortfolioScreen().fetchGainLossDetails().keySet(),
                unrealizedLossGainDetails);
        final List<String> realizedGainLossValues = getPortfolioScreen()
                .fetchGainLossDetails().values()
                .stream().collect(Collectors.toList());
        verifyUnrealizedGainLossDetails(realizedGainLossValues);
        verifyUnrealizedGainLossTotalValue(realizedGainLossValues);
    }

    @Test(
            description =
                    "1249247: Verify that all accounts are selected by default when user navigates to filter<br>"
                            + "1247503: Verify the date format from calendar picker will follow localization<br>"
                            + "1247423: Verify App Display pills/chips to show the breakdown of filters for Current Value under Porfolio screen<br>", dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestVerifyPortfolioPillsAndFilterDefaultAccounts(final String username,
                                                                 final String password) {
        List<String> accountGroups = Arrays.asList("Assets");
        final String TIMEZONE_PACIFIC = "Canada/Pacific";
        final String allAccounts = "All Accounts";
        final String year = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(1)
                .format(DateTimeFormatter.ofPattern("YYYY"));
        final String month = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(1)
                .format(DateTimeFormatter.ofPattern("M"));
        final String day = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(1)
                .format(DateTimeFormatter.ofPattern("d"));

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Default chips shown and default account groups in filter.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        Assert.assertTrue(getPortfolioScreen().getAllAccountsChip().isDisplayed(),
                "All Accounts chip is not displayed.");
        Assert.assertTrue(getPortfolioScreen().getAllSecuritiesChip().isDisplayed(),
                "All Securities chip is not displayed.");
        getPortfolioScreen().tapRealizedGainLoss();
        getPortfolioScreen().waitForRealizedGLToLoad();
        List<String> chips = getPortfolioScreen().fetchChips();
        String fromDate = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusMonths(1).minusDays(1)
                .format(DateTimeFormatter.ofPattern("MMM d"));
        String toDate = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusDays(2)
                .format(DateTimeFormatter.ofPattern("MMM d"));
        String dateChip = String.format("%s – %s", fromDate, toDate);
        Assert.assertEquals(chips.get(0), allAccounts, "All accounts chip text Not matching.");
        Assert.assertEquals(chips.get(1), dateChip, "Date chip text Not matching.");
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitForRealizedGLFilterToLoad();
        getPortfolioFilterScreen().tapAllAccounts();
        getPortfolioFilterScreen().waitForAllAccountsToLoad();
        Assert.assertEquals(getPortfolioFilterScreen().fetchAccountGroups(), accountGroups,
                "Account groups not matching.");
        getPortfolioFilterScreen().verifyAccountsSelected();

        log.info("Unselect few accounts and verify the Pills.");
        final List<String> accounts = getPortfolioFilterScreen().fetchAccounts();
        getPortfolioFilterScreen()
                .selectDeselectAccount(accounts.get(0), Toggle.OFF.getBoolValue());
        getPortfolioFilterScreen()
                .selectDeselectAccount(accounts.get(1), Toggle.OFF.getBoolValue());
        final int selectedAccountsCount = accounts.size() - 2;
        getPortfolioFilterScreen().tapDone();
        getPortfolioFilterScreen().waitForRealizedGLFilterToLoad();
        getPortfolioFilterScreen().selectClosingDate(year, day);
        getPortfolioFilterScreen().tapDone();
        getPortfolioScreen().waitForRealizedGLToLoad();
        chips = getPortfolioScreen().fetchChips();
        final String accountChip = String.format("Accounts (%s)", selectedAccountsCount);
        fromDate = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(1).minusMonths(1)
                .minusDays(1)
                .format(DateTimeFormatter.ofPattern("MMM d, YYYY"));
        toDate = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusDays(2)
                .format(DateTimeFormatter.ofPattern("MMM d, YYYY"));
        dateChip = String.format("%s – %s", fromDate, toDate);
        Assert.assertEquals(chips.get(0), accountChip, "All accounts chip text Not matching.");
        Assert.assertEquals(chips.get(1), dateChip, "Date chip text Not matching.");
    }

    private void verifyUnrealizedGainLossDetails(List<String> values) {
        SoftAssert verifyUnrealizedGainLossValues = new SoftAssert();

        verifyUnrealizedGainLossValues
                .assertTrue(values.get(1).startsWith("$"), "Gain mismatched.");
        verifyUnrealizedGainLossValues
                .assertTrue(values.get(2).startsWith("($") || values.get(2).equals("$0.00"),
                        "Loss mismatched.");
        verifyUnrealizedGainLossValues
                .assertTrue(values.get(3).startsWith("$"), "Short term Sub total mismatched");
        verifyUnrealizedGainLossValues
                .assertTrue(values.get(5).startsWith("$"), "LongTerm Gain mismatched.");
        verifyUnrealizedGainLossValues
                .assertTrue(values.get(6).startsWith("($") || values.get(6).equals("$0.00"),
                        "LongTerm Loss mismatched.");
        verifyUnrealizedGainLossValues
                .assertTrue(values.get(7).startsWith("$") || values.get(7).startsWith("($"),
                        "LongTerm SubTotal mismatched.");
        verifyUnrealizedGainLossValues
                .assertTrue(values.get(8).startsWith("$") || values.get(8).startsWith("($"),
                        "Net Total mismatched.");

        verifyUnrealizedGainLossValues.assertAll();
    }

    private void verifyUnrealizedGainLossTotalValue(List<String> values) {
        final float shortTermSubtotal = Float
                .parseFloat(values.get(3).replaceAll("[^\\d.]+", ""));
        final float longTermSubtotal = Float
                .parseFloat(values.get(7).replaceAll("[^\\d.]+", ""));
        float netGainLossTotal;
        if (values.get(3).startsWith("(")) {
            netGainLossTotal = longTermSubtotal - shortTermSubtotal;
        } else {
            netGainLossTotal = longTermSubtotal + shortTermSubtotal;
        }

        final DecimalFormat decfor = new DecimalFormat("0.00");
        netGainLossTotal = Float.parseFloat(decfor.format(netGainLossTotal));
        final float netTotal = Float
                .parseFloat(values.get(8).replaceAll("[^\\d.]+", ""));
        Assert.assertEquals(netTotal, netGainLossTotal, "Net Gain/Loss Total verification failed.");
    }

    private void verifyStockRecordDetail_ValueChange(final List<String> cusipList) {
        for (String cusip : cusipList) {
            Assert
                    .assertTrue(getPortfolioScreen().getCurrentValue(cusip).getText().startsWith("$") &&
                            getPortfolioScreen().getCurrentValue(cusip).isDisplayed());
            Assert.assertTrue(
                    getPortfolioScreen().getCurrentValueChange(cusip).getText().contains("$") &&
                            getPortfolioScreen().getCurrentValue(cusip).isDisplayed());
            Assert
                    .assertTrue(getPortfolioScreen().getpriceChange(cusip).getText().contains("$") &&
                            getPortfolioScreen().getCurrentValue(cusip).isDisplayed());
        }
    }

    private void verifyStockRecordDetail_GainLoss(final List<String> cusipList) {
        for (String cusip : cusipList) {
            log.info("Name: " + cusip);
            Assert
                    .assertTrue(getPortfolioScreen().getCurrentValue(cusip).getText().startsWith("$") &&
                            getPortfolioScreen().getCurrentValue(cusip).isDisplayed());
            Assert.assertTrue(
                    getPortfolioScreen().getCurrentValueChange(cusip).getText().contains("$") &&
                            getPortfolioScreen().getCurrentValue(cusip).isDisplayed());
            Assert
                    .assertTrue(getPortfolioScreen().getpriceChange(cusip).getText().contains("%") &&
                            getPortfolioScreen().getCurrentValue(cusip).isDisplayed());
        }

    }

}
