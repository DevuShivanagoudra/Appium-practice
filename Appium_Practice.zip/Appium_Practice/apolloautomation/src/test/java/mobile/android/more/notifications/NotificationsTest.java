package mobile.android.more.notifications;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Slf4j
public class NotificationsTest extends AndroidTestBase {

    static final String secretAnswer = "secret";

    @Test(
            description = "1504680: Verify the app can delete a notification",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDeletingANotification(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to More screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Verify Notifications screen");
        getMoreScreen().tapMoreOption(MoreOptions.NOTIFICATIONS.toString());
        getNotificationsScreenAndroid().waitToLoad();

        log.info("Deleting the notification");
        getNotificationsScreenAndroid().swipingAndDeletingNotification();
    }

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }
}
