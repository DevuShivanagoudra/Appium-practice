package mobile.android.login;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import mobile.base.AndroidTestBase;
import mobile.common.constants.TabBarOption;
import mobile.common.constants.Toggle;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
public class LoginTest extends AndroidTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description = "", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "login", "regression"})
    public void TestLogin(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();
        verifyAccountsScreen();
    }

    @Test(
            description = "1188669: Mobile - Login - User click on show/hide Username"
                    + "1154685: Verify hide username is turned on  by default when user launches the app"
                    + "1154694: Verify that username is not displayed if user toggle hide username"
                    + "1154687: Verify user can see username after toggle on show/hide username icon", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "login", "regression"})
    public void TestShowHideUsername(final String username, final String password) {

        log.info("Sign In.");
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();

        log.info("Verify Username is not revealed by default.");
        getLoginScreen().fillUsername(username);
        Assert.assertEquals(getLoginScreen().getUsername().getText().length(),
                username.length(),
                "Hidden Username string doesn't match.");

        log.info("Verify Username is shown when tapped on ShowHide icon.");
        getLoginScreen().tapShowHideIconUsername();
        Assert.assertEquals(getLoginScreen().getUsername().getText(), username,
                "Username string doesn't match.");

        log.info("Verify Username gets hidden when tapped again on ShowHide icon.");
        getLoginScreen().tapShowHideIconUsername();
        Assert.assertEquals(getLoginScreen().getUsername().getText().length(),
                username.length(),
                "Hidden Username string doesn't match.");

    }

    @Test(
            description =
                    "1188696: Mobile - Login - User click on show/hide Password"
                            + "1156036: Verify password that entered at the time of login should be hidden by default"
                            + "1156039: Verify that user can able to see the password that entered at the time of login"
                            + "1156040: Verify that user can hide password that entered at the time of login ", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "login", "regression"})
    public void TestShowHidePassword(final String username, final String password) {

        log.info("Sign In.");
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();

        log.info("Verify Password is not revealed by default.");
        getLoginScreen().fillPassword(password);
        Assert.assertEquals(getLoginScreen().getPassword().getText().length(),
                password.length(),
                "Hidden Password string doesn't match.");

        log.info("Verify Password is shown when tapped on ShowHide icon.");
        getLoginScreen().tapShowHideIconPassword();
        Assert.assertEquals(getLoginScreen().getPassword().getText(), password,
                "Password string doesn't match.");

        log.info("Verify Password gets hidden when tapped again on ShowHide icon.");
        getLoginScreen().tapShowHideIconPassword();
        Assert.assertEquals(getLoginScreen().getPassword().getText().length(),
                password.length(),
                "Hidden Password string doesn't match.");
    }

    @Test(
            description =
                    "1159866: To verify if user can navigate to Forgot UserName screen"
                            + "1159867: To verify if user can navigate to Forgot Password Page"
                            + "1156831: Verify that user is able to open login help screen", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "login", "regression"})
    public void TestForgotUsernameAndPassword(final String username, final String password) {
        final String supportURL = "clientaccess.rjf.com/Support";
        final String forgotUsernameSupportURL = String
                .format("%s%s", supportURL, "/RecoverLoginId");
        final String forgotPasswordSupportURL = String.format("%s%s", supportURL, "/Password");
        final String forgotLoginHelpSupportURL = String.format("%s%s", supportURL, "/LoginHelp");

        log.info("Sign In.");
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();

        log.info("Verify Username support page is displayed on clicking 'Forgot Username' link.");
        getLoginScreen().tapForgotUsername();
        getExitAppAlert().waitToLoad();
        getExitAppAlert().tapYes();
        getSupportWebPageScreen().waitToLoad();
        Assert.assertTrue(getSupportWebPageScreen().getRecoverUsername().isDisplayed());
        Assert.assertEquals(getSupportWebPageScreen().getPageURL().getText(),
                forgotUsernameSupportURL);
        CommonUtils.terminateApp(getDriver(), CHROME_APPPACKAGE);

        log.info("Verify Username support page is displayed on clicking 'Forgot Password' link.");
        getLoginScreen().tapForgotPassword();
        getExitAppAlert().waitToLoad();
        getExitAppAlert().tapYes();
        getSupportWebPageScreen().waitToLoad();
        Assert.assertTrue(getSupportWebPageScreen().getRecoverPassword().isDisplayed());
        Assert.assertEquals(getSupportWebPageScreen().getPageURL().getText(),
                forgotPasswordSupportURL);
        CommonUtils.terminateApp(getDriver(), CHROME_APPPACKAGE);

        log.info("Verify Username support page is displayed on clicking 'Sign In Help' link.");
        getLoginScreen().tapSigninHelp();
        getExitAppAlert().waitToLoad();
        getExitAppAlert().tapYes();
        getSupportWebPageScreen().waitForSignInHelpPageToLoad();
        Assert.assertTrue(getSupportWebPageScreen().getSignInHelpPage().isDisplayed());
        Assert.assertEquals(getSupportWebPageScreen().getPageURL().getText(),
                forgotLoginHelpSupportURL);
        CommonUtils.terminateApp(getDriver(), CHROME_APPPACKAGE);
    }

    @Test(description = "1154477: Verify that remember username is checked by default"
            + "1154679: Verify username is not saved by default after logging in and logout from the account"
            + "1154681: Verify username is not saved if user un-checks remember username checkbox"
            + "1154680: Verify Username is SAVED and MASKED after selecting Remember Username",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"login", "regression"})
    public void TestVerifyRememberUsername(final String username, final String password) {
        final String user = "";
        final String hiddenUsername = String.format("•••••••");

        log.info("Sign In.");
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();

        log.info("Verify 'Remember User' is Not checked by default.");
        Assert.assertTrue(getDriver().isElementChecked(getLoginScreen().getRememberUsername()),
                "'Remember Username' is NOT selected by default.");

        log.info("Verify 'Remember User' is not saved by unchecking the checkbox.");
        getLoginScreen().setRememberUserName(Toggle.OFF.getBoolValue());
        login(username, password, secretAnswer);
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(getBiometricsSetupScreen().getNoThanks())
                                , ExpectedConditions.visibilityOf(getDashboardScreen().getDashboardHeader())),
                "Biometrics/Dashboard Screen is not displayed.");
        if (getDriver().isElementVisible(getBiometricsSetupScreen().getNoThanks())) {
            getBiometricsSetupScreen().tapNoThanks();
        }
        getDashboardScreen().waitToLoad();
        tearDownApp();
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();
        Assert.assertEquals(getLoginScreen().getUsername().getText(), user,
                "Username got saved even on unchecking the checkbox.");

        log.info("Verify 'Remember User' is saved by checking the checkbox and is hidden on next Login.");
        getLoginScreen().setRememberUserName(Toggle.ON.getBoolValue());
        login(username, password, secretAnswer);
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT, ExpectedConditions
                        .or(ExpectedConditions.visibilityOf(getBiometricsSetupScreen().getNoThanks())
                                , ExpectedConditions.visibilityOf(getDashboardScreen().getDashboardHeader())),
                "Biometrics/Dashboard Screen is not displayed.");
        if (getDriver().isElementVisible(getBiometricsSetupScreen().getNoThanks())) {
            getBiometricsSetupScreen().tapNoThanks();
        }
        getDashboardScreen().waitToLoad();
        tearDownApp();
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();
        Assert.assertEquals(getLoginScreen().getUsername().getText().length(),
                hiddenUsername.length(),
                "Username is not masked on Login Screen.");
    }

    @Test(description = "1156182: Verify that user can able to navigate to all screens listed on tab bar"
            + "1156132: Verify that user presented with default options on tab bar as per UI/UX design",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class,
            groups = {"login", "regression"})
    public void TestVerifyTabBar(final String username, final String password) {

        log.info("Sign In and verify user able to select 'Accounts' tabbar.");
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Sign In and verify user able to select 'Porfolio' tabbar.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();

        log.info("Sign In and verify user able to select 'Analysis' tabbar.");
        getTabBar().tap(TabBarOption.ACTIVITY);
        getActivityScreen().waitToLoad();

        log.info("Sign In and verify user able to select 'More' tabbar.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
    }

    @Test(description = "1156182: Verify that user can able to navigate to all screens listed on tab bar<br>"
            + "1156132: Verify that user presented with default options on tab bar as per UI/UX design",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"login", "regression"}, enabled = true)
    //This Whole functionality is getting removed.
    public void TestVerifyEditTabOrder(final String username, final String password) {
        List<String> tabbarOptions_Reorder = Arrays
                .asList("Accounts", "Portfolio", "Activity");

        log.info("Sign In and navigate to 'More' tab.");
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Verify Dashboard option is not displayed in the list of Tabbar names.");
        List<String> tabbarOptions_Order = getMoreScreen().getTabBarNames();
        tabbarOptions_Reorder = Stream
                .concat(tabbarOptions_Reorder.stream(), tabbarOptions_Order.stream())
                .collect(Collectors.toList());
        getMoreScreen().tapEdit();
        getMoreReorderScreen().waitToLoad();
        Assert.assertFalse(getMoreReorderScreen().isTabbarNameVisible("Dashboard"),
                "Dashboard option is visible on Reorder screen.");

        log.info("Verify All Tabbar Options displayed in Reorder screen.");
        Assert.assertEquals(getMoreReorderScreen().getTabBarNames(), tabbarOptions_Reorder);
        int endElementIndex = tabbarOptions_Reorder.indexOf("Documents");
        CommonUtils.dragDropElement(getDriver(),
                getMoreReorderScreen().getTabbarDragIcon("Funds Transfer"),
                getMoreReorderScreen().getTabbarDragIcon("Documents"));
        tabbarOptions_Reorder.remove("Funds Transfer");
        tabbarOptions_Reorder.add(endElementIndex, "Funds Transfer");
        Assert.assertEquals(getMoreReorderScreen().getTabBarNames(), tabbarOptions_Reorder);
        getMoreReorderScreen().tapSave();
        getMoreScreen().waitToLoad();
        tabbarOptions_Order = tabbarOptions_Reorder.subList(3, tabbarOptions_Reorder.size());
        Assert.assertEquals(getMoreScreen().getTabBarNames(), tabbarOptions_Order);

        getMoreScreen().tapEdit();
        getMoreReorderScreen().waitToLoad();
        endElementIndex = tabbarOptions_Reorder.indexOf("Market Research");
        CommonUtils
                .dragDropElement(getDriver(), getMoreReorderScreen().getTabbarDragIcon("Bill Pay"),
                        getMoreReorderScreen().getTabbarDragIcon("Market Research"));
        tabbarOptions_Reorder.remove("Bill Pay");
        tabbarOptions_Reorder.add(endElementIndex, "Bill Pay");
        Assert.assertEquals(getMoreReorderScreen().getTabBarNames(), tabbarOptions_Reorder);
        getMoreReorderScreen().tapSave();
        getMoreScreen().waitToLoad();
        tabbarOptions_Order = tabbarOptions_Reorder.subList(3, tabbarOptions_Reorder.size());
        Assert.assertEquals(getMoreScreen().getTabBarNames(), tabbarOptions_Order);

        log.info("Verify Reordered Tabbar Options are not retained without saving.");
        getMoreScreen().tapEdit();
        getMoreReorderScreen().waitToLoad();
        CommonUtils.dragDropElement(getDriver(), getMoreReorderScreen().getTabbarDragIcon("Vault"),
                getMoreReorderScreen().getTabbarDragIcon("Market Research"));
        getMoreReorderScreen().tapBack();
        getMoreScreen().waitToLoad();
        Assert.assertEquals(getMoreScreen().getTabBarNames(), tabbarOptions_Order);
    }

    @Test(description = "1155791: Verify if Disclosure text is shown on clicking Disclosures",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"login", "regression"})
    public void TestDisclosuresText(final String username, final String password) {
        SoftAssert check = new SoftAssert();
        final String disclosureText1 = "Ⓒ 2022 Raymond James & Associates, Inc., Member New "
                + "York Stock Exchange/SIPC. | Statement of Financial Condition "
                + "(https://www.raymondjames.com/-/media/rj/dotcom/files/our-company"
                + "/about-us/rja-statement-of-financial-condition.pdf)";

        final String disclosureText2 = "The Dow Jones Indexes℠ are compiled, calculated and "
                + "distributed by Dow Jones & Company, Inc. and have been licensed for use. All content "
                + "of the Dow Jones Indexes℠ Ⓒ 2022 Dows Jones & Company, Inc. View Terms and Conditions "
                + "of use.";

        final String disclosureText3 =
                "Raymond James & Associates, Inc. member New York Stock Exchange "
                        + "(https://www.nyse.com/index) / SIPC (https://www.sipc.org/) and Raymond James Financial "
                        + "Services, Inc. member FINRA (https://www.finra.org/#/)/SIPC (https://www.sipc.org/) are "
                        + "subsidiaries of Raymond James Financial, Inc.";

        final String disclosureText4 =
                "Privacy/Security (https://www.raymondjames.com/privacy-security"
                        + "-and-account-protection/how-raymond-james-protects-your-privacy)";

        log.info("Sign In.");
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();

        log.info("Tapped on Disclosures");
        getLoginScreen().tapDisclosures();

        log.info("Verifying Disclosures Text");
        check.assertTrue(getDisclosuresScreen().getDisclosuresHeader(),
                "Disclosure Header Not displayed.");
        check.assertEquals(getDisclosuresScreen().getDisclosuresText().get(0),
                String.format("%s%s%s%s", disclosureText1, disclosureText2, disclosureText3,
                        disclosureText4),
                "Disclosure Text Not displayed.");
    }

    private void verifyAccountsScreen() {
        SoftAssert check = new SoftAssert();

        check.assertTrue(getAccountsScreen().getAccountsHeader().isDisplayed(),
                "Accounts Header is not displayed.");
        check.assertTrue(getAccountsScreen().getAllAccounts().isDisplayed(),
                "All Accounts tab is not displayed.");
        check.assertTrue(getAccountsScreen().getAssetsSection().isDisplayed(),
                "Raymond James Accounts tab is not displayed.");
        check.assertAll();
    }
}
