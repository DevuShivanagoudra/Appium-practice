package mobile.android.more.documents;

import api.utils.Accounts;
import jarvis.mobile.common.constants.Direction;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.android.AndroidUtils;
import mobile.base.AndroidTestBase;
import mobile.common.constants.Messages;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class DocumentsTest extends AndroidTestBase {

    static final String secretAnswer = "secret";
    final String documentType_TaxReporting = "Tax Reporting";
    final String documentType_Statements = "Statements";
    final String yearMostRecent = "Most Recent";
    final String year = "2021";
    final String titleFilter = "Filter";
    final String titleDocuments = "Documents";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1200479: Verify that app displays the following when user tap on filter on documents tab"
                            + "1201130: Verify that app displays the list of filters that has been selected on main Documents screen'"
                            + "1201130: Verify that app displays the list of filters that has been selected on main Documents screen", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsFilterHeaders(final String username, final String password) {
        List<String> documentTypes = Arrays
                .asList("Statements", "Trade Confirmations", "Tax Reporting", "Reports & Proxies",
                        "Prospectuses", "Other Correspondence");
        Map<String, String> deliveryTypes = new HashMap<>();
        deliveryTypes.put("Statements", "E-Delivery");
        deliveryTypes.put("Trade Confirmations", "E-Delivery");
        final String documentType_Statements = "Statements";

        List<String> filterChips = Arrays
                .asList("All Accounts", documentType_TaxReporting, "2021");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify Filter Screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        Assert.assertTrue(getDocumentsFilterScreen().getAccountsHeader().isDisplayed(),
                "Accounts header is not displayed.");
        Assert.assertTrue(getDocumentsFilterScreen().getDocumentTypeHeader().isDisplayed(),
                "Document Type is not displayed.");
        Assert.assertTrue(
                getDriver().scrollTo(getDocumentsFilterScreen().getYearHeader()).isDisplayed(),
                "Year is not displayed.");
        verifyDocumentTypes(documentTypes);

        log.info("Select Document Type and Year and verify the Documents screen.");
        getDocumentsFilterScreen().selectDocumentType(documentType_TaxReporting);
        Assert.assertTrue(
                getDocumentsFilterScreen().isDocumentTypeSelected(documentType_TaxReporting),
                String.format("%s is not selected.", documentType_TaxReporting));
        Assert
                .assertFalse(getDocumentsFilterScreen().isDocumentTypeSelected(documentType_Statements),
                        String.format("%s is selected.", documentType_Statements));
        getDocumentsFilterScreen().selectYear(year);
        getDocumentsFilterScreen().tapDone();
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getFilterChips().subList(0, 3), filterChips,
                "Filter Chips Not matched");
    }

    @Test(
            description =
                    "1202360: Verify the app sorts the year options from the most recent to the least recent"
                            + "1201131: Verify that app displays the document type and date for the document that has been displayed", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsRecordDetails(final String username, final String password) {
        final String year = "2021";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify list of years displayed in order");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        verifyListOfYearsOnFilterScreen();
        getDocumentsFilterScreen().selectYear(year);
        getDocumentsFilterScreen().tapDone();
        getDocumentsScreen().waitToLoad();

        log.info("Verify record attributes");
        //FIXME: Fix after the locators are fixed "TASK 1354689"
        //VerifyDocumentsRecordDetails();
    }

    @Test(
            description =
                    "1201122:Verify that all accounts are selected as a default when user first navigates to accounts filter screen", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsFilterAccountsSelected(final String username,
                                                          final String password) {
        SoftAssert accountSelected = new SoftAssert();
        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify Filter Screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen();
        log.info("Filter Screen displayed");
        accountSelected.assertEquals(getDocumentsFilterScreen().getAccountSelectedIcon().size(), 8,
                "Account List Not Displayed");
        log.info("Filter screen display all accounts selected");

    }

    @Test(
            description =
                    "1201120: Verify that app displays list of accounts that user has when user tap on filter", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsFilterAccount(final String username, final String password) {
        SoftAssert check = new SoftAssert();
        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify Filter Screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        getDocumentsFilterScreen().tapFilterByAccounts();
        getDocumentsFilterScreen().waitUntilAccountsLoaded();
        Assert.assertTrue(getDocumentsFilterScreen().getAccountsHeader().isDisplayed(),
                "Filter screen Not  displayed.");

        check.assertEquals(getDocumentsFilterScreen().getAccountList().size(), 8,
                "Account List Not Displayed");
    }

    @Test(
            description =
                    "1255007:Verify Documents Filter Screen Title and icon to navigate back<br>"
                            + "1202359: Verify the app does not allow user to select multiple year options<br>", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsFilterScreenTitleAndBackButton(final String username,
                                                                  final String password) {
        final String year = "2021";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to More screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Navigate to Documents screen.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify Filter Screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        Assert.assertEquals(getDocumentsFilterScreen().getTitle().getText(), titleFilter,
                "Document filter screen title is not matched.");
        getDocumentsFilterScreen().selectYear(year);
        verifySelectedYearOnFilterScreen(year);

        log.info("Navigate to Main Documents Screen.");
        getDocumentsFilterScreen().tapBack();
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getTitle().getText(), titleDocuments,
                "Documents screen is not Displayed.");
    }

    @Test(
            description =
                    "1200027:Verify that app displays the following message when there is no documents that has to be displayed if user has selected any filtering option<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"documents",
            "regression"})
    public void TestVerifyNoDocumentsWhenFilterIsApplied(final String username,
                                                         final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to More screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Navigate to Documents screen.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify Filter Screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();

        log.info("Filter Screen displayed.");
        getDocumentsFilterScreen().selectDocumentType(documentType_TaxReporting);
        getDocumentsFilterScreen().tapDone();
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getNoDocumentsText().getText(),
                Messages.NO_DOCUMENTS_TEXT.toString(),
                "No Documents Available message is not displayed.");
    }

    @Test(
            description =
                    "1200487: Verify that app displays list of documents of type that has been selected while filtering"
                            + "1206283: Verify the app allows user to open the document file", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"}, enabled = false)
    //FIXME: This test is making the suite fail skipping all the tests. commented for time being.
    public void TestVerifyDocumentsFiles(final String username, final String password) {
        final String documentType = "Statements";
        final String year = "2021";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify all the documents shown are of type that is selected in the filter.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        getDocumentsFilterScreen().selectDocumentType(documentType);
        getDocumentsFilterScreen().selectYear(year);
        getDocumentsFilterScreen().tapDone();
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getDocumentTypes().size(),
                getDocumentsScreen().getStatementDates().size(),
                "All the documents are not of same type.");

        log.info("Verify User is able to open the document file.");
        getDocumentsScreen().tapDocumentRecord();
        getDocumentFileScreen().waitToLoad();
        Assert.assertTrue(getDriver().isElementPresent(getDocumentFileScreen().getPageContent()),
                "Document is not opened.");
        Assert.assertTrue(getDocumentFileScreen().getTitle().isDisplayed(),
                "Document Title not displayed.");
    }

    @Test(
            description =
                    "1331028:Verify the Default filter Settings as said in the test case<br>" +
                            "1379864:Verify the Documents main screen will display the following copy when Shareholder Documents was selected for the Document Type in the filter"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsDefaultFilters(final String username, final String password) {
        final String documentType = "Shareholder Documents";
        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Navigate to Documents filter screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        getDocumentsFilterScreen().verifyAccountsSelected();
        Assert.assertTrue(
                getDocumentsFilterScreen().isDocumentTypeSelected(documentType_Statements),
                "Statements is not selected by Default.");
        Assert.assertTrue(
                getDocumentsFilterScreen().isYearSelected(yearMostRecent),
                "Most Recent is not selected by Default.");

        log.info("Select document type.");
        getDocumentsFilterScreen().selectDocumentType(documentType);
        getDocumentsFilterScreen().tapDone();
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getShareHolderDocumentText().getText(),
                Messages.DOCUMENTS_SHAREHOLDER_TEXT_ANDROID.toString(),
                "Shareholder document text is not matched.");
    }

    @Test(
            description =
                    "1170563: Verify the app navigates to the Documents tab when user taps the \"Documents\" button"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsFilterScreenForDefaults(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify Filter Screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        getDocumentsFilterScreen().verifyDefaultsOnDocumentsFilterScreen();
    }

    private void verifyDocumentTypes(final List<String> documentTypes) {
        for (String type : documentTypes) {
            getDocumentsFilterScreen().isDocumentTypeVisible(type);
        }
    }

    private void verifyListOfYearsOnFilterScreen() {
        getDriver().swipeScreen(Direction.UP);
        List<String> elements = getDocumentsFilterScreen().getTextElements().stream()
                .map(WebElement::getText).collect(
                        Collectors.toList());
        final int yearIndex = elements.indexOf("Year");
        final List<String> years = elements.subList(yearIndex + 1, elements.size());
        final List<String> actualYears = years;
        Collections.sort(years, Comparator.reverseOrder());
        Assert.assertEquals(actualYears, years);
    }

    private void verifySelectedYearOnFilterScreen(final String year) {
        getDriver().swipeScreen(Direction.UP);
        List<String> elements = getDocumentsFilterScreen().getTextElements().stream()
                .map(WebElement::getText).collect(
                        Collectors.toList());
        final int yearIndex = elements.indexOf("Year");
        List<String> years = elements.subList(yearIndex + 1, elements.size());
        years.remove(year);
        Assert.assertTrue(getDocumentsFilterScreen().isYearSelected(year),
                String.format("Year %s is not selected.", year));
        for (String deSelectedYear : years) {
            Assert.assertFalse(getDocumentsFilterScreen().isYearSelected(deSelectedYear),
                    String.format("Year %s is selected.", deSelectedYear));
        }
    }

    private void VerifyDocumentsRecordDetails() {
        //FIXME: Fix after the locators are fixed "TASK 1354689"
        final String elementTag = "new UiSelector().text(\"Statements\")";
        for (WebElement element : getDocumentsScreen().getDocType()) {
            Assert.assertTrue(element.isDisplayed(), "Doc Type Not displayed.");
            Assert.assertTrue(AndroidUtils.getSibling(getDriver(), elementTag, 1).isDisplayed(),
                    "Record Name Not displayed.");
            Assert.assertTrue(AndroidUtils.getSibling(getDriver(), elementTag, 3).isDisplayed(),
                    "Record Date Not displayed.");
        }
    }
}
