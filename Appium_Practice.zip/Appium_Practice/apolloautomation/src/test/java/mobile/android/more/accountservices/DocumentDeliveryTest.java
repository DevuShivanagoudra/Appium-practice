package mobile.android.more.accountservices;

import api.utils.Accounts;
import io.appium.java_client.AppiumBy;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import mobile.common.constants.Toggle;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static mobile.common.constants.AccountServicesOptions.DOCUMENT_DELIVERY;

@Slf4j
public class DocumentDeliveryTest extends AccountServices {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "ddobillingandstatement")
    public Object[][] ddobillingandstatement() {
        return new Object[][]{
                {Accounts.USERNAME6.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "noaccessaccount")
    public Object[][] noaccessaccount() {
        return new Object[][]{
                {Accounts.USERNAME7.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description = "1184683: Verify the user can toggle 'Choose E-delivery for All Documents'"
                    + "1184684: Verify the app displays the following list of document types if user set 'E-Delivery for all documents' to false"
                    + "1184689: Verify the user can able to choose Paper delivery or E-Delivery for document types", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsSaved(final String username, final String password) {
        List<String> documentTypes = Arrays
                .asList("Statements", "Trade Confirmations", "Tax Reporting", "Reports & Proxies",
                        "Prospectuses", "Other Correspondence");
        Map<String, String> deliveryTypes = new HashMap<>();
        deliveryTypes.put("Statements", "E-Delivery");
        deliveryTypes.put("Trade Confirmations", "E-Delivery");
        Map<String, String> accounts = new HashMap<>();
        accounts.put("zx", "E-Delivery");
        accounts.put("Test account", "E-Delivery");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();

        log.info("Verify Delivery types are shown on toggling 'E-Delivery for All Documents'.");
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        verifyDeliveryTypesVisible(documentTypes);
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.ON);
        verifyDeliveryTypesNOTVisible(documentTypes);

        log.info("Set Document Types and check the changes persist by logout and login back.");
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        getDocumentDeliveryScreen().tapDocumentType(documentTypes.get(0));
        getAccountDeliveryOptionsScreen().waitToLoad();
        getAccountDeliveryOptionsScreen().setDeliveryTypes(accounts);
        getDocumentDeliveryScreen().tapBack();
        getDocumentDeliveryScreen().waitToLoad();
        getDocumentDeliveryScreen().tapDocumentType(documentTypes.get(1));
        getAccountDeliveryOptionsScreen().waitToLoad();
        getAccountDeliveryOptionsScreen().setDeliveryTypes(accounts);
        getAccountDeliveryOptionsScreen().tapBack();
        getDocumentDeliveryScreen().waitToLoad();
        tearDownApp();
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();
        getDocumentDeliveryScreen().tapDocumentType(documentTypes.get(1));
        getAccountDeliveryOptionsScreen().waitToLoad();
        final List<String> accountsList = accounts.keySet().stream().collect(Collectors.toList());
        Assert.assertTrue(
                getAccountDeliveryOptionsScreen().isAccountSelected(accountsList.get(0)),
                String.format("[%s] option is not saved.", accountsList.get(0)));
        Assert.assertTrue(
                getAccountDeliveryOptionsScreen().isAccountSelected(accountsList.get(1)),
                String.format("[%s] option is not saved.", accountsList.get(1)));
    }

    @Test(
            description =
                    "1209554: Verify the Document Delivery Options when the user has RJ Bank DDO Billing<br>"
                            + "1209546: Verify the Document Delivery Options when the user has invalid DDO account (DMI)<br>"
            , dataProvider = "ddobillingandstatement", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsEditable(final String username, final String password) {
        Map<String, String> deliveryTypes = new HashMap<>();
        deliveryTypes.put("Statements", "E-Delivery");
        final String DMIAccount = "Residential Mortgage";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();

        log.info("Verify Delivery options can be edited for individual accounts.");
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        verifyAccountDeliveryOptions(deliveryTypes);

        log.info("Verify DMI account is not shown up the list of Document delivery accounts.");
        tearDownApp();
        login(Accounts.USERNAME6.toString(), password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        verifyAccountNotVisible(DMIAccount);
    }

    @Test(
            description =
                    "1209490: Verify the Document Delivery Options when the user has no full access to DDO displayed<br>"
                            + "1209494: Verify the Document Delivery Options when the user only has Raymond James accounts<br>"
            , dataProvider = "noaccessaccount", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsVisibleForNoAccessAccount(final String username,
                                                                   final String password) {
        List<String> documentTypes = Arrays
                .asList("Statements", "Trade Confirmations", "Tax Reporting", "Reports & Proxies",
                        "Prospectuses", "Other Correspondence");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();

        log.info("Verify Delivery options Not displayed.");
        //getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        Assert.assertFalse(getDocumentDeliveryScreen().getEDeliveryAllOptions().isEnabled(),
                "EDelivery for all Documents is enabled for account with no access.");
        verifyDeliveryTypesNOTVisible(documentTypes);

        //TODO: yet to implement TC 1209494. Test data not available.

    }

    @Test(
            description =
                    "1209558: Verify the Document Delivery Options when the user has RJ Bank DDO Statement<br>"
                            + "1209565: Verify the Document Delivery Options when the user has both RJ Bank DDO Billing & Statement<br>"
            , dataProvider = "ddobillingandstatement", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsVisibleForAccountWithDDOStatement(final String username,
                                                                           final String password) {
        Map<String, String> deliveryTypes = new HashMap<>();
        deliveryTypes.put("Statements", "E-Delivery");
        List<String> accounts = Arrays.asList("Wendy DampmanHenry Trust1 xxxx3934",
                "Simply Checking xxxxxx0565", "Select Savings xxxxxx2882");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();

        log.info("Verify Accounts visible and Delivery options are editable.");
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        getDocumentDeliveryScreen().tapAccountsHeader();
        verifyAccountsVisible(accounts);
        verifyAccountDeliveryOptions(deliveryTypes);
    }

    private void verifyDeliveryTypesVisible(final List<String> deliverytypes) {
        final String deliveryType_locator = "new UiSelector().text(\"%s\")";
        for (String type : deliverytypes) {
            getDriver().scrollTo(
                    AppiumBy.androidUIAutomator(String.format(deliveryType_locator, type)));
        }
    }

    private void verifyDeliveryTypesNOTVisible(final List<String> deliverytypes) {
        final String deliveryType_locator = "new UiSelector().text(\"%s\")";
        for (String type : deliverytypes) {
            Assert.assertFalse(getDriver().isElementPresent(
                            AppiumBy.androidUIAutomator(String.format(deliveryType_locator, type))),
                    String.format("%s is visible.", type));
        }
    }

}
