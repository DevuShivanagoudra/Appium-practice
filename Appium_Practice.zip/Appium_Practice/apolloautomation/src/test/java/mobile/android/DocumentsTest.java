package mobile.android;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import mobile.common.constants.Messages;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;

@Slf4j
public class DocumentsTest extends AndroidTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description = "1197666: Verify the app navigates to the Portfolio tab when user taps the Portfolio button",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDisclosuresInDocuments(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Verify Documents Tab.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify Disclosures Text in Documents screen.");
        getDocumentsScreen().tapDisclosuresLink();
        getDocumentsDisclosuresScreen().waitToLoad();
        Assert.assertEquals(
                getDocumentsDisclosuresScreen().getDisclosuresTexts(),
                Arrays.asList(Messages.ACTIVITY_DISCLOSURES_TEXT_ANDROID1.toString(),
                        Messages.ACTIVITY_DISCLOSURES_TEXT_ANDROID2.toString(),
                        Messages.ACTIVITY_DISCLOSURES_TEXT_ANDROID3.toString(),
                        Messages.ACTIVITY_DISCLOSURES_TEXT_ANDROID4.toString()));
    }

    @Test(
            description = "1200026:Verify that app displays the following message when there is no documents that need to be displayed",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyCopyWhenNoDocumentsAre(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Verify copy in Documents Screen when no documents are displayed.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getNoDocumentsText().getText(),
                Messages.NO_DOCUMENTS_TEXT.toString(),
                "No documents available text is not matched.");
    }

    @Test(
            description = "1203387: Verify that app displays the following message under Not getting your email notifications?",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyNotGettingEmailNotificationsSection(final String username,
                                                              final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to More screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Verify Documents Screen.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getNotGettingEmailNotificationsHeader().getText(),
                Messages.NOT_GETTING_EMAIL_NOTIFICATIONS_HEADER.toString(),
                "Not getting your email notifications Header is not matched.");
        Assert.assertEquals(getDocumentsScreen().getNotGettingEmailNotificationsText().getText(),
                Messages.NOT_GETTING_EMAIL_NOTIFICATIONS_TEXT.toString(),
                "Not getting your email notifications text is not matched.");
        Assert.assertEquals(
                getDocumentsScreen().getNotGettingEmailNotificationsEmailIDs().getText(),
                Messages.NOT_GETTING_EMAIL_NOTIFICATIONS_EMAIL_IDs.toString(),
                "Not getting your email notifications Email IDs are not matched.");
    }

    @Test(
            description = "1200023 : Verify that app navigated back to more tab when user tap on More button",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyBackButtonFunctionalityInDocumentsScreen(final String username,
                                                                   final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to More screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Verify Documents Screen.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getTitle().getText(), "Documents",
                "Document screen Title is not matched.");

        log.info("Tap back button and verify More screen.");
        getDocumentsScreen().tapBack();
        getMoreScreen().waitToLoad();
        Assert.assertEquals(getMoreScreen().getTitle().getText(), "More",
                "User is not landed in More screen.");
    }
}
