package mobile.android.accounts;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import mobile.common.constants.TabBarOption;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.TimeZone;

@Slf4j
public class AccountsValidationTest extends AndroidTestBase {

    static final String secretAnswer = "secret";
    private static final String TIMEZONE_PACIFIC = "Canada/Pacific";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "customerwithnoliabilities")
    public Object[][] customerwithnoliabilities() {
        return new Object[][]{
                {Accounts.USERNAME_NO_LIABILITIES.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "ckgcustomer")
    public Object[][] ckgcustomer() {
        return new Object[][]{
                {Accounts.CKGUSER.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1191424: Verify the Accounts widget displays 'Balance' if the account does not have liabilities"
                            + "1176333: Verify User is able to edit Account name for RJ account"
                            + "1191979: Verify that app enables edit mode when user tap on edit icon on the dashboard", dataProvider = "customerwithnoliabilities", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"}, enabled = false)
    //Accounts widget is removed from Dashboard in UI re-Design.
    public void TestVerifyAccountWidgetWithNoLiabilities(final String username,
                                                         final String password) {
        String zoneDateTime = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId())
                .format(DateTimeFormatter.ofPattern("YYYY-MM-dd"));

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts Widget.");
        Assert.assertEquals(getDashboardScreen().getBalanceLabel().getText(), "Balance",
                "Balance Label Not displayed for Account with No Liabilities.");
        Assert.assertTrue(!getDashboardScreen().getBalance().getText().isEmpty(),
                "Balance Value is not displayed");
        Assert.assertTrue(getDashboardScreen().getDateUpdated().getText().contains(zoneDateTime),
                "Balance not updated today.");

        log.info("Edit Dashboard.");
        getDashboardScreen().tapEdit();
        getEditDashboardScreen().waitToLoad();
        Assert.assertEquals(getEditDashboardScreen().getTitle().getText(), "Edit Dashboard",
                "Not able to edit Dashboard Screen.");
        Assert.assertTrue(getEditDashboardScreen().getWidgetCheckbox().isDisplayed(),
                "Not able to edit Dashboard Screen.");
        Assert.assertTrue(getEditDashboardScreen().getDragIcon().isDisplayed(),
                "Not able to edit Dashboard Screen.");

    }

    @Test(
            description =
                    "1191426: Verify that Account widget displays \"Net Balance\" if the account has liabilities"
                            + "1191420: Verify the displays Accounts widget at the top of the dashboard provides a summary of user account", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"}, enabled = false)
    //Accounts widget is removed from Dashboard in UI re-Design.
    public void TestVerifyAccountWidgetWithLiabilities(final String username,
                                                       final String password) {
        String zoneDate = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId())
                .format(DateTimeFormatter.ofPattern("YYYY-MM-dd"));

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts Widget.");
        Assert.assertEquals(getDashboardScreen().getTotalAssets().getText(), "Net Balance",
                "Balance Label Not displayed for Account with No Liabilities.");
        Assert.assertTrue(!getDashboardScreen().getBalance().getText().isEmpty(),
                "Balance Value is not displayed");
        Assert.assertTrue(getDashboardScreen().getDateUpdated().getText().contains(zoneDate),
                "Balance not updated today.");
    }

    @Test(
            description =
                    "1165891: Verify the app can switch between \"All Accounts\" and Raymond James Accounts\" tab"
                            + "1176332: Verify User is not able to edit Account name for External account through RJ App", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyUserSwitchingAccounts(final String username,
                                                final String password) {
        final String accountName = "Banking";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Verify user able to switch between 'All Accounts' and 'Raymond James'.");
        getAccountsScreen().tapAllAccounts();
        getAccountsScreen().waitToLoad();
        final int numOfAccounts_All = getAccountsScreen().fetchLiabilitiesAccounts().size();
        getAccountsScreen().tapRaymondJamesAccounts();
        getAccountsScreen().waitToLoad();
        final int numOfAccounts_RJ = getAccountsScreen().fetchLiabilitiesAccounts().size();
        Assert.assertTrue(numOfAccounts_All > numOfAccounts_RJ,
                "Data for All and RJ tabs is not loading correctly.");

        log.info("Verify user is not able to edit external account.");
        getTabBar().tap(TabBarOption.DASHBOARD);
        getDashboardScreen().waitToLoad();
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();
        getAccountsScreen().tapAllAccounts();
        Assert.assertFalse(getAccountsScreen().isInfoIconVisible(accountName),
                "Edit button got enabled for External Account.");
    }
}
