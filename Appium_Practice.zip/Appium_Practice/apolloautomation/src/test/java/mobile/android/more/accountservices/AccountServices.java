package mobile.android.more.accountservices;

import jarvis.mobile.common.constants.Direction;
import mobile.base.AndroidTestBase;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static mobile.common.constants.AccountServicesOptions.DOCUMENT_DELIVERY;

public class AccountServices extends AndroidTestBase {

    public void verifyAccountDeliveryOptions(final Map<String, String> deliveryTypes) {
        List<String> accountHeaders = Arrays.asList("View Only Accounts", "Bank Accounts");
        Map<String, String> deliveryTypeEdelivary = new HashMap<>();
        deliveryTypeEdelivary.put("Statements", "E-Delivery");
        Map<String, String> deliveryTypePaper = new HashMap<>();
        deliveryTypePaper.put("Statements", "Paper");
        getDriver().scrollTo(getDocumentDeliveryScreen().getAccountsHeader(), Direction.DOWN, 3).click();
        List<String> accounts = getDocumentDeliveryScreen().getAccounts()
                .stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        accounts.removeAll(accountHeaders);
        List<String> accountNames = Arrays.asList(accounts.get(0)/*, accounts.get(1)*/);
        for (String acct : accountNames) {
            getDocumentDeliveryScreen().tapAccount(acct);
            getAccountDeliveryOptionsScreen().waitToLoad();
            getAccountDeliveryOptionsScreen().setDeliveryTypes(deliveryTypeEdelivary);
            Assert.assertTrue(getDriver()
                            .isElementChecked(getAccountDeliveryOptionsScreen().getStatementsEDelivery()),
                    "Account Delivery Option is not Editable.");
            getAccountDeliveryOptionsScreen().setDeliveryTypes(deliveryTypePaper);
            Assert.assertFalse(getDriver()
                            .isElementChecked(getAccountDeliveryOptionsScreen().getStatementsEDelivery()),
                    "Account Delivery Option is not Editable.");
            getAccountDeliveryOptionsScreen().tapBack();
        }
    }

    public void verifyAccountDeliveryOptionsNotEditable(final Map<String, String> deliveryTypes) {
        Map<String, String> deliveryTypeEdelivary = new HashMap<>();
        deliveryTypeEdelivary.put("Statements", "E-Delivery");
        Map<String, String> deliveryTypePaper = new HashMap<>();
        deliveryTypePaper.put("Statements", "Paper");
        getDriver()
                .scrollTo(getDocumentDeliveryScreen().getAccountsHeader(), Direction.UP, 3);
        getDriver().swipeScreen(Direction.UP_SMALL);
        List<String> accounts = getDocumentDeliveryScreen().getViewOnlyAccounts()
                .stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        List<String> accountNames = Arrays.asList(accounts.get(0), accounts.get(
                accounts.size() / 2), accounts.get(accounts.size() - 1));
        for (String acct : accountNames) {
            getDocumentDeliveryScreen().tapAccount(acct);
            Assert.assertEquals(getDocumentDeliveryScreen().getTitle().getText(),
                    "Document Delivery", "Title does not match.");
            Assert.assertTrue(getDriver().isElementVisible(getDocumentDeliveryScreen().getAccountsHeader()),
                    "Account Delivery Option is Editable.");
        }
    }

    public void verifyAccountsVisible(List<String> accounts) {
        for (String account : accounts) {
            Assert.assertTrue(getDocumentDeliveryScreen().isAccountVisible(account),
                    String.format("%s is not displayed.", account));
        }
    }

    public void verifyAccountNotVisible(final String accountName) {
        getDriver()
                .scrollTo(getDocumentDeliveryScreen().getAccountsHeader(), Direction.UP, 3);
        final List<String> accounts = getDocumentDeliveryScreen().getAccounts().stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        Assert.assertFalse(accounts.contains(accountName), "Account is shown up in Document Delivery screen.");
    }

    public void navigateToDocumentDelivery() {
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();
    }
}
