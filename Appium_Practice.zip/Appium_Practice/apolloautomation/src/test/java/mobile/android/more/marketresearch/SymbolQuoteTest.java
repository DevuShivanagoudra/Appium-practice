package mobile.android.more.marketresearch;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import mobile.base.AndroidTestBase;
import mobile.common.constants.MarketResearchOptions;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
public class SymbolQuoteTest extends AndroidTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME12.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1342963: Validate when the account holder taps the “Symbol Quote” option under “Market Research”, the “Symbol Quote” slide screen should be displayed.<br>"
                            + "1342965: Validate “Symbol Quote” is selected by default in the toggle<br>"
                            + "1342967: Validate when “Symbol Quote” is selected, a search bar is displayed<br>"
                            + "1361989: Verify the account holder can search for symbols or company names in the \"Symbol Quote\" toggle",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"activity", "regression"})
    public void TestVerifySymbolQuoteScreen(final String username,
                                            final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Market Research screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.MARKETRESEARCH.toString());
        getMarketResearchScreen().waitToLoad();

        log.info("Verify Symbol Quote screen.");
        getMarketResearchScreen().tapOption(MarketResearchOptions.SYMBOLQUOTE.toString());
        getSymbolQuoteScreen().waitToLoad();
        Assert.assertTrue(getDriver().isElementSelected(getSymbolQuoteScreen().getSymbolQuoteTab()),
                "Symbol Quote tab is not selected by default.");
        Assert.assertTrue(getSymbolQuoteScreen().getSearchBar().isDisplayed(),
                "Search bar is not displayed.");
    }

    @Test(
            description =
                    "1344042: Verify App display slide screen with the symbol as title of the screen when user tap search result.<br>"
                            + "1361998: Verify the account holder should be able to clear the search (x in the search bar)<br>"
                            + "1362001: Verify the search results shall display the following information for each record that match the search criteria<br>"
                            + "1362003: Verify when there are no results, display the following copy below the search bar: 'No records matched at this time.'",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"activity", "regression"})
    public void TestVerifySymbolQuoteSearchBarResults(final String username,
                                                      final String password) {
        String companyName = "AAP";
        final String noCompany = "AAPLAAPLAAPL";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Market Research screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.MARKETRESEARCH.toString());
        getMarketResearchScreen().waitToLoad();

        log.info("Verify Search Results.");
        getMarketResearchScreen().tapOption(MarketResearchOptions.SYMBOLQUOTE.toString());
        getSymbolQuoteScreen().waitToLoad();
        getSymbolQuoteScreen().enterDataInSearchBar(noCompany);
        Assert.assertTrue(getSymbolQuoteScreen().fetchNoRecordsMessage().isDisplayed(),
                "No Records message is not displayed.");
        getSymbolQuoteScreen().tapClearSearchBar();
        getSymbolQuoteScreen().enterDataInSearchBar(companyName);
        verifySearchResultsDetail();

        log.info("Verify Company detail screen when tapped on a record.");
        companyName = "AAPL";
        getSymbolQuoteScreen().tapClearSearchBar();
        getSymbolQuoteScreen().enterDataInSearchBar(companyName);
        getSymbolQuoteScreen().tapFirstRecordInResults();
        getCompanyDetailsScreen().waitToLoad();
        Assert.assertEquals(getCompanyDetailsScreen().getTitle().getText(), companyName,
                "Company CUSIP does not match.");
    }

    private void verifySearchResultsDetail() {
        getDriver()
                .waitUntilClickable(getSymbolQuoteScreen().getLastRecord(), MAXIMUM_WAIT_TIMEOUT,
                        "Last search record is not displayed.");
        List<WebElement> recordElements = getSymbolQuoteScreen().getSearchResults();
        for (WebElement element : recordElements) {
            List<WebElement> details = CommonUtils.getChildrenUsingxPath(getDriver(), element);
            Assert.assertTrue(StringUtils.isAllUpperCase(details.get(1).getText()),
                    "CUSIP is not uppercase.");
            Assert.assertTrue(StringUtils.isAlphanumericSpace(details.get(2).getText()),
                    "Company Name is not displayed.");
            Assert.assertEquals(details.get(3).getText(), "equity",
                    "Status does not match.");
        }
    }

    @Test(
            description =
                    "1524431: Verify the search results shall display the following information for each record that match the search criteria",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"activity", "regression"})
    public void TestVerifySearchBySymbolResultsScreen(final String username, final String password) {
        String symbol = "Go";
        String companyName = "GROCERY OUTLET HOLDING CORP";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Market Research screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.MARKETRESEARCH.toString());
        getMarketResearchScreen().waitToLoad();

        log.info("Verify Symbol Quote screen.");
        getMarketResearchScreen().tapOption(MarketResearchOptions.SYMBOLQUOTE.toString());
        getSymbolQuoteScreen().waitToLoad();
        Assert.assertTrue(getDriver().isElementSelected(getSymbolQuoteScreen().getSymbolQuoteTab()),
                "Symbol Quote tab is not selected by default");
        Assert.assertTrue(getSymbolQuoteScreen().getSearchBar().isDisplayed(),
                "Search bar is not displayed.");
        log.info("Verify Search Results.");
        getMarketResearchScreen().tapOption(MarketResearchOptions.SYMBOLQUOTE.toString());
        getSymbolQuoteScreen().waitToLoad();
        getSymbolQuoteScreen().enterDataInSearchBar(symbol);
        getSymbolQuoteScreen().verifySymbolAndCompanyName(symbol, companyName);
    }
}
