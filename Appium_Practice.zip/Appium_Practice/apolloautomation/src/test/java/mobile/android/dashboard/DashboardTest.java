package mobile.android.dashboard;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


@Slf4j
public class DashboardTest extends AndroidTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description = "1191982:Verify that app displays widgets in a grid layout <br> " +
                    "1192018:Verify that app navigates back to dashboard when user tap on Done button on Customize widgets screen",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyWidgetsOnDashboard(final String username, final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);
        log.info("Verifying that app displays widgets in a grid layout.");
        getDashboardScreen().verifyWidgetsInGrid();
        log.info("Verifying that app navigates back to dashboard when user tap on Done button on Customize widgets screen.");
        getDashboardScreen().verifyWidgetsWhenDashboardCustomised();
    }
}
