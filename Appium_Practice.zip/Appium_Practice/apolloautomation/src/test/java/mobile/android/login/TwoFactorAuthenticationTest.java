package mobile.android.login;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import mobile.common.constants.Toggle;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

@Slf4j
public class TwoFactorAuthenticationTest extends AndroidTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME31.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(description = "1158532: Verify that the DEFAULT Delivery Method is set as 'Text - Mobile only'"
            + "1158527: Verify if user can select Delivery Method as PHONE ( instead of Text - Mobile Only)"
            + "1156581: Verify if user can see his Contact numbers in Phone Number drop down"
            + "1158538: Verify if user can ENABLE  “Remember me on this device” option",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"2FA", "regression"})
    public void TestVerify2FAScreen(final String username, final String password) {
        final String phoneNumber = "4289";
        final String phoneNumber2 = "9483";
        final String phoneNumber3 = "6257";
        final String defaultMethod = "Text - Mobile only";

        log.info("Sign In.");
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);
        getTwoFactorAuthenticationScreen().waitToLoad();

        log.info("Verify that the DEFAULT Delivery Method is set as 'Text - Mobile only.'");
        Assert.assertEquals(getTwoFactorAuthenticationScreen().getMethodSelectable().getText(),
                defaultMethod,
                "'Text - Mobile only' is not checked by default.");

        log.info("Verify User can see his Contact numbers in Phone Number drop down.");
        getTwoFactorAuthenticationScreen().tapPhoneNumberList();
        getTwoFactorAuthenticationScreen().waitForPhoneNumbersToLoad();
        Assert.assertTrue(getTwoFactorAuthenticationScreen().isPhoneNumberVisible(phoneNumber2));
        Assert.assertTrue(getTwoFactorAuthenticationScreen().isPhoneNumberVisible(phoneNumber3));
        getTwoFactorAuthenticationScreen().selectPhoneNumber(phoneNumber2);

        log.info(
                "Verify if user can select Delivery Method as PHONE ( instead of Text - Mobile Only).");
        log.info("Verify if user can ENABLE  “Remember me on this device” option.");
        getTwoFactorAuthenticationScreen().submit2FASecurity(phoneNumber, "Voice", Toggle.OFF);
    }

    @Test(description = "1189328: Mobile - Login - 2FA - User enters an invalid code logging with 2FA (voice delivery)"
            + "1156586: Verify if user can enter AUTH Code on Verify Your Account page",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"2FA", "regression"})
    public void TestVerifyCodeInputScreen_VoiceDelivery(final String username,
                                                        final String password) {
        final String phoneNumber = "1966";
        final String authCode = "009010";

        log.info("Sign In.");
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);

        log.info("Verify that SECURITY QUESTIONS are NOT prompted if 2FA is ENABLED");
        getTwoFactorAuthenticationScreen().waitToLoad();

        log.info("Verify User is able to send code with 'Voice' option.");
        getTwoFactorAuthenticationScreen().submit2FASecurity(phoneNumber, "Voice", Toggle.OFF);
        getCodeInputScreen().waitToLoad();

        log.info(
                "Verify error message when User enters an invalid code logging with 2FA (Voice delivery)");
        getCodeInputScreen().submitCode(authCode);
        getIncorrectVerificationCodeAlert().waitToLoad();
        Assert.assertEquals(getIncorrectVerificationCodeAlert().getTitle().getText(),
                "Wrong Verification Code");
        Assert.assertEquals(getIncorrectVerificationCodeAlert().getMessage().getText(),
                "Please enter a valid code");
    }

    @Test(description = "1189297: Mobile - Login - 2FA - User enters an invalid code logging with 2FA (text delivery)"
            + "1159621: Verify that SECURITY QUESTIONS are NOT prompted if 2FA is ENABLED",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"2FA", "regression"})
    public void TestVerifyCodeInputScreen_TextDelivery(final String username, final String password) {
        final String phoneNumber = "1966";
        final String authCode = "009010";

        log.info("Sign In.");
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);

        log.info("Verify that SECURITY QUESTIONS are NOT prompted if 2FA is ENABLED.");
        getTwoFactorAuthenticationScreen().waitToLoad();

        log.info("Verify User is able to send code via 'Text'.");
        getTwoFactorAuthenticationScreen().submit2FASecurity(phoneNumber, "Text", Toggle.OFF);
        getCodeInputScreen().waitToLoad();

        log.info(
                "Verify error message when User enters an invalid code logging with 2FA (text delivery).");
        getCodeInputScreen().submitCode(authCode);
        getIncorrectVerificationCodeAlert().waitToLoad();
        Assert.assertEquals(getIncorrectVerificationCodeAlert().getTitle().getText(),
                "Wrong Verification Code");
        Assert.assertEquals(getIncorrectVerificationCodeAlert().getMessage().getText(),
                "Please enter a valid code");
    }

    @Test(description = "1265563:Verify Trust This Device Checkbox<br>" +
            "1268918:Verify App display Text and Voice option under Method Dropdown<br>" +
            "1275683: Verify that app navigates back to login screen if user tap on back button on 2FA or security question screen<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"2FA", "regression"})
    public void TestVerifyTrustThisDeviceToggleDefaultValue_MethodValues_BackButtonIn2FA(
            final String username,
            final String password) {

        List<String> expectedMethodValues = Arrays
                .asList("Text - Mobile only", "Voice");

        log.info("Sign In.");
        getDeviceHomeScreen().launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);

        log.info("Verify that SECURITY QUESTIONS are NOT prompted if 2FA is ENABLED.");
        getTwoFactorAuthenticationScreen().waitToLoad();
        Assert.assertEquals(
                getTwoFactorAuthenticationScreen().getTrustThisDevice().getAttribute("checked"),
                "false",
                "Trust This Device button is enabled.");
        getTwoFactorAuthenticationScreen().tapOnMethodDropdown();
        Assert.assertEquals(getTwoFactorAuthenticationScreen().getMethodValues(),
                expectedMethodValues,
                "The Method values are not matched.");
        getTwoFactorAuthenticationScreen().tapTextMobileOnly();

        log.info("Verify the user is taken to Login screen on clicking back button.");
        getTwoFactorAuthenticationScreen().tapBackButton();
        Assert.assertTrue(getLoginScreen().getUsername().isDisplayed(),
                "Login screen is not Displayed.");
    }
}
