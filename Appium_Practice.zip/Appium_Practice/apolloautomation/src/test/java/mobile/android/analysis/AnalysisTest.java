package mobile.android.analysis;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import mobile.common.constants.Messages;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.TimeZone;

@Slf4j
public class AnalysisTest extends AndroidTestBase {

    static final String secretAnswer = "secret";
    static final String TIMEZONE_PACIFIC = "Canada/Pacific";
    final String viewType = "Product Type";
    final String customMonth = "AUG";
    final String customMonth2 = "DEC";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description = "1255258:Validate Description display<br>" +
                    "1255304:Validate Description text<br>" +
                    "1255312:Validate Done display on Description screen<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestToVerifyDescriptionText(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Tap on Analysis.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();

        log.info("Tap on Allocation Tab.");
        getAnalysisScreen().tapAllocation();
        getAllocationScreen().waitToLoad();

        log.info("Tap on Description link.");
        getAllocationScreen().tapDescription();
        getAllocationDescriptionScreen().waitToLoad();
        Assert
                .assertEquals(getAllocationDescriptionScreen().getDescriptionTexts(),
                        Arrays.asList(Messages.ALLOCATION_DESCRIPTION_TEXT_ANDROID.toString(),
                                Messages.ALLOCATION_DESCRIPTION_TEXT_ANDROID1.toString(),
                                Messages.ALLOCATION_DESCRIPTION_TEXT_ANDROID2.toString(),
                                Messages.ALLOCATION_DESCRIPTION_TEXT_ANDROID3.toString(),
                                Messages.ALLOCATION_DESCRIPTION_TEXT_ANDROID4.toString()),
                        "Description text is not matched.");
    }

    @Test(
            description =
                    "1211270:Verify the account holder can change the chart type to display a mountain chart from a line graph<br>"
                            + "1211275:Verify the account holder can change the chart type back to line graph from mountain chart<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestToVerifyChangingChartType(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Tap on Analysis.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();

        log.info("Tap on Chart type button.");
        getAnalysisScreen().tapChartTypeButton();
        Assert.assertEquals(getAnalysisScreen().getChartTypeButton().getAttribute("content-desc"),
                "Area Chart",
                "Mountain chart is not displayed.");
        getAnalysisScreen().tapChartTypeButton();
        Assert.assertEquals(getAnalysisScreen().getChartTypeButton().getAttribute("content-desc"),
                "Line Chart",
                "Line graph is not displayed."
        );
    }

    @Test(
            description =
                    "1249440:Verify Product Type Pie Chart is displayed below the “View” dropdown list<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestToVerifyPieChartDisplayedBelowViewDropdown(final String username,
                                                               final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Tap on Analysis.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();

        log.info("Tap on Chart type button.");
        getAnalysisScreen().tapAllocation();
        getAllocationScreen().waitToLoad();

        log.info("Verify Pie Chart Displayed under view dropdown.");
        getAllocationScreen().selectViewType(viewType);
        Assert.assertTrue(getAllocationScreen().getDoughNutChart().isDisplayed(),
                "Pie chart is not Displayed.");
    }

    @Test(
            description =
                    "1209520:Verify that the Value Over Time will display the graph with the 2 following by default<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void VerifyValueOverTimePortfolioAndAmountInvested(final String username,
                                                              final String password) {

        final String valueOverTime = "Value Over Time";
        final String marketValueGraphText = "Market Value";
        final String portfolioText = "Portfolio Value";
        final String amountInvestedText = "Amount Invested";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Tap on Analysis.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        Assert.assertEquals(getAnalysisScreen().getValueOverTime().getText(), valueOverTime,
                "Value over time text not matched.");

        Assert.assertEquals(getAnalysisScreen().getMarketValueGraph().getText(),
                marketValueGraphText,
                "Graph name not matched.");

        Assert.assertEquals(getAnalysisScreen().getPortfolioValue().getText(), portfolioText,
                "Portfolio text is not matched.");

        Assert.assertEquals(getAnalysisScreen().getAmountInvested().getText(), amountInvestedText,
                "Amount invested is not matched.");
    }

    @Test(
            description =
                    "1210247: Verify that app displays the following three options for End Date under asset growth<br>"
                            + "1248081:  End Date drop down should have three values in dropdown for selection<br>"
                            + "1210245: Verify that the app displays the following parameters for the Asset Growth<br>"
                            +
                            "1210248: Verify that app displays the following options for the Fees parameter of Asset Growth<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestVerifyDropDownAnalysisReport(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("End Date drop down should have three values in dropdown for selection.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapEndDateButton();
        Assert.assertTrue(getAnalysisScreen().getPreviousBusinessDayButton().isDisplayed(),
                "Previous Business day is not displayed.");
        Assert.assertTrue(getAnalysisScreen().getPreviousMonthEndButton().isDisplayed(),
                "Previous Month End is not displayed.");
        Assert.assertTrue(getAnalysisScreen().getCustomButton().isDisplayed(),
                "Custom is not displayed.");

        log.info(
                "Verify that app displays the following three options for End Date under asset growth.");
        getAnalysisScreen().tapBusinessDayButton();
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapAssetEndDateButton();
        Assert.assertTrue(getAnalysisScreen().getPreviousBusinessDayButton().isDisplayed(),
                "Previous Business day is not displayed.");
        Assert.assertTrue(getAnalysisScreen().getPreviousMonthEndButton().isDisplayed(),
                "Previous Month End is not displayed.");
        Assert.assertTrue(getAnalysisScreen().getCustomButton().isDisplayed(),
                "Custom is not displayed.");

        log.info("Verify that the app displays the following parameters for the Asset Growth.");
        getAnalysisScreen().tapBusinessDayButton();
        Assert.assertTrue(getAnalysisScreen().getAssetBeginDateText().isDisplayed(),
                "Asset Begin date is not displayed.");
        Assert.assertTrue(getAnalysisScreen().getAssetEndDateText().isDisplayed(),
                "Asset End date is not displayed.");
        Assert.assertTrue(getAnalysisScreen().getAssetFeesText().isDisplayed(),
                "Asset Fees is not displayed.");

        log.info(
                "Verify that app displays the following options for the Fees parameter of Asset Growth.");
        getAnalysisScreen().tapFeesButton();
        Assert.assertTrue(getAnalysisScreen().getGrossFeeButton().isDisplayed(),
                "Gross Fee Button is not displayed.");
        Assert.assertTrue(getAnalysisScreen().getNetFeeButton().isDisplayed(),
                "Net Fee Button is not displayed.");
    }

    @Test(
            description =
                    "1210249: Verify that the app displays the following options as default for the three parameters of Asset Growth<br>"
                            +
                            "1210246: Verify that the following option set to Begin Date and it will be fixed<br>"
                            +
                            "1248064: Default values for Begin Date should be Account Inception<br>" +
                            "1226663: Default value for End Date should be Previous Business Day<br>" +
                            "1248079:  Begin Date drop down should have Account Inception or Custom values<br>"
                            +
                            "1210254: Verify that app allows user to select custom date for the End date of Asset Growth<br>"
                            +
                            "1252480:Verify default values/Parameters selected in the filters under 'Asset Growth' section",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestVerifyDefaultReportAssetValues(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info(
                "Verify default values for Begin Date and End date should be Account Inception and Previous Business day.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();
        Assert.assertTrue(getAnalysisScreen().getValueOverTimeAccountInceptionText().getText()
                        .equalsIgnoreCase("Account Inception"),
                "Account Inception Text is not displayed.");
        Assert.assertTrue(getAnalysisScreen().getValueOverTimePreviousBusinessDayText().getText()
                        .equalsIgnoreCase("Previous Business Day"),
                "Previous Business Day Text is not displayed.");

        log.info("Begin Date drop down should have Account Inception or Custom values.");
        getAnalysisScreen().tapValueBeginDateButton();
        Assert.assertTrue(
                getAnalysisScreen().getValueOverTimeAccountInceptionButton().isDisplayed(),
                "Account Inception Button is not displayed.");
        Assert.assertTrue(getAnalysisScreen().getCustomButton().isDisplayed(),
                "Custom Button is not displayed.");
        getAnalysisScreen().tapValueBeginDateAccountInceptionButton();

        log.info(
                "Verify the following options as default for the three parameters of Asset Growth and following option set to Begin Date.");
        getAnalysisScreen().scrollTillAssetGrowth();
        Assert.assertTrue(getAnalysisScreen().getAssetAccountInceptionText().getText()
                        .equalsIgnoreCase("Account Inception"),
                "Account Inception Text is not displayed.");
        Assert.assertTrue(getAnalysisScreen().getAssetPreviousBusinessDayText().getText()
                        .equalsIgnoreCase("Previous Business Day"),
                "Previous Business Day Text is not displayed.");
        Assert.assertTrue(
                getAnalysisScreen().getAssetNetFeesText().getText().equalsIgnoreCase("Net of Fees"),
                "Net of fees Text is not displayed.");

        log.info(
                "Verify that app allows user to select custom date for the End date of Asset Growth.");
        getAnalysisScreen().tapAssetEndDateButton();
        getAnalysisScreen().tapCustomButton();
        final String year = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(1)
                .format(DateTimeFormatter.ofPattern("YYYY"));
        getAnalysisScreen().selectCustomDate(year, customMonth);
        getAnalysisScreen().tapCustomOKButton();
        Assert.assertEquals(
                getAnalysisScreen().getAssetEndDateLabel().getText().toLowerCase(),
                String.format("%s %s", customMonth, year).toLowerCase(),
                "Custom Date is not displayed.");
    }

    @Test(
            description =
                    "1252485: Verify User is able to expand/collapse the Asset Growth section<br>" +
                            "1253023: Validate End Date should not allow to enter future date" +
                            "1253020: Validate Begin Date should not allow to enter future date<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestVerifyBeginEndDates(final String username, final String password) {

        String year = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).plusYears(1)
                .format(DateTimeFormatter.ofPattern("YYYY"));
        String month = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId())
                .format(DateTimeFormatter.ofPattern("MMM"));
        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info(
                "Validate End Date for value over time and asset growth should not allow to enter future date.");
        getTabBar().tap(TabBarOption.ANALYSIS);
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().selectValueOverEndDate("Custom");
        Assert.assertFalse(getAnalysisScreen().isFutureDateAvailable(year, month),
                "Value over time End future date is selected.");
        getAnalysisScreen().tapCustomCancelButton();
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().scrollTillAssetGrowth();
        getAnalysisScreen().selectAssetGrowthEndDate("Custom");
        Assert.assertFalse(getAnalysisScreen().isFutureDateAvailable(year, month),
                "Asset Growth End future date is selected.");
        getAnalysisScreen().tapCustomCancelButton();

        log.info("Verify User is able to expand/collapse the Asset Growth section.");
        getAnalysisScreen().tapAssetExpandCollapseIcon();
        Assert.assertTrue(getAnalysisScreen().getAssetGrowthExpandCollapse().isEnabled(),
                "Asset Growth is not collapsable.");
        getAnalysisScreen().tapAssetExpandCollapseIcon();
        Assert.assertTrue(getAnalysisScreen().getAssetGrowthExpandCollapse().isEnabled(),
                "Asset Growth is not expandable.");

        log.info("Validate Begin Date for value over time should not allow to enter future date.");
        getAnalysisScreen().scrollTillValueOverTime();
        getAnalysisScreen().selectBeginDate("Custom");
        Assert.assertFalse(getAnalysisScreen().isFutureDateAvailable(year, month),
                "Value over time Begin future date is selected.");
        getAnalysisScreen().tapCustomCancelButton();
    }

    @Test(
            description = "1253030: Validate if the account holder cancels the updates, the previous Month and Year will be displayed in the parameters field.<br>",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"analysis", "regression"})
    public void TestProductTypeAllocation(final String username, final String password) {

        final String year = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(1)
                .format(DateTimeFormatter.ofPattern("YYYY"));
        final String month = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusMonths(2)
                .format(DateTimeFormatter.ofPattern("MMM"));

        log.info("Sign In.");
        login(username, password, secretAnswer);
        log.info(
                "Validate if the account holder cancels the updates, the previous Month and Year will be displayed in the parameters field.");
        getTabBar().tap(TabBarOption.ANALYSIS);
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().selectCustomBeginDate(year, month);
        getAnalysisScreen().waitToLoad();
        Assert.assertTrue(
                getAnalysisScreen().getValueOverTimeBegindateSelectedOption().getText().contains(month),
                "Custom Begin Date is not displayed.");
        getAnalysisScreen().selectBeginDate("Custom");
        getAnalysisScreen().selectCustomDate(year, month);
        getAnalysisScreen().tapCustomCancelButton();
        Assert.assertTrue(
                getAnalysisScreen().getValueOverTimeBegindateSelectedOption().getText().contains(month),
                "Custom Begin Date is not displayed.");
    }

    @Test(
            description = "1249305:Validate list of filter should be display in filter section <br>" +
                    "1249301:Validate applied filter shown on header <br>" +
                    "1249338:Validate selected filter number should display on header <br>" +
                    "1249343:Validate \"All Accounts\" pill should display when user selects every account <br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestToVerifyListOfFilters(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Tap on Analysis.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();
        log.info("Validating Filter by Number of Accounts.");
        getAnalysisScreen().validateFiltersAppliedByNumberOfAccounts();
        log.info("Validating Filters List.");
        getAnalysisScreen().validateFilterList();
        log.info("Validating Filter By Account Name.");
        getAnalysisScreen().validateFilterByAccountName();
        log.info("Validating Account Filter Pill.");
        getAnalysisScreen().validateAllAccountsFilterPill();
    }

    @Test(
            description = "1252470:Verify display only fields under each sub section in the data table <br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestToVerifyFieldsForAssetGrowthInReportsTab(final String username, final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);
        log.info("Tap on Analysis.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        log.info("Validating Headers in Report tab.");
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().verifyFieldsInReportsTab();
    }

    @Test(description = "1253941:Verify App Display Product Type Table when Account Holder select Product Type as View <br>", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestToVerifyFieldsForProductTypeInAllocationType(final String username, final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);
        log.info("Tap on Analysis.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        log.info("Validating Headers in Allocation tab.");
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().verifyFieldsInAllocationTab();
    }
}
