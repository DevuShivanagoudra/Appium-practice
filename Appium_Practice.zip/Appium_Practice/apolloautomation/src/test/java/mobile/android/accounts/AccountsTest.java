package mobile.android.accounts;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import mobile.common.constants.ErrorMessages;
import mobile.common.constants.ExternalAccounts;
import mobile.common.constants.TabBarOption;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class AccountsTest extends AndroidTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "customerwithnoliabilities")
    public Object[][] customerwithnoliabilities() {
        return new Object[][]{
                {Accounts.USERNAME_NO_LIABILITIES.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "ckgcustomer")
    public Object[][] ckgcustomer() {
        return new Object[][]{
                {Accounts.CKGUSER.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description = "1176346: Verify User is able to cancel changes made to account name"
                    + "1176333: Verify User is able to edit Account name for RJ account", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyEditAccountName(final String username, final String password) {
        String accountname;
        final String account_2Char = "rj";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Edit Account name and Cancel changes.");
        final String firstAccount = getAccountsScreen().getFirstAccount().getText();
        getAccountsScreen().selectAccount(firstAccount);
        getAccountDetailScreen().waitToLoad();
        accountname = getAccountDetailScreen().getTitle().getText();
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        final String newName = account_2Char;
        getAccountDetailScreen().editAccountName(newName);
        getAccountDetailScreen().tapCancel();
        getAccountDetailScreen().waitToLoad();
        Assert.assertEquals(getAccountDetailScreen().getTitle().getText(), accountname);

        log.info("Edit Account name and verify changes.");
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        getAccountDetailScreen().editAccountName(newName);
        getAccountDetailScreen().tapSave();
        getAccountDetailScreen().waitToLoad();
        Assert.assertEquals(getAccountDetailScreen().getTitle().getText(), newName);
    }

    @Test(
            description = "1177524: Verify User is able to edit Account name by entering 60 characters for RJ account"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyEditAccountNameWith60Characters(final String username,
                                                          final String password) {
        String accountname;
        final String longName = RandomStringUtils.randomAlphabetic(60);

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Edit Account name with 60 characters and Cancel changes.");
        final String firstAccount = getAccountsScreen().getFirstAccount().getText();
        getAccountsScreen().selectAccount(firstAccount);
        getAccountDetailScreen().waitToLoad();
        accountname = getAccountDetailScreen().getTitle().getText();
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        final String newName = longName;
        getAccountDetailScreen().editAccountName(newName);
        getAccountDetailScreen().tapCancel();
        getAccountDetailScreen().waitToLoad();
        Assert.assertEquals(getAccountDetailScreen().getTitle().getText(), accountname);

        log.info("Edit Account name and verify changes.");
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        getAccountDetailScreen().editAccountName(newName);
        getAccountDetailScreen().tapSave();
        getAccountDetailScreen().waitToLoad();
        Assert.assertEquals(getAccountDetailScreen().getTitle().getText(), newName);
    }

    @Test(
            description =
                    "1176335: Verify User is shown error message when entered invalid characters in account name field"
                            + "1177513: Verify User is shown error message while editing, when entered more than 60 characters in account name", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyEditAccountNameWithInvalidCharacters(final String username,
                                                               final String password) {
        String accountname;
        final String accountname_InvalidChars = "rj*-";
        final String accountname_MoreThan60Chars = RandomStringUtils.randomAlphabetic(60) + "r";
        String invalidText = ErrorMessages.ACCOUNTNAME_INVALIDTEXT.toString();

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Edit Account name with invalid chars and verify error message.");
        final String firstAccount = getAccountsScreen().getFirstAccount().getText();
        getAccountsScreen().selectAccount(firstAccount);
        getAccountDetailScreen().waitToLoad();
        accountname = getAccountDetailScreen().getTitle().getText();
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        final String newName = accountname_InvalidChars;
        getAccountDetailScreen().editAccountName(newName);
        Assert.assertEquals(getAccountDetailScreen().getInvalidText().getText(), invalidText,
                "Invalid Name error not matched.");
        getAccountDetailScreen().tapCancel();
        getAccountDetailScreen().waitToLoad();
        Assert.assertEquals(getAccountDetailScreen().getTitle().getText(), accountname);

        log.info("Edit Account name and verify error message.");
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        getAccountDetailScreen().editAccountName(newName);
        Assert.assertEquals(getAccountDetailScreen().getInvalidText().getText(), invalidText,
                "Invalid Name error not matched.");
        getAccountDetailScreen().tapCancel();
        getAccountDetailScreen().waitToLoad();
        Assert.assertEquals(getAccountDetailScreen().getTitle().getText(), accountname);
    }

    @Test(
            description = "1168134: Verify the app displays correct details section for CKG accounts (Non-specific checking)"
            , dataProvider = "ckgcustomer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyAccountsSection_CKGAccount(final String username, final String password) {
        final String accountname = "Jeanette TOD xxxx2551";
        Map<String, String> accountDetails = new HashMap<>();
        accountDetails.put("accountName", accountname);
        accountDetails.put("balance", "Balance");
        accountDetails
                .put("currentBalance", "Total Cash");
        accountDetails.put("availableBalance", "Available Cash");
        accountDetails.put("interestRate", "Change Since Last Statement");
        accountDetails.put("ytdInterest", "Prior Statement");
        accountDetails.put("priorYearInterest", "Prior Year End");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Select Account and verify Account Details.");
        getAccountsScreen().tapAccount(accountname);
        getAccountDetailScreen().waitToLoad();
        verifyAccountDetails(accountDetails);
    }

    @Test(
            description = "1170562: Verify the app navigates to the Portfolio tab when user taps the Portfolio button<br>"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyAppNavigatesToPortfolioFromAccountDetailScreen(final String username,
                                                                         final String password) {

        final String accountName = "Thomas calder00g";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Select Account and verify Account Details.");
        getAccountsScreen().tapAllAccounts();
        getAccountsScreen().tapAccount(accountName);
        getAccountDetailScreen().waitToLoad();

        log.info("Verify Documents Screen on Tapping Documents icon.");
        getAccountDetailScreen().tapPortfolioIcon();
        getPortfolioScreen().waitToLoad();
    }

    @Test(
            description = "1170563: Verify the app navigates to the Documents tab when user taps the Documents button<br>"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyAppNavigatesToDocumentsFromAccountDetailScreen(final String username,
                                                                         final String password) {

        final String accountName = "Thomas calder00g";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Select Account and verify Account Details.");
        getAccountsScreen().tapAllAccounts();
        getAccountsScreen().tapAccount(accountName);
        getAccountDetailScreen().waitToLoad();

        log.info("Verify Documents Screen on Tapping Documents icon.");
        getAccountDetailScreen().tapDocumentsIcon();
        getDocumentsScreen().waitToLoad();

        //TODO:This is blocked due to BUG 1347458
    }

    @Test(
            description =
                    "1166404: Verify the app displays icon of people besides the account that has "
                            + "authorized representatives who have view-only access to the account.<br>"
                            + "1275663: Verify that app disables the Portfolio and Documents button for the "
                            + "following accounts on Account details screen."
            , dataProvider = "customerwithnoliabilities", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})

    public void TestAppNavigationForExternalAccounts(final String username,
                                                     final String password) {
        final String accountName = "Banking";
        //FIXME: These TCs are blocked by BUG 1462274.

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify app displays icon besides the account that has authorized representatives"
                + " who have view-only access to the account.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();
        getAccountsScreen().tapAllAccounts();
        Assert.assertFalse(getAccountsScreen().isInfoIconVisible(accountName),
                "Details screen shown up for External Account");
        getAccountsScreen().verifyAuthorizedRepresentativeVisible(accountName);

        log.info("Verify app disables Portfolio and Documents for specific accounts.");
        Assert.assertFalse(getAccountsScreen().isInfoIconVisible(
                        ExternalAccounts.ACCOUNT_NAMES1.toString()),
                "Details screen shown up for External Account");
        Assert.assertFalse(getAccountsScreen().isInfoIconVisible(
                        ExternalAccounts.ACCOUNT_NAMES2.toString()),
                "Details screen shown up for External Account");
        getAccountsScreen().selectAccount(
                ExternalAccounts.ACCOUNT_NAMES3.toString());
        getAccountDetailScreen().waitUntilBalanceDisplayed();
        verifyNavigationIcons();
    }

    private void verifyAccountDetails(final Map<String, String> accountname) {

        SoftAssert verifyAccountDetails = new SoftAssert();
        verifyAccountDetails.assertEquals(getAccountDetailScreen().getTitle().getText(),
                accountname.get("accountName"), "Title is not matching.");
        verifyAccountDetails.assertEquals(getAccountDetailScreen().getBalanceLabel().getText(),
                accountname.get("balance"), "Balance Label is not matching.");
        //verifyAccountDetails.assertTrue(getAccountDetailScreen().getBalance().isDisplayed(), "Balance value is not displayed.");
        //FIXME: Balance Value is not showing up.

        verifyAccountDetails
                .assertEquals(getAccountDetailScreen().getTotalCashLabel().getText(),
                        accountname.get("currentBalance"), "Total Cash is not matching.");
        verifyAccountDetails
                .assertTrue(getAccountDetailScreen().getTotalCashValue().isDisplayed(),
                        "Total Cash is not displayed.");

        verifyAccountDetails
                .assertEquals(getAccountDetailScreen().getAvailableCashLabel().getText(),
                        accountname.get("availableBalance"), "Balance Label is not matching.");
        verifyAccountDetails
                .assertTrue(getAccountDetailScreen().getAvailableCashValue().isDisplayed(),
                        "Available Balance value is not displayed.");

        verifyAccountDetails.assertEquals(getAccountDetailScreen().getInterestRateLabel().getText(),
                accountname.get("interestRate"), "Interest Rate Label is not matching.");
        verifyAccountDetails
                .assertTrue(getAccountDetailScreen().getInterestRateValue().isDisplayed(),
                        "Interest Rate value is not displayed.");

        verifyAccountDetails
                .assertEquals(getAccountDetailScreen().getPriorStatementLabel().getText(),
                        accountname.get("ytdInterest"), "YTD Interest Label is not matching.");
        verifyAccountDetails
                .assertTrue(getAccountDetailScreen().getPriorStatementValue().isDisplayed(),
                        "YTD Interest value is not displayed.");

        verifyAccountDetails
                .assertEquals(getAccountDetailScreen().getPriorYearEndLabel().getText(),
                        accountname.get("priorYearInterest"), "Prior Year Interest Label is not matching.");
        verifyAccountDetails
                .assertTrue(getAccountDetailScreen().getPriorYearEndValue().isDisplayed(),
                        "Prior Year Interest value is not displayed.");

        verifyAccountDetails.assertAll();
    }

    private void verifyNavigationIcons() {
        SoftAssert NavigationIcons = new SoftAssert();
        NavigationIcons.assertFalse(
                getDriver().isElementClickable(getAccountDetailScreen().getPortfolioIcon()),
                "Portfolio icon is enabled.");
        NavigationIcons.assertFalse(
                getDriver().isElementClickable(getAccountDetailScreen().getDocumentsIcon()),
                "Documents icon is enabled.");
        NavigationIcons.assertAll();
    }
}
