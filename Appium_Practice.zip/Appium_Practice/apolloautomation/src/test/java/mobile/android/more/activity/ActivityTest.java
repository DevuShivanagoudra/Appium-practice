package mobile.android.more.activity;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import mobile.common.constants.Messages;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;

@Slf4j
public class ActivityTest extends AndroidTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()},
        };
    }

    @Test(
            description =
                    "1296471:Verify the app displays correct Disclosures copy<br>"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "activity", "regression"})
    public void TestVerifyDisclosuresTextInActivityScreen(final String username,
                                                          final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Activity screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.ACTIVITY.toString());
        getActivityScreen().waitToLoad();

        log.info("Verify Activity Disclosures screen.");
        getActivityScreen().tapDisclosuresLink();
        getActivityDisclosuresScreen().waitToLoad();

        log.info("Verify Disclosures Text.");
        Assert.assertEquals(
                getActivityDisclosuresScreen().getDisclosuresTexts(),
                Arrays.asList(Messages.ACTIVITY_DISCLOSURES_TEXT_ANDROID1.toString(),
                        Messages.ACTIVITY_DISCLOSURES_TEXT_ANDROID2.toString(),
                        Messages.ACTIVITY_DISCLOSURES_TEXT_ANDROID3.toString(),
                        Messages.ACTIVITY_DISCLOSURES_TEXT_ANDROID4.toString()),
                "Activity Disclosures text is not matched.");
    }

    @Test(
            description =
                    "1296713:Verify App display the record’s chevron pointing down If the Description’s copy is long<br>"
                            +
                            "1296723:Verify App display record's chevron pointing up and down icon to indicate record is expanded or collapsed<br>"
                            +
                            "1328140:Verify App display the View filter<br>" +
                            "1328145:Verify App display the default value for the “View” filter is 'All Types'<br>"
            , dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"activity", "regression"})
    public void TestVerifyChevronFunctionality(final String username,
                                               final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Activity screen.");
        getTabBar().tap(TabBarOption.ACTIVITY);
        getActivityScreen().waitToLoad();
        Assert.assertEquals(
                getActivityScreen().getPendingActivity().getAttribute("content-desc"),
                "Expandable Arrow Collapsed", "Pending activity chevron is expanded.");
        getActivityScreen().tapOnPendingActivity();
        Assert.assertEquals(
                getActivityScreen().getPendingActivity().getAttribute("content-desc"),
                "Expandable Arrow Expanded", "Pending activity chevron is collapsed.");
    }
}
