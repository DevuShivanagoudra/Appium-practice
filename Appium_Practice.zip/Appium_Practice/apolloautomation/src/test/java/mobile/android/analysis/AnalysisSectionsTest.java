package mobile.android.analysis;

import api.utils.Accounts;
import jarvis.mobile.common.constants.Direction;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import mobile.common.constants.TabBarOption;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.TimeZone;

@Slf4j
public class AnalysisSectionsTest extends AndroidTestBase {

    static final String secretAnswer = "secret";
    static final String TIMEZONE_PACIFIC = "Canada/Pacific";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1210244: Verify that app displays Asset Growth on Reports tab on Analysis<br>" +
                            "1252463: Verify there are 3 subsections under the section Asset Growth (QTD, YTD and Inception)<br>"
                            +
                            "1252900: Validate by tapping on \"Custom\" option it should give calendar picker<br>"
                            +
                            "1252457: Verify QTD end date is based on the end date selected in the filter<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestToVerifyAssetGrowthSectionAndMembers(final String username,
                                                         final String password) {

        final String endDateOption = "Previous Month End";
        final String feesOption = "Gross of Fees";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Analysis and verify Asset Growth section.");
        getTabBar().tap(TabBarOption.ANALYSIS);
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().scrollTillAssetGrowth();
        Assert.assertTrue(getAnalysisScreen().getAssetGrowthSection().isDisplayed(),
                "Asset Growth Section is not displayed.");
        getAnalysisScreen().selectAssetGrowthEndDate(endDateOption);
        getAnalysisScreen().selectFees(feesOption);

        log.info("Verify Sub sections are visible.");
        getDriver().scrollTo(getAnalysisScreen().getQuarterToDate());
        Assert.assertTrue(getAnalysisScreen().getQuarterToDate().isDisplayed(),
                "Quarter to Date section is not visible.");
        getDriver().scrollTo(getAnalysisScreen().getYearToDate());
        Assert.assertTrue(getAnalysisScreen().getYearToDate().isDisplayed(),
                "Year to Date section is not visible.");
        getDriver().scrollTo(getAnalysisScreen().getInception());
        Assert.assertTrue(getAnalysisScreen().getInception().isDisplayed(),
                "Inception section is not visible.");

        log.info("Select Custom date and verify QTD End date.");
        String year = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId())
                .format(DateTimeFormatter.ofPattern("YYYY"));
        String month = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId())
                .format(DateTimeFormatter.ofPattern("MMM"));
        getDriver()
                .scrollTo(getAnalysisScreen().getAssetGrowthSection(), Direction.DOWN_SMALL);
        getAnalysisScreen().selectAssetGrowthCustomEndDate(year, month);
        String toDate = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId())
                .with(TemporalAdjusters.lastDayOfMonth())
                .format(DateTimeFormatter.ofPattern("M/dd/YY"));
        String fromDate = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusMonths(3)
                .with(TemporalAdjusters.lastDayOfMonth())
                .format(DateTimeFormatter.ofPattern("M/dd/YY"));
        String date = String.format("%s - %s", fromDate, toDate);
        Assert.assertEquals(getAnalysisScreen().getQuarterToDateBeginEndDates().getText(), date, "Quarter To Date Begins and End Date does not match.");

        log.info("Select Custom date and verify QTD End date.");
        year = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(1)
                .format(DateTimeFormatter.ofPattern("YYYY"));
        getDriver().scrollTo(getAnalysisScreen().getAssetGrowthSection());
        getAnalysisScreen().selectAssetGrowthCustomEndDate(year, month);
        toDate = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(1)
                .with(TemporalAdjusters.lastDayOfMonth())
                .format(DateTimeFormatter.ofPattern("M/dd/YY"));
        fromDate = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(2).minusMonths(3)
                .with(TemporalAdjusters.lastDayOfMonth())
                .format(DateTimeFormatter.ofPattern("M/dd/YY"));
        date = String.format("%s - %s", fromDate, toDate);
        Assert.assertEquals(getAnalysisScreen().getQuarterToDateBeginEndDates().getText(), date, "Quarter To Date Begins and End Date does not match.");
    }

    @Test(
            description = "1252902: Validate Begin Date Format<br>" +
                    "1252906: Validate End Date Format<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "analysis", "regression"})
    public void TestToVerifyBegindateEnddate(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Analysis and verify Begin date dropdown date format.");
        String year = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(12)
                .format(DateTimeFormatter.ofPattern("YYYY"));
        String month = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId())
                .format(DateTimeFormatter.ofPattern("MMM"));
        getTabBar().tap(TabBarOption.ANALYSIS);
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().selectBeginDate("Custom");
        getAnalysisScreen().selectCustomDate(year, month);
        getAnalysisScreen().tapSelectedMonthInCalendar();
        getAnalysisScreen().tapCustomOKButton();
        getDriver()
                .waitUntilClickable(getAnalysisScreen().getValueOverTimeEndDateDropDownButton());
        Assert.assertEquals(getAnalysisScreen().getValueOverTimeBegindateSelectedOption().getText(),
                String.format("%s %s", month, year)
                , "Begin date format not matching.");
        getAnalysisScreen().tapBack();
        getMoreScreen().waitToLoad();

        log.info("Navigate to Analysis and verify End date dropdown date format.");
        year = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId()).minusYears(1)
                .format(DateTimeFormatter.ofPattern("YYYY"));
        getTabBar().tap(TabBarOption.ANALYSIS);
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().selectValueOverEndDate("Custom");
        getAnalysisScreen().selectCustomDate(year, month);
        getAnalysisScreen().tapSelectedMonthInCalendar();
        getAnalysisScreen().tapCustomOKButton();
        getDriver().waitUntilClickable(getAnalysisScreen().getEndDateButton());
        Assert.assertEquals(getAnalysisScreen().getValueOverTimeEnddateSelectedOption().getText(),
                String.format("%s %s", month, year)
                , "End date format not matching.");
    }
}
