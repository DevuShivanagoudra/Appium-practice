package mobile.android.analysis;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.AndroidTestBase;
import mobile.common.constants.TabBarOption;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

@Slf4j
public class AnalysisChipsTest extends AndroidTestBase {

    static final String secretAnswer = "secret";
    static final String TIMEZONE_PACIFIC = "Canada/Pacific";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "customerwithliabilities")
    public Object[][] customerwithliabilities() {
        return new Object[][]{
                {Accounts.USERNAME5.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1249338: Validate selected filter number should display on header<br>"
                            + "1204588: Analysis - Android: View Number of Applied Filters<br>"
                            + "1249305: Validate list of filter should be display in filter section<br>"
                            + "1249343: Validate \"All Accounts\" pill should display when user selects every account<br>"
                            + "1251992: <br>"
                            + "1252638: <br>",
            dataProvider = "customerwithliabilities",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"regression", "analysis"})
    public void TestAnalysisFilterAccountsSelection(final String username, final String password) {
        final String accountName = "Limited Liability Corp";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify All Account chip is displayed when all accounts are selected.");
        getTabBar().tap(TabBarOption.ANALYSIS);
        getAnalysisScreen().waitToLoad();
        Assert.assertEquals(getAnalysisScreen().getChips().get(0).getText(), "All Accounts",
                "All Accounts chip is not displayed.");
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().tapFilterByAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();

        log.info(
                "Verify Number of accounts gets displayed in chips.");
        //verifyAllAccountSelected();
        getAnalysisFilterScreen().selectDeselectAccount(accountName, Toggle.OFF.getBoolValue());
        getAnalysisFilterScreen().tapDone();
        getAnalysisFilterScreen().waitForFiltersToLoad();
        getAnalysisFilterScreen().tapDone();
        getAnalysisScreen().waitToLoad();
        Assert.assertEquals(getAnalysisScreen().getChips().get(0).getText(), "Accounts (6)",
                "Accounts chip with number is not displayed.");

        log.info(
                "Verify Done button gets disabled when no account is selected.");
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitForFiltersToLoad();
        getAnalysisFilterScreen().tapFilterByAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();
        deSelectAllAccounts();
        Assert.assertFalse(getPortfolioFilterScreen().getDoneButton().isEnabled(),
                "Done button enabled even with no account selected.");
    }

    private void verifyAllAccountSelected() {
        SoftAssert verifyAccounts = new SoftAssert();
        for (WebElement e : getAnalysisFilterScreen().getAccounts()) {
            verifyAccounts
                    .assertTrue(getAnalysisFilterScreen().isAccountSelectedIconVisible(e.getText()),
                            String.format("Icon for Account %s is not displayed", e.getText()));
        }
        verifyAccounts.assertAll();
    }

    private void deSelectAllAccounts() {
        for (WebElement e : getAnalysisFilterScreen().getAccounts()) {
            if (getAnalysisFilterScreen().isAccountSelectedIconVisible(e.getText())) {
                getAnalysisFilterScreen().getAccountSelectedIcon(e.getText()).click();
            }
        }
    }

}
