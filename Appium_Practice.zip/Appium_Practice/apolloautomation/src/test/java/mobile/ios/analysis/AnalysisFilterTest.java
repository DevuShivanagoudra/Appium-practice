package mobile.ios.analysis;

import api.utils.Accounts;
import jarvis.mobile.common.constants.Direction;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import mobile.base.IOSTestBase;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class AnalysisFilterTest extends IOSTestBase {

    private static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "customerwithliabilities")
    public Object[][] customerwithliabilities() {
        return new Object[][]{
                {Accounts.USERNAME5.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1207958: Verify that app displays Accounts in first section of the filter."
                            + "1207962: Verify that app displays list of account groups in alphabetic order under account section."
                            + "1207963: Verify that app displays the each account group in expanded view by default under accounts section."
                            + "1207964: Verify that app displays the following information for the accounts under account groups."
                            + "1207965: Verify the collapse/expand icon the account group under accounts section.",
            dataProvider = "customerwithliabilities", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestAnalysisFilter(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify account groups is the first section.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitToLoad();
        Assert.assertTrue(getAnalysisFilterScreen().getAccountsSection().isDisplayed(),
                "Accounts Section is not the Top section.");

        log.info("Verify account groups are in order in filter screen.");
        verifyAccountGroupHeaders();

        log.info("Verify Account groups are expanded and Account Names visible.");
        verifyAccountNames();
    }

    @Test(
            description =
                    "1207966: Verify that user can select/deselect specific account under account groups<br>"
                            + "1207967: Verify that all accounts are selected by default when user navigates to filter<br>"
                            + "1207968: Verify that app allows user to save or cancel the changes that are made in filter<br>"
                            + "1207969: Verify that app disables the save button if user not selects at least one account<br>",
            dataProvider = "customerwithliabilities", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "analysis"})
    public void TestAnalysisFilterAccountsSelection(final String username, final String password) {
        final String accountName = "Limited Liability Corp";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify account groups is the first section.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapAllAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();

        log.info(
                "Verify All accounts selected by default and user can select/deselect specific account.");
        verifyAllAccountSelected();
        getAnalysisFilterScreen().selectDeselectAccount(accountName, Toggle.OFF.getBoolValue());
        getAnalysisFilterScreen().waitToLoad();
        Assert.assertFalse(getAnalysisFilterScreen().isAccountSelectedIconVisible(accountName),
                "Account is still selected.");
        getAnalysisFilterScreen().selectDeselectAccount(accountName, Toggle.ON.getBoolValue());
        Assert.assertTrue(getAnalysisFilterScreen().isAccountSelectedIconVisible(accountName),
                "Account is still Unselected.");

        log.info("Verify user is able to save/Cancel changes.");
        getAnalysisFilterScreen().selectDeselectAccount(accountName, Toggle.OFF.getBoolValue());
        getAnalysisFilterScreen().tapBack();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapBack();
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapAllAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();
        Assert.assertTrue(getAnalysisFilterScreen().isAccountSelectedIconVisible(accountName),
                String.format("Account %s is Not selected.", accountName));
        getAnalysisFilterScreen().selectDeselectAccount(accountName, Toggle.OFF.getBoolValue());
        getAnalysisFilterScreen().tapBack();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapDone();
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapAllAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();
        Assert.assertFalse(getAnalysisFilterScreen().isAccountSelectedIconVisible(accountName),
                "Account is still selected.");

        log.info("Verify Done button enabled on deselecting all accounts.");
        deSelectAllAccounts();
        Assert.assertTrue(getAnalysisFilterScreen().getNoAccountSelectedErrorMessage()
                        .isDisplayed(),
                "Done button enabled even no account is selected.");

    }

    @Test(description =
            "1208754: Verify that closed accounts that has been selected under analysis filter will not apply to portfolio<br>"
                    + "1208747: Verify that list of accounts selected under analysis filter will applies to Portfolio and Documents<br>"
                    + "1208774: Verify closed accounts selected on Reports tab will not apply to Asset and Product type allocation tab.<br>",
            dataProvider = "customerwithliabilities", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "analysis"})

    public void TestAnalysisFilterClosedAccountsSelection(final String username,
                                                          final String password) {

        final String viewType = "Product Type";
        final List<String> accountNames = Arrays.asList("Camp IRA xxxx1716",
                "King Capital Access Joint xxxx3365", "Limited Liability Corp",
                "Joanne Steen Trust xxxx0234");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info(
                "Verify that closed accounts that has been selected under analysis filter will not apply to portfolio.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapAllAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();
        deSelectAllAccounts();
        getAnalysisFilterScreen().selectDeselectAccount(accountNames.get(0),
                Toggle.ON.getBoolValue());
        getAnalysisFilterScreen().selectDeselectAccount(accountNames.get(1),
                Toggle.ON.getBoolValue());
        getAnalysisFilterScreen().tapBack();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapDone();
        getAnalysisScreen().waitToLoad();

        log.info("Verify that closed accounts selected will not apply to Allocation tab.");
        getAnalysisScreen().tapAllocation();
        getDriver().waitUntilVisible(getAllocationScreen().getDescription());
        Assert.assertTrue(getAllocationScreen().getNoResultsMatch().isDisplayed(),
                "App displayed Asset allocations.");
        getAllocationScreen().selectViewType(viewType);
        Assert.assertTrue(getAllocationScreen().getNoResultsMatch().isDisplayed(),
                "App displayed Asset allocations.");
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapAllAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();
        verifyAllAccountNotSelected();
        getAnalysisFilterScreen().tapBack();
        getAnalysisFilterScreen().tapBack();
        getAnalysisScreen().waitToLoad();

        log.info("Verify closed accounts selected will not apply to Portfolio tab.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitForCurrentValueTabDisplayed();
        CommonUtils.scrollToElement(getDriver(), getPortfolioScreen().getNoResultsMatch(),
                Direction.UP_SMALL, 4);
        Assert.assertTrue(getDriver().isElementPresent(getPortfolioScreen().getNoResultsMatch()),
                "No Results Match message is not displayed.");
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllAccounts();
        getPortfolioFilterScreen().waitForAllAccountsToLoad();
        verifyAllAccountNotSelected();
        getPortfolioFilterScreen().tapBack();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapCancel();
        getPortfolioScreen().waitToLoad();

        log.info(
                "Verify accounts selected on Analysis tab applies to Portfolio and Documents tab.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAllocationScreen().tapReportsTab();
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapAllAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();
        deSelectAllAccounts();
        getAnalysisFilterScreen().selectDeselectAccount(accountNames.get(2),
                Toggle.ON.getBoolValue());
        getAnalysisFilterScreen().selectDeselectAccount(accountNames.get(3),
                Toggle.ON.getBoolValue());
        getAnalysisFilterScreen().tapBack();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapDone();
        getAnalysisScreen().waitToLoad();

        log.info("Verify that accounts selected on Analysis tab applies to Portfolio tab.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        Assert.assertFalse(getDriver().isElementPresent(getPortfolioScreen().getAllAccountsChip()),
                "All accounts are selected.");
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllAccounts();
        getPortfolioFilterScreen().waitForAllAccountsToLoad();
        Assert.assertTrue(getPortfolioFilterScreen().isAccountSelected(accountNames.get(2)));
        Assert.assertTrue(getPortfolioFilterScreen().isAccountSelected(accountNames.get(3)));
        getPortfolioFilterScreen().tapBack();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapCancel();
        getPortfolioScreen().waitToLoad();

        log.info("Verify that accounts selected on Analysis tab applies to Documents tab.");
        getTabBar().tap(TabBarOption.MORE);
        getAnalysisScreen().tapBack();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();
        Assert.assertFalse(getDriver().isElementPresent(getPortfolioScreen().getAllAccountsChip()),
                "All accounts are selected.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        getDocumentsFilterScreen().tapAllAccounts();
        getDocumentsFilterScreen().waitUntilAccountsLoaded();
        Assert.assertTrue(getDocumentsFilterScreen().isAccountSelected(accountNames.get(2)));
        Assert.assertTrue(getDocumentsFilterScreen().isAccountSelected(accountNames.get(3)));
        getDocumentsFilterScreen().tapBack();
    }

    @Test(
            description =
                    "1207961: Verify that app displays list of accounts under account group accordingly<br>"
                            + "1208743: Verify that app displays the list of accounts those are selected within the same session<br>",
            dataProvider = "customerwithliabilities", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "analysis"})
    public void TestAnalysisFilterAccountsInGroups(final String username, final String password) {
        List<String> accountNames = Arrays
                .asList("Barbara King IRA", "Bill Camp IRA", "Chapman Craig new1", "Joanne Steen Trust",
                        "Limited Liability Corp",
                        "Camp IRA", "King Capital Access Joint");
        final List<String> accountName = Arrays.asList("Limited Liability Corp",
                "Joanne Steen Trust xxxx0234");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify account groups is the first section.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapAllAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();
        Assert.assertTrue(getAnalysisFilterScreen().getAccountsSection().isDisplayed(),
                "Accounts Section is not the Top section.");

        log.info("Verify Account groups and Account Names visible.");
        Assert.assertEquals(getAnalysisFilterScreen().getAccountNames(), accountNames,
                "Accounts not matched.");

        log.info(
                "Verify that app displays the list of accounts those are selected within the same session.");
        deSelectAllAccounts();
        getAnalysisFilterScreen().selectDeselectAccount(accountName.get(0),
                Toggle.ON.getBoolValue());
        getAnalysisFilterScreen().selectDeselectAccount(accountName.get(1),
                Toggle.ON.getBoolValue());
        getAnalysisFilterScreen().tapBack();
        getAnalysisFilterScreen().tapDone();
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapAllAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();
        Assert.assertTrue(getPortfolioFilterScreen().isAccountSelected(accountName.get(0)));
        Assert.assertTrue(getPortfolioFilterScreen().isAccountSelected(accountName.get(1)));
        tearDownApp();

        log.info("Verify all accounts are selected on Analysis tab.");
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().tapMoreOption(MoreOptions.ANALYSIS.toString());
        getAnalysisScreen().waitToLoad();
        getAnalysisScreen().tapFilter();
        getAnalysisFilterScreen().waitToLoad();
        getAnalysisFilterScreen().tapAllAccounts();
        getAnalysisFilterScreen().waitUntilAccountsLoaded();
        verifyAllAccountSelected();
    }

    private void verifyAccountGroupHeaders() {
        List<String> accountGroups = getAnalysisFilterScreen().getAccountGroups()
                .stream().map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
        final List<String> accountGroupsOnApp = accountGroups;
        Collections.sort(accountGroups, Comparator.reverseOrder());
        Assert.assertEquals(accountGroups, accountGroupsOnApp);
    }

    private void verifyAccountNames() {
        SoftAssert verifyAccountNames = new SoftAssert();
        List<WebElement> accounts = getAnalysisFilterScreen().getAccounts();
        verifyAccountNames.assertTrue(accounts.size() > 0, "No accounts are displayed.");
        for (WebElement e : accounts) {
            verifyAccountNames.assertTrue(e.isDisplayed(),
                    "All Accounts in group %s is not displayed.");
        }
        verifyAccountNames.assertAll();
    }

    private void verifyAllAccountSelected() {
        SoftAssert verifyAccounts = new SoftAssert();
        List<String> accounts = getAnalysisFilterScreen().getAccountsList().stream().
                map(x -> x.getAttribute("label")).collect(Collectors.toList());
        accounts.removeAll(getAnalysisFilterScreen().getAccountGroupsNames());
        verifyAccounts.assertTrue(accounts.size() > 0, "No accounts are displayed.");
        for (String account : accounts) {
            verifyAccounts
                    .assertTrue(getAnalysisFilterScreen().isAccountSelectedIconVisible(account),
                            String.format("Icon for Account %s is not displayed", account));
        }
        verifyAccounts.assertAll();
    }

    private void deSelectAllAccounts() {
        List<String> accounts = getAnalysisFilterScreen().getAccountsList().stream().
                map(x -> x.getAttribute("label")).collect(Collectors.toList());
        for (String account : accounts) {
            if (getAnalysisFilterScreen().isAccountSelectedIconVisible(account)) {
                getAnalysisFilterScreen().getAccountSelectedIcon(account).click();
            }
        }
    }

    private void verifyAllAccountNotSelected() {
        SoftAssert verifyAccounts = new SoftAssert();
        List<String> accounts = getPortfolioFilterScreen().getAccountsList().stream().
                map(x -> x.getAttribute("label")).collect(Collectors.toList());
        accounts.removeAll(getAnalysisFilterScreen().getAccountGroupsNames());
        for (String account : accounts) {
            verifyAccounts
                    .assertFalse(getPortfolioFilterScreen().isAccountSelected(account),
                            String.format("Icon for Account %s is selected", account));
        }
        verifyAccounts.assertAll();
    }
}
