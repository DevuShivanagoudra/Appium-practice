package mobile.ios.accounts;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.IOSTestBase;
import mobile.common.constants.ErrorMessages;
import mobile.common.constants.ExternalAccounts;
import mobile.common.constants.TabBarOption;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.Arrays;
import java.util.List;

import static jarvis.mobile.common.constants.Constants.MAXIMUM_WAIT_TIMEOUT;

@Slf4j
public class AccountsTest extends IOSTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "customerWithExternalLiabilitiesLifeInsurance")
    public Object[][] customerWithExternalLiabilitiesLifeInsurance() {
        return new Object[][]{
                {Accounts.USERNAME_NO_LIABILITIES.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description = "1176346: Verify User is able to cancel changes made to account name"
                    + "1176333: Verify User is able to edit Account name for RJ account",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyEditAccountName(final String username, final String password) {
        String accountname;
        final String account_2Char = String.format("1%s", RandomStringUtils.randomAlphabetic(1));

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Edit Account name and Cancel changes.");
        getAccountsScreen().tapFirstAccount();
        accountname = getAccountDetailScreen().getTitle().getText();
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        final String newName = account_2Char;
        getAccountDetailScreen().editAccountName(newName);
        getAccountDetailScreen().tapCancel();
        getAccountDetailScreen().waitToLoad();
        Assert.assertEquals(
                getDriver().waitUntilClickable(getAccountDetailScreen().getTitle()).getText(),
                accountname);

        log.info("Edit Account name and verify changes.");
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        getAccountDetailScreen().editAccountName(newName);
        getAccountDetailScreen().tapSave();
        handleAlert();
        getAccountDetailScreen().waitToLoad();
        getDriver().waitUntilCondition(
                ExpectedConditions.attributeToBe(getAccountDetailScreen().getTitle(), "label",
                        String.format("%s Details", newName)));
    }

    @Test(
            description = "1177524: Verify User is able to edit Account name by entering 60 characters for RJ account"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyEditAccountNameWith60Characters(final String username,
                                                          final String password) {
        String accountname;
        final String longName = String.format("1%s", RandomStringUtils.randomAlphabetic(59));

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Edit Account name with 60 characters and Cancel changes.");
        getAccountsScreen().tapFirstAccount();
        accountname = getAccountDetailScreen().getTitle().getAttribute("label");
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        final String newName = longName;
        getAccountDetailScreen().editAccountName(newName);
        getAccountDetailScreen().tapCancel();
        getAccountDetailScreen().waitToLoad();
        Assert.assertEquals(
                getDriver().waitUntilClickable(getAccountDetailScreen().getTitle())
                        .getAttribute("label"),
                accountname);

        log.info("Edit Account name and verify changes.");
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        getAccountDetailScreen().editAccountName(newName);
        getAccountDetailScreen().tapSave();
        handleAlert();
        getAccountDetailScreen().waitToLoad();
        getDriver().waitUntilCondition(MAXIMUM_WAIT_TIMEOUT,
                ExpectedConditions.attributeToBe(getAccountDetailScreen().getTitle(), "label",
                        String.format("%s Details", newName)), "Edited Name is not matching.");
    }

    @Test(
            description =
                    "1176335: Verify User is shown error message when entered invalid characters in account name field"
                            + "1177513: Verify User is shown error message while editing, when entered more than 60 characters in account name", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyEditAccountNameWithInvalidCharacters(final String username,
                                                               final String password) {
        String accountname;
        final String accountname_InvalidChars = "rj*-";
        final String accountname_MoreThan60Chars = String
                .format("1%s", RandomStringUtils.randomAlphabetic(60));
        String invalidText = ErrorMessages.ACCOUNTNAME_INVALIDTEXT.toString();

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Edit Account name with invalid chars and verify error message.");
        getAccountsScreen().tapFirstAccount();
        accountname = getAccountDetailScreen().getTitle().getText();
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        String newName = accountname_InvalidChars;
        getAccountDetailScreen().editAccountName(newName);
        getAccountDetailScreen().tapSave();
        Assert.assertEquals(getAccountDetailScreen().getInvalidText().getText(), invalidText,
                "Invalid Name error not matched.");
        getAccountDetailScreen().tapCancel();
        getAccountDetailScreen().waitToLoad();
        Assert.assertEquals(
                getDriver().waitUntilClickable(getAccountDetailScreen().getTitle()).getText(),
                accountname);

        log.info("Edit Account name and verify error message.");
        newName = accountname_MoreThan60Chars;
        getAccountDetailScreen().tapEdit();
        getAccountDetailScreen().waitForEditWindowToLoad();
        getAccountDetailScreen().editAccountName(newName);
        getAccountDetailScreen().tapSave();
        Assert.assertEquals(getAccountDetailScreen().getInvalidText().getText(), invalidText,
                "Invalid Name error not matched.");
        getAccountDetailScreen().tapCancel();
        getAccountDetailScreen().waitToLoad();
        Assert.assertEquals(
                getDriver().waitUntilClickable(getAccountDetailScreen().getTitle()).getText(),
                accountname);
    }

    @Test(
            description = "1170562: Verify the app navigates to the Portfolio tab when user taps the Portfolio button<br>"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyAppNavigatesToPortfolioFromAccountDetailScreen(final String username,
                                                                         final String password) {

        final String accountName = "Thomas calder00";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Select Account and verify Account Details.");
        getAccountsScreen().tapAccount(accountName);
        getAccountDetailScreen().waitToLoad();

        log.info("Verify Portfolio Screen shown on Tapping Documents icon.");
        getAccountDetailScreen().tapPortfolioIcon();
        getPortfolioScreen().waitToLoad();
    }

    @Test(
            description =
                    "1170563: Verify the app navigates to the Documents tab when user taps the Documents button<br>"
                            + "1275663: Verify that app disables the Portfolio and Documents button for the following accounts on Account details screen"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyAppNavigatesToDocumentsFromAccountDetailScreen(final String username,
                                                                         final String password) {

        final String accountName = "Thomas calder00";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Select Account and verify Account Details.");
        getAccountsScreen().tapAccount(accountName);
        getAccountDetailScreen().waitToLoad();

        log.info("Verify Documents Screen on Tapping Documents icon.");
        getAccountDetailScreen().tapDocumentsIcon();
        getDocumentsScreen().waitToLoad();
        //TODO:This is blocked due to BUG 134745
    }

    @Test(
            description =
                    "1275663: Verify that app disables the Portfolio and Documents button for the following accounts on Account details screen<br>"
                            + "1166404: Verify the app displays icon of people besides the account that has authorized representatives who have view-only access to the account"
            , dataProvider = "customerWithExternalLiabilitiesLifeInsurance", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestAppNavigationForExternalAccounts(final String username,
                                                     final String password) {

        final List<String> accountNames = Arrays.asList("Banking",
                "Investment", "Account 17");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify app displays icon besides the account that has authorized representatives"
                + " who have view-only access to the account.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();
        getAccountsScreen().tapAllAccounts();
        //TODO: On iOS 15 "Visible" Property is "False" please run on iOS 16.
        getAccountsScreen().selectAccount_External(accountNames.get(0));
        Assert.assertFalse(getAccountsScreen().isUserAbleToEditExternalAccount(accountNames.get(0)),
                "Details screen is NOT View only.");
        getAccountsScreen().verifyAuthorizedRepresentativeVisible(accountNames.get(2));

        log.info("Verify app disables Portfolio and Documents for specific accounts.");
        getAccountsScreen().selectAccount_External(
                ExternalAccounts.ACCOUNT_NAMES2.toString());
        Assert.assertFalse(getAccountsScreen()
                        .isUserAbleToEditExternalAccount(ExternalAccounts.ACCOUNT_NAMES2.toString()),
                "Details screen is NOT View only.");
        getAccountsScreen().selectAccount_External(
                ExternalAccounts.ACCOUNT_NAMES3.toString());
        getAccountsScreen().tapInfoIcon(ExternalAccounts.ACCOUNT_NAMES3.toString());
        getAccountDetailScreen().waitForExternalAccountToLoad();
        verifyNavigationIcons();
    }

    private void handleAlert() {
        getDriver().waitUntilAlertPresent();
        if (getDriver().isAlertPresent()) {
            getDriver().waitUntilVisible(getAccountsScreen().getOkButton()).click();
        }
    }

    private void verifyNavigationIcons() {
        SoftAssert NavigationIcons = new SoftAssert();
        NavigationIcons.assertFalse(getAccountDetailScreen().getPortfolioIcon().isEnabled(),
                "Portfolio button is enabled");
        NavigationIcons.assertFalse(getAccountDetailScreen().getDocumentsIcon().isEnabled(),
                "Documents button is enabled");
        NavigationIcons.assertAll();
    }
}
