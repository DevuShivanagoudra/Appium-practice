package mobile.ios.more.fundstransfer;

import api.utils.Accounts;
import jarvis.mobile.common.constants.Direction;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.ios.IOSUtils;
import mobile.base.IOSTestBase;
import mobile.common.constants.Messages;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import mobile.common.constants.TransferTypes;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class FundsTransferTest extends IOSTestBase {

    static final String TIMEZONE_PACIFIC = "Canada/Pacific";
    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME12.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "customerwithnopendingtransfers")
    public Object[][] customerwithnopendingtransfers() {
        return new Object[][]{
                {Accounts.USERNAME2.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1339768: Verify App display a successful message at the top after transaction has been submitted<br>"
                            + "1339769: Verify App display confirmation code below the successful message<br>"
                            + "1339771: Verify App display the table with following information<br>"
                            + "1339776: Verify App display the following copy below the table"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "activity", "regression"})
    public void TestVerifyTransferSummary(final String username,
                                          final String password) {
        final String fromAccount = "Bob SEP IRA xxxx9810";
        final String toAccount = "WELLS FARGO BANK NA";
        final double amount = 1.11;
        final String transferDate = ZonedDateTime.now(TimeZone.getTimeZone(TIMEZONE_PACIFIC)
                        .toZoneId()).plusDays(4)
                .format(DateTimeFormatter.ofPattern("M/DD/YYYY"));
        final Map<String, String> transferDetails = new HashMap<>();
        transferDetails.put("From", fromAccount);
        transferDetails.put("To", toAccount);
        transferDetails.put("Amount", String.format("%s%s", "$", amount));
        transferDetails.put("Date", transferDate);

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Funds Transfer screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.FUNDS_TRANSFER.toString());
        getFundsTransferScreen().waitToLoad();

        log.info("Verify User is able to make a transfer.");
        getFundsTransferScreen().tapOption(TransferTypes.NEWTRANSFER.toString());
        getNewTransferScreen().waitToLoad();
        getNewTransferScreen().tapFromSelectable();
        getNewTransferScreen().selectAccount(fromAccount);
        getNewTransferScreen().waitForTransferDateToLoad();
        getNewTransferScreen().enterAmount(amount);
        getNewTransferScreen().tapNext();
        getVerifyTransferScreen().waitToLoad();
        getVerifyTransferScreen().tapFinish();
        getTransferSummaryScreen().waitToLoad();

        log.info("Verify the summary screen.");
        Assert.assertTrue(getTransferSummaryScreen().getSuccessfulMessage().isDisplayed(),
                "Successful message is not displayed.");
        Assert.assertTrue(StringUtils
                        .isAlphanumeric(getTransferSummaryScreen().getConfirmationCodeValue().getText()),
                "Confirmation Code is not displayed.");
        verifySummaryScreen(transferDetails);
        getDriver().swipeScreen(Direction.UP);
        getDriver().swipeScreen(Direction.UP);
        Assert.assertEquals(getTransferSummaryScreen().getRaymondJamesCopy().getText(),
                Messages.FUNDSTRANSFER_SUMMARYCOPY
                        .toString(), "Funds Transfer Copy does not match.");
    }

    @Test(
            description =
                    "1337372: Verify if user can see “New Transfer”, “Pending”, “History” section under Funds Transfer<br>"
                            + "1337417: Verify that app displays the following copy when user tap on \"Why Don't I See All My Accounts\"<br>"
                            + "1337606: Verify that app displays the following type of Transactions on Pending screen<br>"
                            + "1337612: Verify that Pending Transfers and In Process Transfers are sorted by submitted date"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "activity", "regression"})
    public void TestVerifyPendingTransfer(final String username,
                                          final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Funds Transfer screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.FUNDS_TRANSFER.toString());
        getFundsTransferScreen().waitToLoad();

        log.info("Verify sub-texts of the Options.");
        Assert.assertEquals(getFundsTransferScreen().getNewTransferSubText().getText(),
                Messages.NEWTRANSFER_SUBTEXT.toString(), "New Transfer Sub-Text does not match.");
        Assert.assertEquals(getFundsTransferScreen().getPendingSubText().getText(),
                Messages.PENDING_SUBTEXT.toString(), "Pending Transfer Sub-Text does not match.");
        Assert.assertEquals(getFundsTransferScreen().getHistorySubText().getText(),
                Messages.HISTORY_SUBTEXT.toString(), "History Sub-Text does not match.");
        getFundsTransferScreen().tapOption(TransferTypes.PENDING.toString());
        getPendingTransferScreen().waitToLoad();

        log.info("Verify Record are sorted by submitted date.");
        verifyPendingTransfersOrder();

        log.info("Verify Record Types.");
        getDriver()
                .scrollTo(getPendingTransferScreen().getPendingTransferRecord(), Direction.DOWN);
        getPendingTransferScreen().selectPendingTransferRecord();
        getPendingTransferSummaryScreen().waitToLoad();
        Assert.assertEquals(getPendingTransferSummaryScreen().getStatus().getText(), "Pending",
                "Transaction type does not match.");
        getPendingTransferSummaryScreen().tapBack();
        getPendingTransferScreen().waitToLoad();
        getPendingTransferScreen().selectInProcessTransferRecord();
        getPendingTransferSummaryScreen().waitToLoad();
        Assert.assertEquals(getPendingTransferSummaryScreen().getStatus().getText(), "In Process",
                "Transaction type does not match.");
    }

    @Test(
            description =
                    "1337640: Verify that app displays the copy below the list of Pending Transactions<br>"
                            + "1337619: Verify that app displays the following information for each record under Pending transactions<br>"
                            + "1359476: Verify that app displays the copy when user tap on Disclosures on Pending transfers screen",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"activity", "regression"})
    public void TestVerifyPendingTransferRecordDetails(final String username,
                                                       final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Funds Transfer screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.FUNDS_TRANSFER.toString());
        getFundsTransferScreen().waitToLoad();

        log.info("Verify Record details and the copy.");
        getFundsTransferScreen().tapOption(TransferTypes.PENDING.toString());
        getPendingTransferScreen().waitToLoad();
        verifyPendingTransfersRecordDetail();
        getDriver().scrollTo(getPendingTransferScreen().getPendingTransfersCopy());
        Assert.assertEquals(getPendingTransferScreen().getPendingTransfersCopy().getText(),
                Messages.FUNDSTRANSFER_SUMMARYCOPY.toString(),
                "Pending Transfer copy does not match.");
        getHistoryScreen().tapDisclosuresLink();
        Assert.assertEquals(getFeatureDisclosuresScreen().getDisclosuresText().getText(),
                Messages.HISTORY_DISCLOSURES_TEXT_IOS.toString(),
                "Pending Transfer Disclosures text does not match.");
    }

    @Test(
            description =
                    "1337623: Verify that app displays the following message when there are no Pending transactions to be displayed<br>"
                            + "1345778: Verify the following message “No transfer history is available at this time” displayed under 'To' field when there are no historical fund transfers",
            dataProvider = "customerwithnopendingtransfers",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"activity", "regression"})
    public void TestVerifyPendingHistoryTransferWithNoRecords(final String username,
                                                              final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Funds Transfer screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.FUNDS_TRANSFER.toString());
        getFundsTransferScreen().waitToLoad();

        log.info("Verify Pending Transfers with no records.");
        getFundsTransferScreen().tapOption(TransferTypes.PENDING.toString());
        getPendingTransferScreen().waitToLoad();
        Assert.assertEquals(getPendingTransferScreen().getNoRecordsMessage().getText(),
                Messages.NO_PENDINGTRANSFERS_MESSAGE.toString(), "No Records Message doesn't match.");
        getPendingTransferScreen().tapClose();
        getFundsTransferScreen().waitToLoad();
        getFundsTransferScreen().tapOption(TransferTypes.HISTORY.toString());
        getHistoryScreen().waitToLoad();
        Assert.assertEquals(getHistoryScreen().getNoTransferHistoryMessage().getText(),
                Messages.NO_TRANSFERHISTORY_MESSAGE.toString(), "No Records Message doesn't match.");
    }

    @Test(
            description =
                    "1345762: Verify the History modal has the following elements by Default as said in the test case<br>"
                            + "1345766: Verify the “History” modal shall display the following information for each record as mentioned in the test case<br>"
                            + "1346988: Verify the copy In the history section of the \"Funds Transfer\" under the states<br>"
                            + "1359477: Verify that app displays the Disclosures copy on History Fund Transfer screen",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"fundstransfer", "regression"})
    public void TestVerifyHistoryScreen(final String username,
                                        final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Funds Transfer screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.FUNDS_TRANSFER.toString());
        getFundsTransferScreen().waitToLoad();

        log.info("Verify History screen Record details.");
        getFundsTransferScreen().tapOption(TransferTypes.HISTORY.toString());
        getHistoryScreen().waitToLoad();
        verifyHistoryRecordDetail();

        log.info("Verify History screen elements.");
        verifyDefaultElementsInHistoryScreen();

        log.info("Verify Copy and the link in it.");
        Assert.assertEquals(getHistoryScreen().fetchHistoryCopy(),
                Messages.HISTORY_COPY_IOS.toString(),
                "Copy in History screen does not match.)");
        getHistoryScreen().tapDisclosuresLink();
        Assert.assertEquals(getFeatureDisclosuresScreen().getDisclosuresText().getText(),
                Messages.HISTORY_DISCLOSURES_TEXT_IOS.toString(),
                "History Disclosures text does not match.");
    }

    @Test(
            description =
                    "1345765: Verify the “History” modal shall sort the records by date transferred/cancelled from latest to earliest<br>",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"fundstransfer", "regression"})
    public void TestVerifyHistoryTransferRecordsOrder(final String username,
                                                      final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Funds Transfer screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.FUNDS_TRANSFER.toString());
        getFundsTransferScreen().waitToLoad();

        log.info("Verify History screen Record details.");
        getFundsTransferScreen().tapOption(TransferTypes.HISTORY.toString());
        getHistoryScreen().waitToLoad();
        verifyHistoryTransfersOrder();
    }

    private void verifySummaryScreen(final Map<String, String> transferDetails) {
        SoftAssert summaryDetails = new SoftAssert();

        summaryDetails
                .assertEquals(getTransferSummaryScreen().getFromAccount(), transferDetails.get("From"));
        summaryDetails
                .assertEquals(getTransferSummaryScreen().getToAccount(), transferDetails.get("To"));
        summaryDetails.assertEquals(getTransferSummaryScreen().getGrossAmount(),
                transferDetails.get("Amount"));
        summaryDetails.assertEquals(getTransferSummaryScreen().getTransferDate(),
                transferDetails.get("Date"));
    }

    private void verifyPendingTransfersOrder() {
        int listEndIndex;
        List<String> recordElements = getPendingTransferScreen().getRecordDates().stream()
                .map(x -> x.getText())
                .collect(Collectors.toList());
        if (recordElements.contains("In Process Transfers")) {
            listEndIndex = recordElements.indexOf("In Process Transfers");
        } else {
            listEndIndex = recordElements.size();
        }
        List<String> pendingTransfers = recordElements
                .subList(recordElements.indexOf("Pending Transfers") + 1,
                        listEndIndex);
        List<String> pendingTransfersBeforeSort = pendingTransfers;
        Collections.sort(pendingTransfers);
        Assert.assertEquals(pendingTransfers, pendingTransfersBeforeSort);

        getDriver().scrollTo(getPendingTransferScreen().getInProcessTransferRecord());
        getDriver().swipeScreen(Direction.UP);
        List<String> inProcessTransfers = getPendingTransferScreen().getInProcessTransferDates()
                .stream()
                .map(x -> x.getText())
                .collect(Collectors.toList());
        List<String> inProcessTransfersBeforeSort = inProcessTransfers;
        Collections.sort(inProcessTransfers);
        Assert.assertEquals(inProcessTransfers, inProcessTransfersBeforeSort,
                "In- Process Transfer records are not in order.");
    }

    private void verifyHistoryTransfersOrder() {
        List<String> recordElements = getHistoryScreen().getRecordDates().stream()
                .map(x -> x.getText())
                .collect(Collectors.toList());
        List<String> historyTransfers = recordElements.subList(0, 5);
        List<String> historyTransfersBeforeSort = historyTransfers;
        Collections.sort(historyTransfers);
        Assert.assertEquals(historyTransfers, historyTransfersBeforeSort);
    }

    private void verifyPendingTransfersRecordDetail() {
        List<WebElement> recordElements = getPendingTransferScreen().getRecords();
        List<WebElement> pendingTransfers = recordElements.subList(0, 4);
        for (WebElement element : pendingTransfers) {
            List<WebElement> details = IOSUtils.getChildren(getDriver(), element);
            Assert.assertTrue(details.get(1).getText().matches(".*/.*/.*,.*:.*M.*"),
                    "Date string does not match.");
            Assert.assertTrue(StringUtils.isAlphanumericSpace(details.get(2).getText()),
                    "Name does not match.");
            Assert.assertTrue(details.get(3).getText().matches("\\$.*..*"),
                    "Money Text does not match.");
        }
    }

    private void verifyHistoryRecordDetail() {
        List<WebElement> recordElements = getHistoryScreen().getRecords();
        List<WebElement> pendingTransfers = recordElements.subList(0, 4);
        for (WebElement element : pendingTransfers) {
            List<WebElement> details = IOSUtils.getChildren(getDriver(), element);
            Assert.assertTrue(details.get(1).getText().matches(".*/.*/.*,.*:.*M.*"),
                    "Date string does not match.");
            Assert.assertTrue(StringUtils.isAlphanumericSpace(details.get(2).getText()),
                    "Name does not match.");
            Assert.assertEquals(details.get(3).getText(), "Completed",
                    "Status does not match.");
            Assert.assertTrue(details.get(4).getText().matches("\\$.*..*"),
                    "Money Text does not match.");
        }
    }

    private void verifyDefaultElementsInHistoryScreen() {
        SoftAssert verifyDefaultElements = new SoftAssert();

        verifyDefaultElements.assertTrue(getHistoryScreen().getFromDateSelectable().isDisplayed(),
                "From Date Selectable is not displayed.");
        verifyDefaultElements.assertTrue(getHistoryScreen().getToDateSelectable().isDisplayed(),
                "To Date Selectable is not displayed.");
        verifyDefaultElements.assertTrue(getHistoryScreen().getFirstRecord().isDisplayed(),
                "First record is not displayed.");
        getDriver().scrollTo(getHistoryScreen().getDisclosuresLink());
        verifyDefaultElements.assertTrue(getHistoryScreen().getHistoryCopy().isDisplayed(),
                "History Transfer copy is not displayed.");
        verifyDefaultElements.assertTrue(getHistoryScreen().getDisclosuresLink().isDisplayed(),
                "History Transfer copy is not displayed.");

        verifyDefaultElements.assertAll();
    }
}
