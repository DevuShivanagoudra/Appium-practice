package mobile.ios.login;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.IOSTestBase;
import mobile.common.constants.Toggle;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

@Slf4j
public class TwoFactorAuthenticationTest extends IOSTestBase {

    private static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME3.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1158532: Verify that the DEFAULT Delivery Method is set as 'Text - Mobile only'"
                            + "1158527: Verify if user can select Delivery Method as PHONE ( instead of Text - Mobile Only)"
                            + "1156581: Verify if user can see his Contact numbers in Phone Number drop down"
                            + "1158538: Verify if user can ENABLE  “Remember me on this device” option", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "2FA", "regression"})
    public void TestVerify2FAScreen(final String username, final String password) {
        final String phoneNumber = "2875";
        final String phoneNumber2 = "9483";
        final String phoneNumber3 = "6625";

        log.info("Sign In.");
        login(username, password);
        getTwoFactorAuthenticationScreen().waitToLoad();

        log.info("Verify that the DEFAULT Delivery Method is set as 'Text - Mobile only.'");
        Assert.assertEquals(
                getTwoFactorAuthenticationScreen().getTextMobileOnly().getAttribute("label"),
                "Text - Mobile only");

        log.info("Verify User can see his Contact numbers in Phone Number drop down.");
        getTwoFactorAuthenticationScreen().tapPhoneNumberList();
        getTwoFactorAuthenticationScreen().waitForPhoneNumbersToLoad();
        Assert.assertTrue(getTwoFactorAuthenticationScreen().isPhoneNumberVisible(phoneNumber2));
        Assert.assertTrue(getTwoFactorAuthenticationScreen().isPhoneNumberVisible(phoneNumber3));
        getTwoFactorAuthenticationScreen().selectPhoneNumber(phoneNumber);

        log.info(
                "Verify if user can select Delivery Method as PHONE ( instead of Text - Mobile Only).");
        log.info("Verify if user can ENABLE  “Remember me on this device” option.");
        getTwoFactorAuthenticationScreen().submit2FASecurity(phoneNumber, "Phone", Toggle.OFF);
    }

    @Test(
            description =
                    "1158532: Verify that the DEFAULT Delivery Method is set as 'Text - Mobile only'"
                            + "1158527: Verify if user can select Delivery Method as PHONE ( instead of Text - Mobile Only)"
                            + "1156581: Verify if user can see his Contact numbers in Phone Number drop down"
                            + "1158538: Verify if user can ENABLE  “Remember me on this device” option", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "2FA", "regression"})
    public void TestVerifyCodeInputScreen(final String username, final String password) {
        final String phoneNumber = "2875";
        final String phoneNumber2 = "9483";
        final String phoneNumber3 = "6625";

        log.info("Sign In.");
        login(username, password);
        getTwoFactorAuthenticationScreen().waitToLoad();

        log.info("Verify User can see his Contact numbers in Phone Number drop down.");
        getTwoFactorAuthenticationScreen().tapPhoneNumberList();
        getTwoFactorAuthenticationScreen().waitForPhoneNumbersToLoad();
        Assert.assertTrue(getTwoFactorAuthenticationScreen().isPhoneNumberVisible(phoneNumber2));
        Assert.assertTrue(getTwoFactorAuthenticationScreen().isPhoneNumberVisible(phoneNumber3));
        getTwoFactorAuthenticationScreen().selectPhoneNumber(phoneNumber);

        log.info(
                "Verify if user can select Delivery Method as PHONE ( instead of Text - Mobile Only).");
        log.info("Verify if user can ENABLE  “Trust this device” option.");
        getTwoFactorAuthenticationScreen().submit2FASecurity(phoneNumber, "Text", Toggle.OFF);
    }

    @Test(
            description =
                    "1189328: Mobile - Login - 2FA - User enters an invalid code logging with 2FA (voice delivery)"
                            + "1156586: Verify if user can enter AUTH Code on Verify Your Account page", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "2FA", "regression"})
    public void TestVerifyCodeInputScreen_VoiceDelivery(final String username,
                                                        final String password) {
        final String phoneNumber = "2875";
        final String authCode = "009010";

        log.info("Sign In.");
        launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);

        log.info("Verify that SECURITY QUESTIONS are NOT prompted if 2FA is ENABLED");
        getTwoFactorAuthenticationScreen().waitToLoad();

        log.info("Verify User is able to send code with 'Voice' option.");
        getTwoFactorAuthenticationScreen().tapPhoneNumberList();
        getTwoFactorAuthenticationScreen().waitForPhoneNumbersToLoad();
        getTwoFactorAuthenticationScreen().selectPhoneNumber(phoneNumber);
        getTwoFactorAuthenticationScreen().submit2FASecurity(phoneNumber, "Phone", Toggle.OFF);
        getCodeInputScreen().waitToLoad();

        log.info(
                "Verify error message when User enters an invalid code logging with 2FA (Voice delivery)");
        getCodeInputScreen().submitCode(authCode);
        Assert.assertFalse(getCodeInputScreen().getSubmitButton().isEnabled(),
                "Submit button is enabled for invalid code.");
        Assert.assertTrue(getCodeInputScreen().getErrorMessage().isDisplayed(),
                "Error message NOT displayed on entering invalid code.");
    }

    @Test(
            description =
                    "1189297: Mobile - Login - 2FA - User enters an invalid code logging with 2FA (text delivery)"
                            + "1159621: Verify that SECURITY QUESTIONS are NOT prompted if 2FA is ENABLED", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "2FA", "regression"})
    public void TestVerifyCodeInputScreen_TextDelivery(final String username,
                                                       final String password) {
        final String phoneNumber = "2875";
        final String authCode = "009010";

        log.info("Sign In.");
        launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);

        log.info("Verify that SECURITY QUESTIONS are NOT prompted if 2FA is ENABLED");
        getTwoFactorAuthenticationScreen().waitToLoad();

        log.info("Verify User is able to send code via 'Text'.");
        getTwoFactorAuthenticationScreen().tapPhoneNumberList();
        getTwoFactorAuthenticationScreen().waitForPhoneNumbersToLoad();
        getTwoFactorAuthenticationScreen().selectPhoneNumber(phoneNumber);
        getTwoFactorAuthenticationScreen().submit2FASecurity(phoneNumber, "Text", Toggle.OFF);
        getCodeInputScreen().waitToLoad();

        log.info(
                "Verify error message when User enters an invalid code logging with 2FA (text delivery)");
        getCodeInputScreen().submitCode(authCode);
        Assert.assertFalse(getCodeInputScreen().getSubmitButton().isEnabled(),
                "Submit button is enabled for invalid code.");
        Assert.assertTrue(getCodeInputScreen().getErrorMessage().isDisplayed(),
                "Error message NOT displayed on entering invalid code.");
    }

    @Test(
            description = "1265563:Verify Trust This Device Checkbox<br>" +
                    "1268918:Verify App display Text and Voice option under Method Dropdown<br>" +
                    "1275683: Verify that app navigates back to login screen if user tap on back button on 2FA or security question screen<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "2FA", "regression"})
    public void TestVerifyTrustThisDeviceToggleDefaultValue_MethodValues_BackButtonIn2FA(
            final String username,
            final String password) {

        List<String> expectedMethodValues = Arrays
                .asList("Text - Mobile only", "Phone");

        log.info("Sign In.");
        launchApp();
        getLoginScreen().waitToLoad();
        getLoginScreen().signIn(username, password);

        log.info("Verify that SECURITY QUESTIONS are NOT prompted if 2FA is ENABLED.");
        getTwoFactorAuthenticationScreen().waitToLoad();
        Assert.assertEquals(
                getTwoFactorAuthenticationScreen().getTrustThisDevice().getAttribute("value"), "0",
                "Trust This Device button is enabled.");
        getTwoFactorAuthenticationScreen().tapOnMethodDropdown();
        Assert.assertEquals(getTwoFactorAuthenticationScreen().getMethodValues(),
                expectedMethodValues,
                "The Method values are not matched.");
        getTwoFactorAuthenticationScreen().tapTextMobileOnly();

        log.info("Verify the user is taken to Login screen on clicking back button.");
        getTwoFactorAuthenticationScreen().tapBackButton();
        Assert.assertTrue(getLoginScreen().getUsername().isDisplayed(),
                "Login screen is not Displayed.");
    }
}
