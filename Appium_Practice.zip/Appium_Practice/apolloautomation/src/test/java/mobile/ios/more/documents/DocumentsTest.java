package mobile.ios.more.documents;

import api.utils.Accounts;
import jarvis.mobile.common.constants.Direction;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import mobile.base.IOSTestBase;
import mobile.common.constants.Messages;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class DocumentsTest extends IOSTestBase {

    static final String secretAnswer = "secret";
    private static final String TIMEZONE_PACIFIC = "Canada/Pacific";
    final String documentType_TaxReporting = "Tax Reporting";
    final String year = "2021";
    final String titleFilter = "Filter Documents";
    final String titleDocuments = "Documents";
    final String documentType_Statements = "Statements";
    final String yearMostRecent = "Most Recent";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1200479: Verify that app displays the following when user tap on filter on documents tab"
                            + "1201130: Verify that app displays the list of filters that has been selected on main Documents screen'"
                            + "1201130: Verify that app displays the list of filters that has been selected on main Documents screen", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsFilterHeaders(final String username, final String password) {
        List<String> documentTypes = Arrays
                .asList("Statements", "Trade Confirmations", "Tax Reporting", "Reports & Proxies",
                        "Prospectuses", "Other Correspondence");
        Map<String, String> deliveryTypes = new HashMap<>();
        deliveryTypes.put("Statements", "E-Delivery");
        deliveryTypes.put("Trade Confirmations", "E-Delivery");
        final String documentType_Statements = "Statements";

        List<String> filterChips = Arrays
                .asList("All Accounts", documentType_TaxReporting, "2021");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify Filter Screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        Assert.assertTrue(getDriver().isElementPresent(getDocumentsFilterScreen().getAllAccounts()),
                "Accounts header is not displayed.");
        CommonUtils.scrollToElement(getDriver(), getDocumentsFilterScreen().getDocumentTypeHeader(),
                Direction.UP_SMALL, 5);
        Assert.assertTrue(
                getDriver().isElementPresent(getDocumentsFilterScreen().getDocumentTypeHeader()));
        CommonUtils.scrollToElement(getDriver(), getDocumentsFilterScreen().getYearHeader(),
                Direction.UP_SMALL, 10);
        Assert.assertTrue(
                getDriver().isElementPresent(getDocumentsFilterScreen().getYearHeader()),
                "Year is not displayed.");
        verifyDocumentTypes(documentTypes);

        log.info("Select Document Type and Year and verify the Documents screen.");
        getDocumentsFilterScreen().selectDocumentType(documentType_TaxReporting);
        //TODO: Blocked by Task 1354673
        //Assert.assertTrue(getDocumentsFilterScreen().isDocumentTypeSelected(documentType_TaxReporting), String.format("%s is not selected.", documentType_TaxReporting));
        //Assert.assertFalse(getDocumentsFilterScreen().isDocumentTypeSelected(documentType_Statements), String.format("%s is selected.", documentType_Statements));
        getDocumentsFilterScreen().selectYear(year);
        getDocumentsFilterScreen().tapDone();
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getFilterChips().subList(0, 3), filterChips,
                "Filter Chips Not matched");
    }

    @Test(
            description = "1197666: Verify the app navigates to the Portfolio tab when user taps the Portfolio button",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDisclosuresInDocuments(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        log.info("Verify Documents Tab.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();
        log.info("Verify Disclosures Text in Documents screen.");
        getDocumentsScreen().tapDisclosuresLink();
        getDocumentsDisclosuresScreen().waitToLoad();
        Assert
                .assertTrue(getDocumentsDisclosuresScreen().getDisclosureText().getText().contentEquals(
                                Messages.ACTIVITY_DISCLOSURES_TEST_IOS.toString()),
                        "Disclosures text is not matched.");
    }

    @Test(
            description = "1200026:Verify that app displays the following message when there is no documents that need to be displayed",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyCopyWhenNoDocumentsAreFounds(final String username,
                                                       final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Verify copy in Documents Screen when no documents are displayed.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getNoDocumentsText().getText(),
                Messages.NO_DOCUMENTS_TEXT_iOS.toString(),
                "No documents available text is not matched.");
    }

    @Test(
            description = "1203387: Verify that app displays the following message under Not getting your email notifications?",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyNotGettingEmailNotificationsSection(final String username,
                                                              final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to More screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Verify Documents Screen.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(
                getDocumentsScreen().getNotGettingEmailNotificationsHeader().getAttribute("label"),
                Messages.NOT_GETTING_EMAIL_NOTIFICATIONS_HEADER.toString(),
                "Not getting your email Notifications Header text is not matched.");
        Assert.assertEquals(
                getDocumentsScreen().getNotGettingEmailNotificationsText().getAttribute("label"),
                String.format("%s%s%s", Messages.NOT_GETTING_EMAIL_NOTIFICATIONS_TEXT.toString(),
                        "\n",
                        Messages.NOT_GETTING_EMAIL_NOTIFICATIONS_EMAIL_IDs_IOS.toString()),
                "Not getting your email notifications text and Email IDS is not matched.");
    }

    @Test(
            description = "1200023 : Verify that app navigated back to more tab when user tap on More button",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyBackButtonFunctionalityInDocumentsScreen(final String username,
                                                                   final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to More screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Verify Documents Screen.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Tap back button and verify More screen.");
        getDocumentsScreen().tapBack();
        getMoreScreen().waitToLoad();
        Assert.assertEquals(getMoreScreen().getTitle().getAttribute("label"), "More",
                "User is not landed in More screen.");
    }

    @Test(
            description =
                    "1202360: Verify the app sorts the year options from the most recent to the least recent"
                            + "1201131: Verify that app displays the document type and date for the document that has been displayed", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsRecordDetails(final String username, final String password) {
        final String year = "2021";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify list of years displayed in order");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        verifyListOfYearsOnFilterScreen();
        getDocumentsFilterScreen().selectYear(year);
        getDocumentsFilterScreen().tapDone();
        getDocumentsScreen().waitToLoad();

        log.info("Verify record attributes");
        //FIXME: Fix after the locators are fixed "TASK 1354689"
        //VerifyDocumentsRecordDetails();
    }

    @Test(
            description =
                    "1255007:Verify Documents Filter Screen Title and icon to navigate back<br>"
                            + "1202359: Verify the app does not allow user to select multiple year options<br>", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"}, enabled = false)
    //FIXME: Blocked by Task 1354673 as selected Year/Document type doesn't have tags.
    public void TestVerifyDocumentsFilterScreenTitleAndBackButton(final String username,
                                                                  final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to More screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Navigate to Documents screen.");
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify Filter Screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        Assert.assertEquals(getDocumentsFilterScreen().getTitle().getAttribute("name"), titleFilter,
                "Document filter screen title is not matched.");
        getDocumentsFilterScreen().selectYear(year);
        verifySelectedYearOnFilterScreen(year);

        log.info("Navigate to Main Documents Screen.");
        getDocumentsFilterScreen().tapBack();
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getTitle().getAttribute("name"), titleDocuments,
                "Documents screen is not Displayed.");
    }

    @Test(
            description =
                    "1200027:Verify that app displays the following message when there is no documents that has to be displayed if user has selected any filtering option<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"documents",
            "regression"})
    public void TestVerifyNoDocumentsWhenFilterIsApplied(final String username,
                                                         final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify Filter Screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();

        log.info("Filter Screen displayed.");
        getDocumentsFilterScreen().selectDocumentType(documentType_TaxReporting);
        getDocumentsFilterScreen().tapDone();
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getNoDocumentsText().getText(),
                Messages.NO_DOCUMENTS_TEXT_iOS.toString(),
                "No Documents Available message is not displayed");
    }

    @Test(
            description =
                    "1200487: Verify that app displays list of documents of type that has been selected while filtering"
                            + "1206283: Verify the app allows user to open the document file", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsFiles(final String username, final String password) {
        final String year = "2021";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Verify all the documents shown are of type that is selected in the filter.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        getDocumentsFilterScreen().selectYear(year);
        getDocumentsFilterScreen().tapDone();
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getDocumentTypes().size(),
                getDocumentsScreen().getStatementDates().size(),
                "All the documents are not of same type.");

        log.info("Verify User is able to open the document file.");
        getDocumentsScreen().tapDocumentRecord();
        getDocumentFileScreen().waitToLoad();
        Assert.assertTrue(getDriver().isElementPresent(getDocumentFileScreen().getPageContent()),
                "Document is not opened.");
        Assert.assertTrue(getDocumentFileScreen().getTitle().isDisplayed(),
                "Document Title not displayed.");
    }

    @Test(
            description =
                    "1331028:Verify the Default filter Settings as said in the test case<br>" +
                            "1379864:Verify the Documents main screen will display the following copy when Shareholder Documents was selected for the Document Type in the filter"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "regression"})
    public void TestVerifyDocumentsDefaultFilters(final String username, final String password) {
        final String documentType = "Shareholder Documents";
        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Documents screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.DOCUMENTS.toString());
        getDocumentsScreen().waitToLoad();

        log.info("Navigate to Documents filter screen.");
        getDocumentsScreen().tapFilter();
        getDocumentsFilterScreen().waitToLoad();
        getDocumentsFilterScreen().tapAllAccounts();
        getDocumentsFilterScreen().waitUntilAccountsLoaded();
        getDocumentsFilterScreen().verifyAccountsSelected();
        getDocumentsFilterScreen().tapBack();
        getDocumentsFilterScreen().waitToLoad();
        /*FIXME: Blocked by Task 1354673 as selected Year/Document type doesn't have tags.
        Assert.assertTrue(
            getDocumentsFilterScreen().isDocumentTypeSelected(documentType_Statements),
            "Statements is not selected by Default.");
        Assert.assertTrue(
            getDocumentsFilterScreen().isYearSelected(yearMostRecent),
            "Most Recent is not selected by Default.");*/

        log.info("Select document type.");
        getDocumentsFilterScreen().selectDocumentType(documentType);
        getDocumentsFilterScreen().tapDone();
        getDocumentsScreen().waitToLoad();
        Assert.assertEquals(getDocumentsScreen().getShareHolderDocumentText().getText(),
                Messages.DOCUMENTS_SHAREHOLDER_TEXT.toString(),
                "Shareholder document text is not matched.");
    }

    private void verifyDocumentTypes(final List<String> documentTypes) {
        for (String type : documentTypes) {
            getDocumentsFilterScreen().isDocumentTypeVisible(type);
        }
    }

    private void verifyListOfYearsOnFilterScreen() {
        String zoneDateTime = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId())
                .format(DateTimeFormatter.ofPattern("YYYY"));
        getDriver().swipeScreen(Direction.UP);
        List<String> elements = getDocumentsFilterScreen().getTextElements().stream()
                .filter(WebElement::isDisplayed).map(
                        WebElement::getText).collect(
                        Collectors.toList());
        final int yearIndex = elements.indexOf(zoneDateTime);
        final List<String> years = elements.subList(yearIndex, elements.size());
        final List<String> actualYears = years;
        Collections.sort(years, Comparator.reverseOrder());
        Assert.assertEquals(actualYears, years);
    }

    private void verifySelectedYearOnFilterScreen(final String year) {
        String zoneDateTime = ZonedDateTime
                .now(TimeZone.getTimeZone(TIMEZONE_PACIFIC).toZoneId())
                .format(DateTimeFormatter.ofPattern("YYYY"));
        getDriver().swipeScreen(Direction.UP);
        List<String> elements = getDocumentsFilterScreen().getTextElements().stream()
                .filter(WebElement::isDisplayed).map(
                        WebElement::getText).collect(
                        Collectors.toList());
        final int yearIndex = elements.indexOf(zoneDateTime);
        final List<String> years = elements.subList(yearIndex, elements.size());
        years.remove(year);
        Assert.assertTrue(getDocumentsFilterScreen().isYearSelected(year),
                String.format("Year %s is not selected.", year));
        for (String deSelectedYear : years) {
            Assert.assertFalse(getDocumentsFilterScreen().isYearSelected(deSelectedYear),
                    String.format("Year %s is selected.", deSelectedYear));
        }
    }

    private void VerifyDocumentsRecordDetails() {
        //FIXME: Fix after the locators are fixed "TASK 1354689"
        final String elementTag = "**/XCUIElementTypeScrollView/**/XCUIElementTypeStaticText";
        final List<WebElement> elementsList = getDocumentsScreen().getRecordsList();
        final List<String> elementsTextList = getDocumentsScreen().getRecordsList().stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        final int lastRecord_Lastindex = elementsTextList.lastIndexOf("Statements") + 1;
        final List<WebElement> elementsSubList = elementsList.subList(0, lastRecord_Lastindex);
        for (int i = 0; i <= elementsSubList.size() / 4; i = i + 4) {
            Assert.assertTrue(StringUtils.isAlpha(elementsSubList.get(i).getText()),
                    "Doc Type Not displayed.");
            Assert.assertTrue(StringUtils.isAlpha(elementsSubList.get(i + 1).getText()),
                    "Record Name Not displayed.");
            Assert.assertTrue(StringUtils.isAlpha(elementsSubList.get(i + 2).getText()),
                    "Record Date Not displayed.");
            Assert.assertTrue(StringUtils.isAlpha(elementsSubList.get(i + 3).getText()),
                    "Record Date Not displayed.");
        }
    }
}
