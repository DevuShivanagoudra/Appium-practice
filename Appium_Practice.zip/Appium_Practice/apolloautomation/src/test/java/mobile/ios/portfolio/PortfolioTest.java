package mobile.ios.portfolio;

import api.utils.Accounts;
import jarvis.mobile.common.constants.Direction;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.IOSTestBase;
import mobile.common.constants.Messages;
import mobile.common.constants.TabBarOption;
import mobile.common.constants.Toggle;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.text.ParseException;
import java.util.*;

@Slf4j
public class PortfolioTest extends IOSTestBase {

    private static final String secretAnswer = "secret";
    final String capitalGL = "All";
    final String shortTermGL = "Short-Term";
    final String longTermGL = "Long-Term";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "customerwithliabilities")
    public Object[][] customerwithliabilities() {
        return new Object[][]{
                {Accounts.USERNAME_NO_LIABILITIES.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1205360: Verify the user can apply 'Cost Basis Gain or (Loss)' view filter option.<br>"
                            +
                            "1205359: Verify the user can apply 'Investment Gain or (Loss)' view filter option.<br>"
                            + "1205356: Verify the app displays 'Views' filter options.<br>" +
                            "1205357: Verify the default Views option."
                            + "1206986: Verify all default views.<br>"
                            + "are selected when user navigated to Portfolio tab first time.<br>" +
                            "1170562: Verify the app navigates to the Portfolio tab when user taps the \"Portfolio\" button <br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestViewSelected(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify the app navigates to the Portfolio tab when user taps the \"Portfolio\" button.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        Assert.assertTrue(getPortfolioScreen().getCurrentValueTab().isDisplayed(),
                "Current value tab is not displayed.");
        Assert.assertTrue(getPortfolioScreen().getRealizedGainLoss().isDisplayed(),
                "Realized G/L tab is not displayed.");

        log.info("Verify all default views are selected when user navigate to Portfolio.");
        verifyDefaultViews();
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllAccounts();
        getPortfolioFilterScreen().waitForAllAccountsToLoad();
        getPortfolioFilterScreen().verifyAccountsSelected();
        getPortfolioFilterScreen().tapBack();
        getPortfolioFilterScreen().tapAllSecurities();
        getPortfolioFilterScreen().waitForSecurityToggleToLoad();
        Assert.assertTrue(getPortfolioFilterScreen().getAllSecuritiesToggle().isDisplayed(),
                "All securities are not selected.");
        getPortfolioFilterScreen().tapBack();

        log.info("verify user able to select Cost Basis Gain/Loss on Portfolio' View.");
        getPortfolioFilterScreen().tapCostBasis();
        getPortfolioFilterScreen().tapDone();
        getPortfolioScreen().waitToLoad();
        Assert.assertEquals(getPortfolioScreen().getGainLossTypeText().getText(),
                "Cost Basis Gain/(Loss)",
                "Cost Basis Gain / (Loss) text is not selected.");

        log.info("verify user able to select Investment Gain/Loss on Portfolio' View.");
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapInvestmentGainLoss();
        getPortfolioFilterScreen().tapDone();
        getPortfolioScreen().waitToLoad();
        Assert.assertEquals(getPortfolioScreen().getGainLossTypeText().getText(),
                "Investment Gain/(Loss)",
                "Investment Gain / (Loss) text is not selected.");

    }

    @Test(
            description = "1206938: Verify the app displays Value Change and Gain/Loss under My "
                    + "Portfolio Views.<br>" + "1206940: Verify app displays Holdings information.<br>" +
                    "1249556: Verify app displays Gain/Loss as default for My Portfolio Holdings.<br>" +
                    "1206973: Verify that app displays the total value for My Portfolio Holdings.<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestMyPortfolioHoldings(final String username, final String password) {
        final String gainlossType = "Investment Gain/(Loss)";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify the Gain/Loss is a default view for My Portfolio Holdings.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        Assert.assertEquals(getPortfolioScreen().getGainLossTypeText().getText(), gainlossType,
                "Gain/Loss is not selected by default under My Portfolio Holdings.");

        log.info("Verify View are displayed for My Portfolio Holdings.");
        Assert.assertTrue(getPortfolioScreen().getGainLossButton().isDisplayed(),
                "Gain/Loss is  not Displayed under My Portfolio Holdings.");
        Assert.assertTrue(getPortfolioScreen().getValueChangeButton().isDisplayed(),
                "Value Change is not Displayed under My Portfolio Holdings.");
        getPortfolioScreen().tapGainLoss();

        log.info("Verify app displays Each Holdings information.");
        getDriver().swipeScreen(Direction.UP);
        Assert.assertEquals(getPortfolioScreen().getHoldingDescription().getText(),
                "ALTRIA GROUP INCORPORATED", "Holding Description is not displayed");
        Assert.assertEquals(getPortfolioScreen().getHoldingSymbol().getText(),
                "MO", "Symbol Cusip is not displayed");
        getDriver().waitUntilPresent(getPortfolioScreen().getHoldingsCurrentValue());

        log.info("Verify Total Value is displayed for My Portfolio Holdings.");
        // FIXME: Ticket 1254547: waitUntilElementVisible is now working for StaticText. will be fixed once the bug is fixed.
        getDriver().swipeScreen(Direction.UP);
        getDriver().swipeScreen(Direction.UP);
        getDriver().swipeScreen(Direction.UP);
        Assert.assertTrue(!getPortfolioScreen().getTotalHoldingsValue().getText().isEmpty(),
                "Total Value is null");
    }

    @Test(
            description =
                    "1206280: Verify that app displays 'Unrealized Gain / (Loss)' under current value "
                            + "on Portfolio tab.<br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestUnrealizedGainLoss(final String username, final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify  app displays Unrealized Gain/Loss under Current value.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().tapUnrealizedGainLoss();
        getPortfolioScreen().waitToLoad();
        //FIXME: Ticket 1354549: Unrealized Gain / (Loss) static text is not visible, should be working fine  after bug is fixed
        Assert.assertTrue(
                getDriver().isElementPresent(getPortfolioScreen().getUnrealizedGainLossText()),
                "Unrealized Gain / (Loss) is not displayed.");
    }

    @Test(
            description =
                    "1206978: Verify that app displays Holdings Information screen when user tap on one of the record(Stock)"
                            + "1206984: Verify that app displays all records in an alphabetical order when they are not grouped"
                            + "1206985: Verify the app allows user to select/deselect a specific security (Portfolio filter)",
            dataProvider = "customerwithliabilities", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestVerifySelectingfilterAndOrderOfTheRecords(final String username,
                                                              final String password) {
        List<String> cusips = Arrays.asList("AFAXX", "XAP1", "CJLXX", "VMRXX", "MMM");
        final String groupOption = "Account";
        //TODO: Script to be fixed for any of the Cusip selection.
        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("verify default view of records are ordered Alphabetically.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        verifyOrderOfRecords(cusips);

        log.info("verify Securities options can be selected.");
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllSecurities();
        getPortfolioFilterScreen().waitForSecurityToggleToLoad();
        getPortfolioFilterScreen().tapAllSecurities(Toggle.OFF);
        getPortfolioFilterScreen().tapCash();
        Assert.assertTrue(getPortfolioFilterScreen().getCashSelected().isDisplayed(),
                "Cash Security is not selected.");
        getPortfolioFilterScreen().tapCashAlternatives();
        Assert.assertTrue(getPortfolioFilterScreen().getCashAlternativesSelected().isDisplayed(),
                "Cash Alternatives security is not selected.");
        getPortfolioFilterScreen().tapBack();
        getPortfolioFilterScreen().tapDone();
        getPortfolioScreen().waitToLoad();

        log.info("Verify tapping on any record takes user to details page");
        getPortfolioScreen().tapARecord("Cash");
        getHoldingDetailsScreen().waitToLoad();
        Assert.assertEquals(getHoldingDetailsScreen().getTitle().getAttribute("label"), "Details",
                "Title is not matching.");
    }

    @Test(
            description =
                    "1206970: Verify the app expands every security group by default (Portfolio filter).<br>"
                            + "1206972: Verify the app allows user to expand/collapse the security group (Portfolio filter).<br>"
                            + "1206989: Verify the app does not apply filter when user taps the \"Cancel\" button (Portfolio filter).<br>"
                            + "1206987: Verify the app selects all available securities by default (Portfolio filter).<br>"
                            + "1206990: Verify the app cannot apply filter if user has not select any securities option (Portfolio filter).<br>"
                            + "1206964: Verify the app displays all security types based on the selected accounts (Portfolio filter). <br>"
                            + "1206971: Verify the app displays all available security names under each security group (Portfolio filter). <br> ",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestPortfolioFilter(final String username, final String password) {
        final String accountName = "William Calder IRA xxxx7969899";
        final String securityGroup = "Annuities";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify that all securities are selected by default.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllSecurities();
        getPortfolioFilterScreen().waitForSecurityToggleToLoad();
        Assert.assertTrue(getPortfolioFilterScreen().getAllSecuritiesToggle().isDisplayed(),
                "All securities are not selected.");

        log.info("Verify All Security groups are expanded by default.");
        getPortfolioFilterScreen().setAllSecurities(Toggle.OFF.getBoolValue());
        getPortfolioFilterScreen().waitForSecurityToggleToLoad();
        Assert.assertTrue(
                getPortfolioFilterScreen().getVariableAnnuitiesSecurityName().isDisplayed(),
                "Variable Annuities is not displayed.");
        getDriver().swipeScreen(Direction.UP);
        Assert.assertTrue(getPortfolioFilterScreen().getCashSecurityButton().isDisplayed(),
                "Cash security type is not displayed.");

        log.info("Verify user can expand/collapse security group.");
        getPortfolioFilterScreen().expandCollapseSecurityGroup("Annuities");
        Assert.assertFalse(getDriver().isElementPresent
                (getPortfolioFilterScreen().getVariableAnnuitiesSecurityName()));
        getPortfolioFilterScreen().expandCollapseSecurityGroup("Annuities");
        Assert.assertTrue(
                getPortfolioFilterScreen().getVariableAnnuitiesSecurityName().isDisplayed(),
                "Variable Annuities is not displayed.");

        log.info("Verify the app does not apply changes in filter if user tap on Cancel.");
        getPortfolioFilterScreen().tapBack();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllAccounts();
        getPortfolioFilterScreen().waitForAllAccountsToLoad();
        getPortfolioFilterScreen().selectDeselectAccount(accountName, Boolean.FALSE);
        getPortfolioFilterScreen().tapBack();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllSecurities();
        getPortfolioFilterScreen().waitForSecurityToggleToLoad();
        getPortfolioFilterScreen().tapCash();
        getPortfolioFilterScreen().tapBack();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapCancel();
        getPortfolioScreen().waitToLoad();
        Assert.assertTrue(getPortfolioScreen().getAllAccountsChip().isDisplayed(),
                "All Accounts are not selected.");
        Assert.assertTrue(getPortfolioScreen().getAllSecuritiesChip().isDisplayed(),
                "All Securities are not selected.");
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllAccounts();
        getPortfolioFilterScreen().waitForAllAccountsToLoad();
        getPortfolioFilterScreen().verifyAccountsSelected();
        getPortfolioFilterScreen().tapBack();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllSecurities();
        getPortfolioFilterScreen().waitForSecurityToggleToLoad();
        Assert.assertTrue(getPortfolioFilterScreen().getAllSecuritiesToggle().isDisplayed(),
                "All securities are not selected.");

        log.info("Verify app cannot apply filter if no securities are selected.");
        getPortfolioFilterScreen().setAllSecurities(Toggle.OFF.getBoolValue());
        getPortfolioFilterScreen().tapBack();
        getPortfolioFilterScreen().waitToLoad();
        Assert.assertTrue(getPortfolioFilterScreen().isSecuritiesErrorMessageVisible(),
                "All securities error message is not displayed.");

        log.info("Verify security groups displayed based on accounts selected");
        getPortfolioFilterScreen().tapAllAccounts();
        getPortfolioFilterScreen().waitForAllAccountsToLoad();
        getPortfolioFilterScreen().selectDeselectAccount(accountName, Boolean.FALSE);
        getPortfolioFilterScreen().tapBack();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().tapAllSecurities();
        getPortfolioFilterScreen().tapAllSecurities(Toggle.OFF);
        getPortfolioFilterScreen().verifySecurityGroupNotDisplayed(securityGroup);

        log.info(
                "Verify all available security names are displayed under group based on Accounts selected");
        verifySecurityNames();
    }

    @Test(
            description =
                    "1210961: Verify User is able to navigate Realized Gain/ Losses Summary Section" +
                            "1211087: Verify App should display sub sections" +
                            "1208854:Verify that app displays the following data under the current value field"
                            + "1208840:Verify that app displays totals summary under Current value tab on Portfolio"
                            + "1247497:Verify the \"Closing Date” section have the following fields \"From\" and \"To\""
            , dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class, groups = {"portfolio",
            "regression"})
    public void TestRealizedGainLoss(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Realized gain/Loss summary section is display.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().tapRealizedGainLoss();
        getPortfolioScreen().waitToLoad();
        Assert.assertTrue(getPortfolioScreen().getRealizedGainLoss().isDisplayed(),
                "Realized Gain/Loss button is not displayed.");

        //TODO: Ticket "1358811" once fixed code will be working .
        //log.info("Verify App should display sub sections.");
//        Assert.assertTrue(getPortfolioScreen().getShortTermText().isDisplayed(),
//                "Short-Term text is not displayed");
//        Assert.assertTrue(getPortfolioScreen().getLongTermText().isDisplayed(),
//                "Long-Term text is not displayed");
//        Assert.assertTrue(getPortfolioScreen().getNetGainLossText().isDisplayed(),
//                "Net Gain/Loss text is not displayed");

        log.info("Verify App display total summary under current value tab.");
        getPortfolioScreen().tapCurrentValue();
        getPortfolioScreen().waitToLoadCurrentValueScreen();
        Assert.assertEquals(getPortfolioScreen().getCurrentValueText().getText(), "Current Value",
                "Current value is not matching.");
        Assert.assertEquals(getPortfolioScreen().getDailyChangeText().getText(), "Daily Change",
                "Daily change is not matching.");
        Assert.assertEquals(getPortfolioScreen().getInvestmentGLSummaryText().getText(),
                "Investment Gain/(Loss)",
                "Investment Gain/(Loss) is not matching.");

        log.info("Verify that app displays the following data under the current value field.");
        //FIXME: TASK 1354547 element visibility not working due to this ticket.
        Assert.assertTrue(getPortfolioScreen().getCurrentValue().getText().contains("$"),
                "Current value is missing.");
        Assert.assertTrue(getPortfolioScreen().getAsOfValue().getText().contains("As of"),
                "As of value is missing.");

        log.info("Verify the Closing Date section have the following fields From and To fields.");
        getPortfolioScreen().tapRealizedGainLoss();
        getPortfolioScreen().PortfolioClosingfields();
        Assert.assertEquals(getPortfolioScreen().getClosingFromDateText().getText(), "From",
                "From field is not matching.");
        Assert.assertEquals(getPortfolioScreen().getClosingToDateText().getText(), "To",
                "To field is not matching.");
    }

    @Test(
            description =
                    "1208867: Verify that app displays the daily change amount under Daily change field<br>"
                            + "1208869: Verify that app displays Investment Gain/Loss under current value tab if account holders selects the view under filter<br>"
                            + "1208878: Verify  that app displays Cost Basis Gain/Loss info if user selects the view on Filter<br>"
                            + "1246263: Verify that app displays Views under Realized Gain / Loss under Portfolio<br>"
                            + "1275641: Verify App display Modal when Information Icon is Tapped<br>"
                            + "1275642: Verify text for Information Modal<br>"
            , dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class, groups = {"portfolio",
            "regression"})
    public void TestCurrentValueTab(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify that app displays the daily change amount under Daily change field.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().tapCurrentValue();
        getPortfolioScreen().waitToLoadCurrentValueScreen();
        Assert.assertTrue(getPortfolioScreen().getDailyChangeValue().getText().contains("$"),
                "Daily change value is missing.");

        log.info("Verify that app displays Investment Gain/Loss under current value tab.");
        Assert.assertTrue(getPortfolioScreen().getInvestmentGLValue().getText().contains("$"),
                "Investment Gain Loss value is missing.");

        log.info(
                "Verify that app displays Cost Basis Gain/Loss info if user selects the view on Filter.");
        final String viewOption = "Cost Basis Gain/(Loss)";
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        getPortfolioFilterScreen().selectGainLossType(viewOption);
        getPortfolioFilterScreen().tapDone();
        getPortfolioScreen().waitToLoadCurrentValueScreen();
        Assert.assertEquals(getPortfolioScreen().getGainLossTypeText().getText(), viewOption,
                "Cost Basis Gain or (Loss) is not matching.");

        log.info("Verify that app displays Views under Realized Gain / Loss under Portfolio");
        getPortfolioScreen().tapRealizedGainLoss();
        getPortfolioScreen().waitForRealizedGLToLoad();
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitForRealizedGLFilterToLoad();
        getPortfolioFilterScreen().selectClosingDate("2021", "1");
        getPortfolioFilterScreen().tapDone();

        log.info("Verify App display Modal when Information Icon is Tapped.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().tapCurrentValue();
        getPortfolioScreen().waitToLoadCurrentValueScreen();
        getPortfolioScreen().tapDailyChangeInfoButton();
        Assert.assertEquals(getPortfolioScreen().getDailyChangeModalText().getAttribute("label"),
                "Daily Change",
                "Daily change text is not matching.");

        log.info("Verify text for Information Modal.");
        Assert.assertEquals(getPortfolioScreen().getDailyChangeDescriptionText().getText(),
                Messages.DAILY_CHANGE_INFO_TEXT.toString(),
                "Description text is not matched.");

    }

    @Test(
            description =
                    "1246265: Verify that app displays the following options when user tap on Views below the Realized G/L under portfolio<br>"
            , dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class, groups = {"portfolio",
            "regression"})
    public void TestVerifyRealizedGLViewSelection(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info(
                "Verify that app displays the following options when user tap on Views below the Realized G/L under portfolio.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().tapRealizedGainLoss();
        getPortfolioScreen().waitForRealizedGLToLoad();
        getPortfolioScreen().selectView(capitalGL);
        getPortfolioFilterScreen().selectClosingDate("2021", "1");
        getPortfolioFilterScreen().tapDone();
        getPortfolioScreen().waitForRealizedGLToLoad();
/*        Assert.assertTrue(getPortfolioScreen().getCapitalGainLossText().isDisplayed(),
            "All Capital Gains & Losses is not displayed.");*/
        Assert.assertTrue(getPortfolioScreen().getShortTermText().isDisplayed(),
                "Short-Term Gains & Losses is not displayed.");
        Assert.assertTrue(getPortfolioScreen().getLongTermText().isDisplayed(),
                "Long-Term Gains & Losses is not displayed.");

        getPortfolioScreen().selectView(shortTermGL);
        getPortfolioFilterScreen().selectClosingDate("2021", "1");
        getPortfolioFilterScreen().tapDone();
        getPortfolioScreen().waitForRealizedGLToLoad();
        Assert.assertTrue(getPortfolioScreen().getShortTermText().isDisplayed(),
                "Short-Term Gains & Losses is not displayed.");
        getPortfolioScreen().selectView(longTermGL);
        getPortfolioFilterScreen().selectClosingDate("2021", "1");
        getPortfolioFilterScreen().tapDone();
        getPortfolioScreen().waitForRealizedGLToLoad();
        Assert.assertTrue(getPortfolioScreen().getLongTermText().isDisplayed(),
                "Long-Term Gains & Losses is not displayed.");
    }

    private void verifyOrderOfRecords(final List<String> cusips) {
        List<String> records = new ArrayList<>();
        List<String> recordsOnApp = records;
        for (String cusip : cusips) {
            records.add(getPortfolioScreen().getRecordDescription(cusip).getText());
        }
        Collections.sort(records, Comparator.reverseOrder());
        Assert.assertEquals(records, recordsOnApp, "Order of records not matching.");
    }

    private void verifySecurityNames() {
        SoftAssert verifySecurityNames = new SoftAssert();
        verifySecurityNames.assertTrue(getPortfolioFilterScreen().getCash().isDisplayed(),
                "Cash security name is not displayed");
        verifySecurityNames.assertTrue(
                getPortfolioFilterScreen().getOpenEndMutualFunds().isDisplayed(),
                "Open-End Mutual Funds is not displayed");
        verifySecurityNames.assertTrue(getPortfolioFilterScreen().getCommonShares().isDisplayed(),
                "Common Shares security name is not displayed");
        verifySecurityNames.assertAll();
    }

    private void verifyDefaultViews() {
        SoftAssert defaultViewDetails = new SoftAssert();
        defaultViewDetails.assertTrue(getPortfolioScreen().getAllAccountsChip().isDisplayed(),
                "All Accounts are not selected.");
        defaultViewDetails.assertTrue(getPortfolioScreen().getAllSecuritiesChip().isDisplayed(),
                "All Securities are not selected.");

        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().waitToLoad();
        defaultViewDetails
                .assertTrue(getPortfolioFilterScreen().isOptionSelected("Investment Gain/(Loss)"),
                        "Investment Gain / (Loss) text is not Selected.");
        defaultViewDetails
                .assertTrue(getPortfolioFilterScreen().isOptionVisible("Cost Basis Gain/(Loss)"),
                        "Gain/Loss is not displayed.");
        defaultViewDetails.assertTrue(getPortfolioFilterScreen().isOptionSelected("Default"),
                "Default GroupBy is not selected.");
        getPortfolioFilterScreen().tapCancel();
        getPortfolioScreen().waitToLoad();
        defaultViewDetails.assertAll();
    }

    @Test(description = "1206294: Verify that app displays Short term and Long term held  information under Unrealized Gain/Loss. <br>" +
            "1206296: Verify that app displays amount in following colour  for positive/Negative/Zero values under Unrealized Summary information. <br>" +
            "1206969: Verify the app displays the values under My Portfolio Holdings in the following colours depends up on positive/negative/equals to zero values. <br>" +
            "1208886: Verify the app displays the values under My Portfolio Holdings in the following colours depends up on positive/negative/equals to zero values. <br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestShortAndLongTermValuesInUnrealizedGainLoss(final String username, final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);
        log.info("Verify app displays Unrealized Gain/Loss under Current value.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        getPortfolioScreen().tapUnrealizedGainLoss();
        getPortfolioScreen().waitToLoad();
        log.info("Verify that app displays Short term and Long term held information under Unrealized Gain/Loss.");
        getPortfolioScreen().verifyNetGainLossTotal();
        log.info("Verify that app displays amount in following colour for positive/Negative/Zero values under Unrealized Summary information.");
        getPortfolioScreen().verifyColorAmountInUnrealizedSummary();
        log.info("Verify the app displays the values under My Portfolio Holdings in the following colours depends up on positive/negative/equals to zero values.");
        getPortfolioScreen().verifyColorAmountInPortfolioHoldings();
    }

    @Test(description = "1252638: Verify that app disables the Done button if user not selects at least one account. <br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestWhenNoAccountSelectedInFilterScreen(final String username, final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);
        log.info("Verify app displays Unrealized Gain/Loss under Current value.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        log.info("Verify that app disables the Done button if user not selects at least one account.");
        getPortfolioScreen().getFilterButton().click();
        getPortfolioFilterScreen().getAllAccounts().click();
        getPortfolioFilterAccountsScreen().verifyWhenNoAccountIsSelected();
    }

    @Test(description = "1206960: Verify the app displays the \"Product Types\" section with correct UI (Portfolio filter). <br>" +
            "1206821:Verify that app updates the current value to most up to date after the refresh",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestPortfolioScreenForFields(final String username, final String password) throws ParseException {
        log.info("Sign In.");
        login(username, password, secretAnswer);
        log.info("Verify app displays Unrealized Gain/Loss under Current value.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        log.info("Verify that app updates the current value to most up to date after the refresh.");
        getPortfolioScreen().verifyScreenRefresh();
        getDriver().swipeScreen(Direction.DOWN);
        getPortfolioScreen().getFilterButton().click();
        log.info("Verify the app displays the \"Product Types\" section with correct UI (Portfolio filter).");
        getPortfolioFilterScreen().verifyProductTypesFieldInPortfolioFilterScreen();
    }

    @Test(description = "1247506: Verify the Realized Gain or Loss records will be updated based on everything the account holder sold within the period set for the Closing Date. <br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestVerifyRealizedGainOrLossInFilterScreen(final String username, final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);
        log.info("Verify app displays Unrealized Gain/Loss under Current value.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        getPortfolioScreen().getRealizedGainLoss().click();
        getPortfolioScreen().tapFilterButton();
        log.info("Verify dates selected.");
        getPortfolioFilterScreen().verifyDatesSelected();
    }

    @Test(description = "1206992: Verify the app resets the filter options after user logout the account. <br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestVerifyResettingOptionInFilterScreen(final String username, final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);
        log.info("Verify app displays Unrealized Gain/Loss under Current value.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().getAllAccounts().click();
        getPortfolioFilterAccountsScreen().getAllAccountsToggleButton().click();
        getPortfolioFilterAccountsScreen().getExpandAssetsIcon().click();
        getPortfolioFilterAccountsScreen().getFirstAccountRecord().click();
        getPortfolioFilterAccountsScreen().getBackButton().click();
        getPortfolioFilterScreen().getDoneButton().click();
        log.info("Verify Filter screen when only one is selected.");
        Assert.assertTrue(getPortfolioScreen().verifyAccountsSelected(1), "Account Filter pill with one account is not present.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption("Sign Out");
        getSignOutScreen().getSignOutButton().click();
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        log.info("Verifying All Accounts filter pill should not be visible.");
        Assert.assertTrue(getPortfolioScreen().getAllAccountsChip().isDisplayed(), "All Accounts filter pill is visible.");
    }

    @Test(description = "1208879: Verify that app displays the sum of My Portfolio Holdings on totals summary based on filters and views that are selected. <br>",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "regression",
            "Portfolio"})
    public void TestVerifySumOfMyPortfolioHoldingsOnTotalsSummary(final String username, final String password) {
        log.info("Sign In.");
        login(username, password, secretAnswer);
        log.info("Verify app displays Unrealized Gain/Loss under Current value.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();
        log.info("Verify app displays the sum of My Portfolio Holdings on totals summary in case of default.");
        getPortfolioScreen().verifyHoldingsWithTotalsSummary();
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().getAllAccounts().click();
        getPortfolioFilterAccountsScreen().getAllAccountsToggleButton().click();
        getPortfolioFilterAccountsScreen().getExpandAssetsIcon().click();
        getPortfolioFilterAccountsScreen().getFirstAccountRecord().click();
        getPortfolioFilterAccountsScreen().getBackButton().click();
        getPortfolioFilterScreen().getDoneButton().click();
        log.info("Verify app displays the sum of My Portfolio Holdings on totals summary when one account is selected.");
        getPortfolioScreen().verifyHoldingsWithTotalsSummary();
        getPortfolioScreen().tapFilterButton();
        getPortfolioFilterScreen().getAllAccounts().click();
        getPortfolioFilterAccountsScreen().getFirstAccountRecord().click();
        getPortfolioFilterAccountsScreen().getSecondAccountRecord().click();
        getPortfolioFilterAccountsScreen().getBackButton().click();
        getPortfolioFilterScreen().getDoneButton().click();
        log.info("Verify app displays the sum of My Portfolio Holdings on totals summary when another account is selected from the previous step.");
        getPortfolioScreen().verifyHoldingsWithTotalsSummary();
    }
}
