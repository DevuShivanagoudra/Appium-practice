package mobile.ios.accounts;

import api.utils.Accounts;
import jarvis.mobile.common.constants.Direction;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.IOSTestBase;
import mobile.common.constants.TabBarOption;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Slf4j
public class AccountsValidationTest extends IOSTestBase {

    static final String secretAnswer = "secret";
    private static final String TIMEZONE_PACIFIC = "Canada/Pacific";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "customerwithnoliabilities")
    public Object[][] customerwithnoliabilities() {
        return new Object[][]{
                {Accounts.USERNAME_NO_LIABILITIES.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "ckgcustomer")
    public Object[][] ckgcustomer() {
        return new Object[][]{
                {Accounts.CKGUSER.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1191424: Verify the Accounts widget displays 'Balance' if the account does not have liabilities"
                            + "1176333: Verify User is able to edit Account name for RJ account"
                            + "1191979: Verify that app enables edit mode when user tap on edit icon on the dashboard", dataProvider = "customerwithnoliabilities", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"}, enabled = false)
    //Accounts widget is removed from Dashboard in UI re-Design.
    public void TestVerifyAccountWidgetWithNoLiabilities(final String username,
                                                         final String password) {
        String updatedTime = "Since yesterday";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts Widget.");
        //FIXME: Widget info not ready yet.
        /*Assert.assertEquals(getDashboardScreen().getBalanceLabel().getText(), "Balance",
            "Balance Label Not displayed for Account with No Liabilities.");*/
        Assert.assertTrue(!getDashboardScreen().getBalance().getText().isEmpty(),
                "Balance Value is not displayed");
        Assert.assertTrue(getDashboardScreen().getDateUpdated().getText().contains(updatedTime),
                "Balance not updated today.");

        log.info("Edit Dashboard.");
        getDashboardScreen().tapEdit();
        getEditDashboardScreen().waitToLoad();
        Assert.assertEquals(getEditDashboardScreen().getTitle().getText(), "Edit Dashboard",
                "Not able to edit Dashboard Screen.");
        Assert.assertTrue(getEditDashboardScreen().getWidgetCheckbox().isDisplayed(),
                "Not able to edit Dashboard Screen.");
        Assert.assertTrue(getEditDashboardScreen().getDragIcon().isDisplayed(),
                "Not able to edit Dashboard Screen.");
    }

    @Test(
            description =
                    "1191426: Verify that Account widget displays \"Net Balance\" if the account has liabilities"
                            + "1191420: Verify the displays Accounts widget at the top of the dashboard provides a summary of user account", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"}, enabled = false)
    //Accounts widget is removed from Dashboard in UI re-Design.
    public void TestVerifyAccountWidgetWithLiabilities(final String username,
                                                       final String password) {
        String updatedTime = "Since yesterday";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts Widget.");
        Assert.assertEquals(getDashboardScreen().getBalanceLabel().getText(), "Net Balance",
                "Balance Label Not displayed for Account with No Liabilities.");
        Assert.assertTrue(!getDashboardScreen().getBalance().getText().isEmpty(),
                "Balance Value is not displayed");
        Assert.assertTrue(getDashboardScreen().getDateUpdated().getText().contains(updatedTime),
                "Balance not updated today.");
    }

    @Test(
            description =
                    "1165891: Verify the app can switch between \"All Accounts\" and Raymond James Accounts\" tab"
                            + "1176332: Verify User is not able to edit Account name for External account through RJ App", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "accounts", "regression"})
    public void TestVerifyUserSwitchingAccounts(final String username,
                                                final String password) {
        final String accountName = "Banking";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Verify user able to switch between 'All Accounts' and 'Raymond James'.");
        getAccountsScreen().tapAllAccounts();
        getAccountsScreen().waitToLoad();
        getDriver().scrollTo(getAccountsScreen().getExternalAccount());
        Assert.assertTrue(getAccountsScreen().isExternalAccountVisible(),
                "External account is not displayed.");
        getAccountsScreen().tapRaymondJamesAccounts();
        getAccountsScreen().waitToLoad();
        getDriver().swipeScreen(Direction.UP);
        Assert.assertTrue(getAccountsScreen().isExternalAccountNotVisible(),
                "External account is displayed.");

        log.info("Verify user is not able to edit external account.");
        getAccountsScreen().tapAllAccounts();
        getAccountsScreen().tapExternalAccount(accountName);
        Assert.assertFalse(getAccountsScreen().isUserAbleToEditExternalAccount(accountName),
                "Details screen is NOT View only.");
    }
}
