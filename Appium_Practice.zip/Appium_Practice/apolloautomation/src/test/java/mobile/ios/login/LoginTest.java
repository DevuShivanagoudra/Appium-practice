package mobile.ios.login;

import api.utils.Accounts;
import io.appium.java_client.InteractsWithApps;
import jarvis.mobile.appium.Utils;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import mobile.base.IOSTestBase;
import mobile.common.constants.TabBarOption;
import mobile.common.constants.Toggle;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
public class LoginTest extends IOSTestBase {

    private static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description = "1155288: Verify if user is able to login with VALID Credentials ( with NO - 2FA, Security Questions, Interrupts)"
                    + "1155311: Verify on successful LOGIN, Dashboard( or Summary screen) screen is displayed",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"miorg"})
    public void TestLogin(final String username, final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts screen.");
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();
        verifyAccountsScreen();
    }

    @Test(description = "1188669: Mobile - Login - User click on show/hide Username"
            + "1154685: Verify hide username is turned on  by default when user launches the app"
            + "1154694: Verify that username is not displayed if user toggle hide username"
            + "1154687: Verify user can see username after toggle on show/hide username icon",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"login", "regression"})
    public void TestShowHideUsername(final String username, final String password) {

        log.info("Sign In.");
        launchApp();
        getLoginScreen().waitToLoad();

        log.info("Verify Username is not revealed by default.");
        getLoginScreen().fillUsername(username);
        Assert.assertEquals(getLoginScreen().getUsername().getText().length(),
                username.length(),
                "Hidden Username string doesn't match.");

        log.info("Verify Username is shown when tapped on ShowHide icon.");
        getLoginScreen().tapShowHideIconUsername();
        Assert.assertEquals(getLoginScreen().getUsername().getText(), username,
                "Username string doesn't match.");

        log.info("Verify Username gets hidden when tapped again on ShowHide icon.");
        getLoginScreen().tapShowHideIconUsername();
        Assert.assertEquals(getLoginScreen().getUsername().getText().length(),
                username.length(),
                "Hidden Username string doesn't match.");
    }

    @Test(description = "1188696: Mobile - Login - User click on show/hide Password"
            + "1156036: Verify password that entered at the time of login should be hidden by default"
            + "1156039: Verify that user can able to see the password that entered at the time of login"
            + "1156040: Verify that user can hide password that entered at the time of login ",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"login", "regression"})
    public void TestShowHidePassword(final String username, final String password) {

        log.info("Sign In.");
        launchApp();
        getLoginScreen().waitToLoad();

        log.info("Verify Username is not revealed by default.");
        getLoginScreen().fillPassword(password);
        Assert.assertEquals(getLoginScreen().getPassword().getText().length(),
                password.length(),
                "Hidden Password string doesn't match.");

        log.info("Verify Password is shown when tapped on ShowHide icon.");
        getLoginScreen().tapShowHideIconPassword();
        Assert.assertEquals(getLoginScreen().getPassword().getText(), password,
                "Password string doesn't match.");

        log.info("Verify Password gets hidden when tapped again on ShowHide icon.");
        getLoginScreen().tapShowHideIconPassword();
        Assert.assertEquals(getLoginScreen().getPassword().getText().length(),
                password.length(),
                "Hidden Username string doesn't match.");
    }

    @Test(description = "1159866: To verify if user can navigate to Forgot UserName screen"
            + "1159867: To verify if user can navigate to Forgot Password Page"
            + "1156831: Verify that user is able to open login help screen",
            dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {"login", "regression"})
    public void
    TestForgotUsernameAndPassword(final String username, final String password) {
        final String supportURL = String.format("https://clientaccess%s.rjf.com/Support",
                Utils.getProperty("appium.environment"));
        final String forgotUsernameSupportURL = String
                .format("%s%s", supportURL, "/RecoverLoginId");
        final String forgotPasswordSupportURL = String.format("%s%s", supportURL, "/Password");
        final String forgotLoginHelpSupportURL = String.format("%s%s", supportURL, "/LoginHelp");

        log.info("Sign In.");
        launchApp();
        getLoginScreen().waitToLoad();

        log.info("Verify Username support page is displayed on clicking 'Forgot Username' link.");
        getLoginScreen().tapForgotUsername();
        getDriver().clearAlert("Continue");

        getSupportWebPageScreen().waitToLoad();
        Assert.assertTrue(getSupportWebPageScreen().getRecoverUsername().isDisplayed());
        Assert.assertEquals(getSupportWebPageScreen().fetchPageURL(), forgotUsernameSupportURL);
        ((InteractsWithApps) getDriver()).terminateApp(SAFARI_BUNDLEID);
        ((InteractsWithApps) getDriver()).activateApp(CLIENTACCESS_BUNDLEID);

        log.info("Verify Username support page is displayed on clicking 'Forgot Password' link.");
        getLoginScreen().tapForgotPassword();
        getDriver().clearAlert("Continue");
        getSupportWebPageScreen().waitToLoad();
        Assert.assertTrue(getSupportWebPageScreen().getRecoverPassword().isDisplayed());
        Assert.assertEquals(getSupportWebPageScreen().fetchPageURL(), forgotPasswordSupportURL);
        ((InteractsWithApps) getDriver()).terminateApp(SAFARI_BUNDLEID);
        ((InteractsWithApps) getDriver()).activateApp(CLIENTACCESS_BUNDLEID);

        log.info("Verify Username support page is displayed on clicking 'Sign In Help' link.");
        getLoginScreen().tapSigninHelp();
        getDriver().clearAlert("Continue");
        getSupportWebPageScreen().waitForSignInHelpPageToLoad();
        Assert.assertTrue(getSupportWebPageScreen().getSignInHelpPage().isDisplayed());
        Assert.assertEquals(getSupportWebPageScreen().fetchPageURL(), forgotLoginHelpSupportURL);
        ((InteractsWithApps) getDriver()).terminateApp(SAFARI_BUNDLEID);
    }

    @Test(
            description =
                    "1154477: Verify that remember username is checked by default"
                            + "1154679: Verify username is not saved by default after logging in and logout from the account"
                            + "1154681: Verify username is not saved if user un-checks remember username checkbox"
                            + "1154680: Verify Username is SAVED and MASKED after selecting Remember Username", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "login", "regression"})
    public void TestVerifyRememberUsername(final String username, final String password) {
        final String user = "Username";

        log.info("Sign In.");
        launchApp();
        getLoginScreen().waitToLoad();

        log.info("Verify 'Remember User' is checked by default.");
        Assert.assertTrue(getLoginScreen().getRememberUserNameState(),
                "'Remember Username' is not selected by default.");

        log.info("Verify 'Remember User' is not saved by unchecking the checkbox.");
        getLoginScreen().setRememberUserName(Toggle.OFF.getBoolValue());
        getLoginScreen().signIn(username, password);
        getSecretQuestionScreen().waitToLoad();
        getSecretQuestionScreen().submitSecretAnswer(secretAnswer, Toggle.OFF);
        getDashboardScreen().waitToLoad();
        ((InteractsWithApps) getDriver()).terminateApp(CLIENTACCESS_BUNDLEID);
        ((InteractsWithApps) getDriver()).activateApp(TESTFLIGHT_BUNDLEID);
        launchApp();
        getLoginScreen().waitToLoad();
        Assert.assertEquals(getLoginScreen().getUsername().getText().length(), user.length(),
                "Username got saved even on unchecking the checkbox.");

        log.info(
                "Verify 'Remember User' is saved by checking the checkbox and is hidden on next Login.");
        getLoginScreen().setRememberUserName(Toggle.OFF.getBoolValue());
        getLoginScreen().signIn(username, password);
        getSecretQuestionScreen().waitToLoad();
        getSecretQuestionScreen().submitSecretAnswer(secretAnswer, Toggle.OFF);
        getDashboardScreen().waitToLoad();
        ((InteractsWithApps) getDriver()).terminateApp(CLIENTACCESS_BUNDLEID);
        ((InteractsWithApps) getDriver()).activateApp(TESTFLIGHT_BUNDLEID);
        launchApp();
        getLoginScreen().waitToLoad();
        Assert.assertEquals(getLoginScreen().getUsername().getText().length(),
                username.length(),
                "Username is not masked on Login Screen.");
    }

    @Test(
            description =
                    "1156182: Verify that user can able to navigate to all screens listed on tab bar"
                            + "1156132: Verify that user presented with default options on tab bar as per UI/UX design", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "login", "regression"})
    public void TestVerifyTabbar(final String username, final String password) {

        log.info("Sign In and verify user able to select 'Accounts' tabbar.");
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.ACCOUNTS);
        getAccountsScreen().waitToLoad();

        log.info("Sign In and verify user able to select 'Porfolio' tabbar.");
        getTabBar().tap(TabBarOption.PORTFOLIO);
        getPortfolioScreen().waitToLoad();

        log.info("Sign In and verify user able to select 'Analysis' tabbar.");
        getTabBar().tap(TabBarOption.ANALYSIS);
        getAnalysisScreen().waitToLoad();

        log.info("Sign In and verify user able to select 'More' tabbar.");
        //getDriver().waitUntilAlertPresent();
        if (getDriver().isAlertPresent()) {
            getDriver().clearAlert("OK");
        }
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
    }

    @Test(description =
            "1156182: Verify that user can able to navigate to all screens listed on tab bar"
                    + "1156132: Verify that user presented with default options on tab bar as per UI/UX design", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "login", "regression"}, enabled = false)
    //TODO: To be refactored after the feature is implemented.
    public void TestVerifyEditTabOrder(final String username, final String password) {
        List<String> tabbarOptions_Reorder = Arrays
                .asList("Dashboard", "Accounts", "Portfolio", "Activity");

        log.info("Sign In and navigate to 'More' tab.");
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Verify Dashboard option is not displayed in the list of Tabbar names.");
        List<String> tabbarOptions_Order = getMoreScreen().getTabBarNames();
        tabbarOptions_Reorder = Stream
                .concat(tabbarOptions_Reorder.stream(), tabbarOptions_Order.stream())
                .collect(Collectors.toList());
        getMoreScreen().tapEdit();
        getMoreReorderScreen().waitToLoad();
        //FIXME: There is no difference between enabled and disabled icon options
        /*Assert.assertFalse(getMoreReorderScreen().isTabbarNameVisible("Dashboard"),
            "Dashboard option is visible on Reorder screen.");*/

        log.info("Verify All Tabbar Options displayed in Reorder screen.");
        Assert.assertEquals(getMoreReorderScreen().getTabBarNames(), tabbarOptions_Reorder);
        int endElementIndex = tabbarOptions_Reorder.indexOf("Goal Planning");
        CommonUtils.dragDropElement(getDriver(),
                getMoreReorderScreen().getTabbarDragIcon("Funds Transfer"),
                getMoreReorderScreen().getTabbarDragIcon("Goal Planning"));
        tabbarOptions_Reorder.remove("Funds Transfer");
        tabbarOptions_Reorder.add(endElementIndex, "Funds Transfer");
        Assert.assertEquals(getMoreReorderScreen().getTabBarNames(), tabbarOptions_Reorder);
        getMoreReorderScreen().tapSave();
        getMoreScreen().waitToLoad();
        tabbarOptions_Order = tabbarOptions_Reorder.subList(3, tabbarOptions_Reorder.size());
        Assert.assertEquals(getMoreScreen().getTabBarNames(), tabbarOptions_Order);

        getMoreScreen().tapEdit();
        getMoreReorderScreen().waitToLoad();
        endElementIndex = tabbarOptions_Reorder.indexOf("Preferences");
        CommonUtils
                .dragDropElement(getDriver(), getMoreReorderScreen().getTabbarDragIcon("Bill Pay"),
                        getMoreReorderScreen().getTabbarDragIcon("Preferences"));
        tabbarOptions_Reorder.remove("Bill Pay");
        tabbarOptions_Reorder.add(endElementIndex, "Bill Pay");
        Assert.assertEquals(getMoreReorderScreen().getTabBarNames(), tabbarOptions_Reorder);
        getMoreReorderScreen().tapSave();
        getMoreScreen().waitToLoad();
        tabbarOptions_Order = tabbarOptions_Reorder.subList(3, tabbarOptions_Reorder.size());
        Assert.assertEquals(getMoreScreen().getTabBarNames(), tabbarOptions_Order);

        log.info("Verify Reordered Tabbar Options are not retained without saving.");
        getMoreScreen().tapEdit();
        getMoreReorderScreen().waitToLoad();
        CommonUtils.dragDropElement(getDriver(), getMoreReorderScreen().getTabbarDragIcon("Vault"),
                getMoreReorderScreen().getTabbarDragIcon("Preferences"));
        getMoreReorderScreen().tapBack();
        getMoreScreen().waitToLoad();
        Assert.assertEquals(getMoreScreen().getTabBarNames(), tabbarOptions_Order);
    }

    @Test(
            description = "1155791: Verify if Disclosure text is shown on clicking Disclosures", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "login", "regression"})
    public void TestDisclosuresText(final String username, final String password) {
        SoftAssert verifyDisclosuresText = new SoftAssert();

        final String disclosureText1 = "Ⓒ 2022 Raymond James & Associates, Inc., Member New York "
                + "Stock Exchange/SIPC. | Statement of Financial Condition (https://www.raymondjames.com"
                + "/-/media/rj/dotcom/files/our-company/about-us/rja-statement-of-financial-condition.pd"
                + "f) The Dow Jones Indexes℠ are compiled, calculated and distributed by Dow Jones & Com"
                + "pany, Inc. and have been licensed for use. All content of the Dow Jones Indexes℠ Ⓒ 2"
                + "022 Dow Jones & Company, Inc. Visit Terms and Conditions. Raymond James & Associates,"
                + " Inc. member New York Stock Exchange (https://www.nyse.com/index) / SIPC (https://www"
                + ".sipc.org/) and Raymond James Financial Services, Inc. member FINRA (https://www.finr"
                + "a.org/#/) / SIPC (https://www.sipc.org/) are subsidiaries of Raymond James Financial,"
                + " Inc. Privacy/Security (https://www.raymondjames.com/privacy-security-and-account-pro"
                + "tection/how-raymond-james-protects-your-privacy)";

        log.info("Sign In.");
        launchApp();
        getLoginScreen().waitToLoad();

        log.info("Tapped on Disclosures.");
        getLoginScreen().tapDisclosures();

        log.info("Verifying Disclosures Text.");
        verifyDisclosuresText.assertTrue(getDisclosuresScreen().getDisclosuresHeader(),
                "Disclosure Header Not displayed.");
        verifyDisclosuresText.assertEquals(getDisclosuresScreen().getLoginDisclosuresText(),
                disclosureText1,
                "Disclosure Text Not displayed.");
    }


    private void verifyAccountsScreen() {
        SoftAssert assertAccountsScreen = new SoftAssert();

        assertAccountsScreen.assertTrue(getAccountsScreen().getAccountsHeader().isDisplayed(),
                "Accounts Header is not displayed.");
        assertAccountsScreen.assertTrue(getAccountsScreen().getAllAccounts().isDisplayed(),
                "All Accounts tab is not displayed.");
        assertAccountsScreen.assertTrue(getAccountsScreen().getAssetsSection().isDisplayed(),
                "Raymond James Accounts tab is not displayed.");
    }
}
