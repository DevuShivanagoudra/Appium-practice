package mobile.ios.more.accountservices;

import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.constants.Direction;
import mobile.appium.ios.IOSUtils;
import mobile.base.IOSTestBase;
import mobile.common.constants.AccountServicesOptions;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import mobile.common.constants.Toggle;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AccountServices extends IOSTestBase {

    public void verifyAccountDeliveryOptions(final Map<String, String> deliveryTypes) {
        Map<String, String> deliveryTypeEdelivary = new HashMap<>();
        deliveryTypeEdelivary.put("Statements", "E-Delivery");
        Map<String, String> deliveryTypePaper = new HashMap<>();
        deliveryTypePaper.put("Statements", "Paper");
        getDriver()
                .scrollTo(getDocumentDeliveryScreen().getAccountsHeader(), Direction.UP, 3);
        List<String> accounts = getDocumentDeliveryScreen().getAccounts()
                .stream().map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
        int section = 0;
        /* The structure of the accounts is shown below, all of then are siblings.
            Investment Accounts
            ..
            ..
            Banking Accounts
            ..
            ..
            View Only Accounts
            ..
            ..
            Document Delivery Options */
        if (accounts.contains("Banking Accounts")) {
            section = accounts.indexOf("Banking Accounts");
        } else if (accounts.contains("View Only Accounts")) {
            section = accounts.indexOf("View Only Accounts");
        } else if (accounts.contains("Document Delivery Options")) {
            section = accounts.indexOf("Document Delivery Options");
        } else {
            section = accounts.indexOf("Investment Accounts") + 4;
            //if there are a lot of Investment accounts (>= 10), fetch only 3
        }

        if (section > 9) { //if there are a lot of Investment accounts (>= 10), fetch only 3
            section = accounts.indexOf("Investment Accounts") + 4;
        }
        List<String> investmentAccounts = getDocumentDeliveryScreen().getAccounts()
                .subList(accounts.indexOf("Investment Accounts") + 1, section)
                .stream()
                .map(x -> x.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText")))
                .map(x -> x.getAttribute("label")).collect(
                        Collectors.toList());
        for (String acct : investmentAccounts) {
            getDocumentDeliveryScreen().tapAccount(acct);
            getAccountDeliveryOptionsScreen().waitToLoad();
            getAccountDeliveryOptionsScreen().setDeliveryTypes(deliveryTypeEdelivary);
            Assert.assertTrue(IOSUtils
                            .getToggleState(getAccountDeliveryOptionsScreen().getStatementsToggle()),
                    "Account Delivery Option is not Editable.");
            getAccountDeliveryOptionsScreen().setDeliveryTypes(deliveryTypePaper);
            Assert.assertFalse(
                    IOSUtils.getToggleState(getAccountDeliveryOptionsScreen().getStatementsToggle()),
                    "Account Delivery Option is not Editable.");
            getAccountDeliveryOptionsScreen().tapBack();
            getDocumentDeliveryScreen().waitForAccountsHeaderToLoad();
            getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
            getDocumentDeliveryScreen().waitForOptionsToLoad();
        }
    }

    public void verifyViewOnlyAccounts_DeliveryOptionsNotEditable(
            final Map<String, String> deliveryTypes) {
        Map<String, String> deliveryTypeEdelivary = new HashMap<>();
        deliveryTypeEdelivary.put("Statements", "E-Delivery");
        Map<String, String> deliveryTypePaper = new HashMap<>();
        deliveryTypePaper.put("Statements", "Paper");
        List<String> accounts = getDocumentDeliveryScreen().getAccounts()
                .stream().map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
        List<String> accountNames = accounts.subList(accounts.indexOf("View Only Accounts"),
                accounts.indexOf("Document Delivery Options"));
        accountNames = accountNames
                .subList(accountNames.indexOf("Investment Accounts"), accountNames.size());
        for (String acct : accountNames) {
            getDocumentDeliveryScreen().tapAccount(acct);
            Assert
                    .assertFalse(getDriver()
                                    .isElementPresent(getAccountDeliveryOptionsScreen().getStatementsToggle()),
                            "Account Delivery Option is Editable.");
        }
    }

    public void verifyAccountsVisible(List<String> accounts) {
        for (String account : accounts) {
            Assert.assertTrue(getDocumentDeliveryScreen().isAccountVisible(account),
                    String.format("%s is not displayed.", account));
        }
    }

    public void verifyAccoutNotVisible(final String accountName) {
        getDriver()
                .scrollTo(getDocumentDeliveryScreen().getAccountsHeader(), Direction.UP, 3);
        final List<String> accounts = getDocumentDeliveryScreen().getAccounts().stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        Assert.assertFalse(accounts.contains(accountName),
                "Account is shown up in Document Delivery screen.");
    }

    public void navigateToDocumentDelivery() {
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(AccountServicesOptions.DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();
    }
}
