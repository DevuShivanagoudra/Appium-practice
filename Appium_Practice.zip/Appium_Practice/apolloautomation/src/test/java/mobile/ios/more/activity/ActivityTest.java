package mobile.ios.more.activity;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.IOSTestBase;
import mobile.common.constants.Messages;
import mobile.common.constants.TabBarOption;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Slf4j
public class ActivityTest extends IOSTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1296471:Verify the app displays correct Disclosures copy<br>"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "activity", "regression"})
    public void TestVerifyDisclosuresTextInActivityScreen(final String username,
                                                          final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Activity screen.");
        getTabBar().tap(TabBarOption.ACTIVITY);
        getActivityScreen().waitToLoad();

        log.info("Verify Activity Disclosures Text.");
        getActivityScreen().tapDisclosuresLink();
        getActivityDisclosuresScreen().waitToLoad();
        Assert.assertTrue(
                getActivityDisclosuresScreen().getDisclosuresText().getText().substring(2)
                        .contentEquals(
                                Messages.ACTIVITY_DISCLOSURES_TEST_IOS.toString().substring(2)),
                "Activity Disclosures text is not matched.");
    }

    @Test(
            description =
                    "1296713:Verify App display the record’s chevron pointing down If the Description’s copy is long<br>"
                            +
                            "1296723:Verify App display record's chevron pointing up and down icon to indicate record is expanded or collapsed"
                            +
                            "1328140:Verify App display the View filter<br>" +
                            "1328145:Verify App display the default value for the “View” filter is 'All Types'<br>"
            , dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "activity", "regression"})
    public void TestVerifyChevronFunctionality(final String username,
                                               final String password) {

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Activity screen.");
        getTabBar().tap(TabBarOption.ACTIVITY);
        getActivityScreen().waitToLoad();
        Assert.assertEquals(
                getActivityScreen().getPendingActivity().getAttribute("value"),
                "Collapsed", "Pending activity chevron is expanded.");
        getActivityScreen().tapOnPendingActivity();
        Assert.assertEquals(
                getActivityScreen().getPendingActivity().getAttribute("value"),
                "Expanded", "Pending activity chevron is collapsed.");

        //FIXME: Activity types is been moved to filter screen. will be taken care after FF.
        /*Assert.assertEquals(getActivityScreen().getViewDropDown().getText(), "All Types",
            "Default value is not matched.");*/
    }
}
