package mobile.ios.more.accountservices;

import api.utils.Accounts;
import jarvis.mobile.common.constants.Direction;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.CommonUtils;
import mobile.common.constants.Toggle;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class DocumentDeliveryOptionsTest extends AccountServices {

    static final String secretAnswer = "secret";

    @DataProvider(name = "pendingDDO")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME8.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "fullaccessdoc")
    public Object[][] customerwithfullaccess() {
        return new Object[][]{
                {Accounts.USERNAME10.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "viewonlyaccounts")
    public Object[][] customerwithviewonlyaccounts() {
        return new Object[][]{
                {Accounts.USERNAME5.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1209567: Verify the Document Delivery Options when the user has a pending DDO change<br>"
                            + "1209569: Verify the Document Delivery Options when the user has document management on file and enabled<br>"
            , dataProvider = "pendingDDO", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsForAccountWithPendingDDOChange(final String username,
                                                                        final String password) {
        Map<String, String> deliveryTypes = new HashMap<>();
        deliveryTypes.put("Statements", "E-Delivery");
        List<String> accounts = Arrays.asList("Cobb, Dan Trust ARK SMA xxxxX218");

        log.info("Sign In with user having pending DDO change.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts visible and Delivery options are editable.");
        navigateToDocumentDelivery();
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        getDocumentDeliveryScreen().tapAccountsHeader();
        verifyAccountsVisible(accounts);
        //FIXME: Click is not working on TypeSwitch(IOS16).
        CommonUtils
                .scrollToElement(getDriver(), getDocumentDeliveryScreen().getEDeliveryAllOptions(),
                        Direction.DOWN, 4);
        verifyAccountDeliveryOptions(deliveryTypes);

        log.info("Sign In with user having document management on file.");
        tearDownApp();
        login(Accounts.USERNAME9.toString(), password, secretAnswer);
        navigateToDocumentDelivery();
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        getDriver().scrollTo(getDocumentDeliveryScreen().getAccountsHeader());
        Assert.assertTrue(getDocumentDeliveryScreen().getAccounts().size() >= 1,
                "More than one account displayed.");
        getDocumentDeliveryScreen().tapAccountsHeader();
        verifyAccountDeliveryOptions(deliveryTypes);
    }

    @Test(
            description =
                    "1209575: Verify the Document Delivery Options when the user is not account holder but has full access<br>"
                            + "1209577: Verify the Document Delivery Options when the user has closed account(s) and has full access<br>"
            , dataProvider = "fullaccessdoc", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsForNOTAccountHolderButFullAccess(final String username,
                                                                          final String password) {
        Map<String, String> deliveryTypes = new HashMap<>();
        deliveryTypes.put("Statements", "E-Delivery");
        List<String> accounts = Arrays
                .asList("King Capital Access Joint xxxx3365",
                        "Camp IRA xxxx1716"); //TODO: Accounts needs to be changed.

        log.info("Sign In with user Who is not account holder but has full access.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts visible and Delivery options are editable.");
        navigateToDocumentDelivery();
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        getDocumentDeliveryScreen().waitForOptionsToLoad();
        getDocumentDeliveryScreen().tapAccountsHeader();
        Assert.assertTrue(getDocumentDeliveryScreen()
                        .getAccountsInSection("Investment Accounts", "View Only Accounts").size() >= 1,
                "More than one account displayed.");
        verifyAccountDeliveryOptions(deliveryTypes);

        log.info(
                "Sign In with user having closed accounts and verify closed accounts not showing up in Document Delivery Accounts.");
        tearDownApp();
        login(Accounts.USERNAME9.toString(), password, secretAnswer);
        navigateToDocumentDelivery();
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        getDocumentDeliveryScreen().waitForOptionsToLoad();
        getDocumentDeliveryScreen().tapAccountsHeader();
        verifyAccoutNotVisible(accounts.get(0));
        verifyAccoutNotVisible(accounts.get(1));
    }

    @Test(
            description =
                    "1209568: Verify the Document Delivery Options when the user has view-only RJ bank accounts<br>"
            , dataProvider = "viewonlyaccounts", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsForViewonlyAccounts(final String username,
                                                             final String password) {
        Map<String, String> deliveryTypes = new HashMap<>();
        deliveryTypes.put("Statements", "E-Delivery");
        List<String> accounts = Arrays
                .asList("King Capital Access Joint xxxx3365", "Camp IRA xxxx1716");

        log.info("Sign In with user Who is not account holder but has full access.");
        login(username, password, secretAnswer);

        log.info("Verify Accounts visible and Delivery options are editable.");
        navigateToDocumentDelivery();
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        getDocumentDeliveryScreen().tapAccountsHeader();
        getDriver().scrollTo(getDocumentDeliveryScreen().getDocumentDeliveryOptionsCopy(),
                Direction.UP_SMALL);
        verifyViewOnlyAccounts_DeliveryOptionsNotEditable(deliveryTypes);
    }
}
