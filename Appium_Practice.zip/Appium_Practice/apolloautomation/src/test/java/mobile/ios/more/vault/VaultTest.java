package mobile.ios.more.vault;

import api.utils.Accounts;
import com.github.javafaker.Faker;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.IOSTestBase;
import mobile.common.constants.Messages;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.Arrays;
import java.util.List;

@Slf4j
public class VaultTest extends IOSTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME11.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description =
                    "1334368:Verify App display the following options upon taping the + icon<br>" +
                            "1334396:Verify App display the following bottom sheet if create folder is selected<br>"
                            +
                            "1334624:Verify App disable the Save/Create CTA if name text box is empty<br>",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"vault", "regression"}, enabled = false)
    public void TestVerifyAddItemOptionsAndCreateNewFolderFields(final String username,
                                                                 final String password) {

        List<String> expectedOptions = Arrays
                .asList("Upload File", "Create New Folder");

        Faker faker = new Faker();
        String folderName = faker.name().fullName();

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to More screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();

        log.info("Navigate to Vault screen.");
        getMoreScreen().tapMoreOption(MoreOptions.VAULT.toString());
        getVaultScreen().waitToLoad();

        log.info("Verify the add item options.");
        getVaultScreen().tapAddItem();
        Assert.assertEquals(getVaultScreen().getAddItemOptions(), expectedOptions,
                "Add Item Options does not match.");

        log.info("Verify all fields are displayed for new folder.");
        getVaultScreen().tapCreateNewFolder();
        verifyNewFolderFields();

        log.info("Verify create button is enabled when text is entered.");
        getVaultNewFolderScreen().enterFolderName(folderName);
        Assert.assertTrue(
                getVaultNewFolderScreen().getSaveButton().getAttribute("enabled").contains("true"),
                "Create button is disabled.");
    }

    @Test(
            description =
                    "1333789: Validate if only 1 vault is available , the vault name / home folder should be displayed.<br>"
                            + "1333793: Validate the account holder can opt to expand the accordion.<br>"
                            + "1333797: Validate the account holder  can collapse accordion display to hide the additional Information.<br>"
                            + "1333850: Validate the default sort order is 'Type'.",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"vault", "regression"})
    public void TestVerifyDefaultView(final String username,
                                      final String password) {
        final String title = "Vault";
        final String defaultSort = "Type";

        log.info("Sign In and Navigate to Vault screen.");
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.VAULT.toString());
        getVaultScreen().waitToLoad();

        log.info("Verify default view of Main Screen.");
        Assert.assertEquals(getVaultScreen().getTitle().getAttribute("label"), title,
                "Title of the screen does not match.");
        getVaultScreen().expandAdditionalInfo();
        Assert.assertTrue(getVaultScreen().getCollaborators().isDisplayed(),
                "Additional Information is not displayed.");
        getVaultScreen().CollapseAdditionalInfo();
        Assert.assertFalse(getDriver().isElementVisible(getVaultScreen().getCollaborators()),
                "Additional Information should not be displayed.");

        getVaultScreen().tapSort();
        Assert.assertTrue(getVaultScreen().isSortOptionSelected(defaultSort),
                String.format("Default Sort %s is not selected.", defaultSort));
    }

    @Test(
            description =
                    "1334609: Validate the trash icon (CTA) will appear at the top right section of the slide screen.<br>"
                            + "1334610: Validate once CTA is tapped , a “Permanently Delete” confirmation message should appear.<br>"
                            + "1334611: Validate CTA is tapped , confirmation  message  should appear this message “Are you  sure you want to delete ””<folder name>” and its all content.<br>"
                            + "1334612: Validate once CTA is tapped , confirmation  message  should appear 2 buttons: “Delete ” & “Cancel”.",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"vault", "regression"})
    public void TestVerifyDeleteConfirmationElements(final String username,
                                                     final String password) {
        final String name = "11deleteFolder";
        final String description = "delete folder";
        final String title = "Permanently Delete";

        log.info("Sign In and Navigate to Vault screen.");
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.VAULT.toString());
        getVaultScreen().waitToLoad();

        log.info("Create a folder.");
        getVaultScreen().tapAddItem();
        getVaultScreen().tapCreateNewFolder();
        getVaultNewFolderScreen().enterFolderDetails(name, description);
        getVaultScreen().tapSaveButton();
        getVaultScreen().waitForFolderToLoad(name);

        log.info("Try deleting the folder and verify the options available.");
        getVaultScreen().tapFolderInfo(name);
        getVaultFolderInformationScreen().waitToLoad();
        getVaultFolderInformationScreen().tapDeleteButton();

        getDriver().waitUntilAlertPresent();
        Assert.assertTrue(getDriver().isAlertTitle(title),
                "Title does not match.");
        Assert.assertEquals(getDriver().getAlertText().get(1),
                String.format(Messages.VAULT_DELETE_FOLDER_CONFIRMATION_IOS.toString(), name),
                "Title Message does not match.");
        getVaultDeleteFolderAlert().tapOption("Cancel");
        getVaultFolderInformationScreen().tapDeleteButton();
        getVaultDeleteFolderAlert().tapOption("Delete");
        getVaultScreen().waitToLoad();
        Assert.assertFalse(getVaultScreen().isFolderVisible(name),
                "Deleted Folder is still displayed.");
    }

    @Test(
            description =
                    "1334606: Validate only folder created by the account holder can be delete.<br>"
                            + "1334613: Validate if an account holder  selects the “Delete ” button the folder and all its sub folders and files will permanently delete.<br>"
                            + "1334614: Validate if account  holder delete the folder, application return the account holder to parent folder.<br>"
                            + "1334615: Validate if an account holder  selects the \"Cancel “ button , the account holder will return back to the “Folder Information ” slide screen.",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"vault", "regression"})
    public void TestVerifyDeleteFolder(final String username,
                                       final String password) {
        final String folderName = "11PermanentdeleteFolder";
        final String innerfoldername = "11innerFolder";
        final String description = "delete folder";
        final String title = "Permanently Delete";

        log.info("Sign In and Navigate to Vault screen.");
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.VAULT.toString());
        getVaultScreen().waitToLoad();

        log.info("Create a folder.");
        getVaultScreen().tapAddItem();
        getVaultScreen().tapCreateNewFolder();
        getVaultNewFolderScreen().enterFolderDetails(folderName, description);
        getVaultScreen().tapSaveButton();
        getVaultScreen().waitForFolderToLoad(folderName);

        log.info("Create multi-level folder.");
        getVaultScreen().tapFolder(folderName);
        getVaultScreen().waitToLoad();
        getVaultDetailScreen().tapAddItem();
        getVaultDetailScreen().tapCreateNewFolder();
        getVaultNewFolderScreen().enterFolderDetails(innerfoldername, description);
        getVaultDetailScreen().tapSaveButton();
        getVaultDetailScreen().waitForFolderToLoad(innerfoldername);
        getVaultDetailScreen().tapBackButton();
        getVaultScreen().waitToLoad();

        log.info("Try deleting the multi-level folder and verify all contents got deleted.");
        getVaultScreen().tapFolderInfo(folderName);
        getVaultFolderInformationScreen().waitToLoad();
        getVaultFolderInformationScreen().tapDeleteButton();
        getDriver().waitUntilAlertPresent();
        Assert.assertTrue(getDriver().isAlertTitle(title),
                "Title does not match.");
        Assert.assertEquals(getDriver().getAlertText().get(1),
                String.format(Messages.VAULT_DELETE_FOLDER_CONFIRMATION_IOS.toString(), folderName),
                "Title Message does not match.");
        getVaultDeleteFolderAlert().tapOption("Cancel");
        getVaultFolderInformationScreen().waitToLoad();
        Assert.assertTrue(getVaultFolderInformationScreen().getDeleteButton().isEnabled(),
                "Delete Button is not enabled.");
        getVaultFolderInformationScreen().tapDeleteButton();
        getVaultDeleteFolderAlert().tapOption("Delete");
        getVaultScreen().waitToLoad();
        Assert.assertFalse(getVaultScreen().isFolderVisible(folderName),
                "Deleted Folder is still displayed.");
        Assert.assertFalse(getVaultScreen().isFolderVisible(innerfoldername),
                "Deleted Folder is still displayed.");
    }

    @Test(
            description =
                    "1336320: Validate from the “Folder information” slide screen the account holder can select “Edit” beside the “Folder Name” if the account holder created folder.<br>"
                            + "1336321: Validate if the Folder Name is empty, the “Save” CTA should be disable.<br>"
                            + "1336325: Validate the existing folder name should display in text box.<br>"
                            + "1335576: Validate the description should not allow a space at the start"
                            + "1335578: Validate the exciting folder description should be display in the text box"
                            + "1336330: Validate once the new folder name is saved, the new folder name shall reflect in the folder information.",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"vault", "regression"})
    public void TestVerifyEditFolder(final String username,
                                     final String password) {
        String folderName = "11EditFolder";
        String description = "description";

        log.info("Sign In and Navigate to Vault screen.");
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.VAULT.toString());
        getVaultScreen().waitToLoad();

        log.info("Create a folder.");
        getVaultScreen().tapAddItem();
        getVaultScreen().tapCreateNewFolder();
        getVaultNewFolderScreen().enterFolderDetails(folderName, description);
        getVaultScreen().tapSaveButton();
        getVaultScreen().waitForFolderToLoad(folderName);

        log.info("Edit Folder name and description and verify.");
        getVaultScreen().tapFolderInfo(folderName);
        getVaultFolderInformationScreen().waitToLoad();
        getVaultFolderInformationScreen().tapEditFolder();
        Assert.assertEquals(getVaultNewFolderScreen().getFolderNameEditable().getText(), folderName,
                "Existing Folder Name does not match.");
        getVaultNewFolderScreen().clearFolderName();
        Assert.assertFalse(getVaultNewFolderScreen().getSaveButton().isEnabled(),
                "Save Button enabled eventhough Folder name is empty.");
        folderName = String.format("%s%s", folderName, "Edited");
        getVaultNewFolderScreen().enterFolderName(folderName);
        getVaultNewFolderScreen().tapSaveButton();
        getVaultFolderInformationScreen().waitToLoad();
        Assert.assertEquals(getVaultFolderInformationScreen().getFolderNameValue().getText(),
                folderName,
                "Edited Folder Name does not match.");

        getVaultFolderInformationScreen().tapEditDescription();
        Assert
                .assertEquals(getVaultNewFolderScreen().getDescriptionEditable().getText(), description,
                        "Description does not match.");
        description = String.format("%s%s", description, "Edited");
        getVaultNewFolderScreen().enterDescription(" " + description);
        getVaultNewFolderScreen().tapSaveButton();
        getVaultFolderInformationScreen().waitToLoad();
        Assert.assertEquals(getVaultFolderInformationScreen().getDescriptionValue().getText(),
                description,
                "Edited Description does not match.");
        description = String.format("%s%s", description, "Edited2");
        getVaultFolderInformationScreen().tapEditDescription();
        getVaultNewFolderScreen().enterDescription(description);
        getVaultNewFolderScreen().tapSaveButton();
        getVaultFolderInformationScreen().waitToLoad();
        Assert.assertEquals(getVaultFolderInformationScreen().getDescriptionValue().getText(),
                description,
                "Edited Description does not match.");
        deleteFolder();
    }

    @Test(
            description =
                    "1333787: Validate the top most accordion in the Vault’s main screen should display the name of the vault that is currently selected.<br>"
                            + "1333798: Validate once the accordion is expanded app displays the details of the current vault.<br>"
                            + "1333815: Validate the Financial Advisors in alphabetical order by First Name.<br>"
                            + "1333845: Validate  the accounts holder navigates to the vault, the home/root folder should be displayed  by default.",
            dataProvider = "customer",
            retryAnalyzer = RetryAnalyzer.class,
            groups = {"vault", "regression"})
    public void TestVerifyAdditionalInformation(final String username,
                                                final String password) {
        final String vaultName = "Shared Files";
        final String officeProfessionals = "Office Professionals";

        log.info("Sign In and Navigate to Vault screen.");
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.VAULT.toString());
        getVaultScreen().waitToLoad();

        log.info("Verify vault Details.");
        Assert.assertEquals(getVaultScreen().getSelectedVault().getText(), vaultName,
                "Selected Vault name does not match.");
        getVaultScreen().expandAdditionalInfo();
        final List<String> vaultDetails = getVaultScreen().getVaultDetails(vaultName);
        Assert.assertEquals(vaultDetails.get(0), vaultName,
                "Vault name does not match.");
        Assert.assertTrue(vaultDetails.get(1).matches("Collaborators \\(.*"),
                "Collaborators header is not displayed.");
        Assert.assertEquals(vaultDetails.get(vaultDetails.size() - 1), officeProfessionals,
                "Office Professionals header is not displayed.");
        List<String> financialAdvisors = vaultDetails.subList(2, vaultDetails.size() - 1);
        verifyFinancialAdvisors(financialAdvisors);
    }

    private void verifyFinancialAdvisors(final List<String> financialAdvisors) {
        for (String advisor : financialAdvisors) {
            Assert.assertTrue(advisor.matches(".*- Financial Advisor"),
                    String.format("String [%s] is not advisor.", advisor));
        }
    }

    private void verifyNewFolderFields() {
        SoftAssert verifyNewFolder = new SoftAssert();
        verifyNewFolder.assertTrue(getVaultNewFolderScreen().getFolderNameEditable().isDisplayed(),
                "Name field is not displayed.");
        verifyNewFolder.assertTrue(getVaultNewFolderScreen().getDescriptionEditable().isDisplayed(),
                "Description field is not displayed.");
        verifyNewFolder.assertTrue(getVaultNewFolderScreen().getCancelButton().isDisplayed(),
                "Cancel button is not displayed.");
        verifyNewFolder.assertTrue(getVaultNewFolderScreen().getSaveButton().isDisplayed(),
                "Cancel button is not displayed.");
        verifyNewFolder.assertTrue(
                getVaultNewFolderScreen().getSaveButton().getAttribute("enabled").contains("false"),
                "Create button is enabled.");
        verifyNewFolder.assertAll();
    }

    private void deleteFolder() {
        getVaultFolderInformationScreen().tapDeleteButton();
        getVaultDeleteFolderAlert().tapOption("Delete");
        getVaultScreen().waitToLoad();
    }
}
