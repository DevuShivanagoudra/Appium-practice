package mobile.ios.login;

import api.utils.Accounts;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.base.IOSTestBase;
import mobile.common.constants.ErrorMessages;
import mobile.common.constants.Toggle;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Slf4j
public class ChallengeTest extends IOSTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME2.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description = "", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "challenge", "regression"})
    public void TestIncorrectSecretAnswer(final String username, final String password) {
        final String incorrectSecretAnswer = "secret11";
        final String errorText = ErrorMessages.INCORRECTSECRETANSWER_ERROR.toString();

        log.info("Sign In.");
        login(username, password);
        getSecretQuestionScreen().waitToLoad();

        log.info("Enter Incorrect Secret Answer.");
        getSecretQuestionScreen().submitSecretAnswer(incorrectSecretAnswer, Toggle.OFF);
        Assert.assertEquals(getSecretQuestionScreen().getErrorText().getText(), errorText);
    }
}
