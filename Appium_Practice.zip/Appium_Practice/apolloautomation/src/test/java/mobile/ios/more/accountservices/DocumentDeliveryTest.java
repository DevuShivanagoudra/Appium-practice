package mobile.ios.more.accountservices;

import api.utils.Accounts;
import io.appium.java_client.AppiumBy;
import jarvis.mobile.common.constants.Direction;
import listeners.RetryAnalyzer;
import lombok.extern.slf4j.Slf4j;
import mobile.appium.ios.IOSUtils;
import mobile.base.IOSTestBase;
import mobile.common.constants.AccountServicesOptions;
import mobile.common.constants.MoreOptions;
import mobile.common.constants.TabBarOption;
import mobile.common.constants.Toggle;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class DocumentDeliveryTest extends IOSTestBase {

    static final String secretAnswer = "secret";

    @DataProvider(name = "customer")
    public Object[][] customer() {
        return new Object[][]{
                {Accounts.USERNAME1.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "ddobillingandstatement")
    public Object[][] ddobillingandstatement() {
        return new Object[][]{
                {Accounts.USERNAME6.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @DataProvider(name = "noaccessaccount")
    public Object[][] noaccessaccount() {
        return new Object[][]{
                {Accounts.USERNAME7.toString(), Accounts.PASSWORD.toString()}
        };
    }

    @Test(
            description = "1184683: Verify the user can toggle 'Choose E-delivery for All Documents'"
                    + "1184684: Verify the app displays the following list of document types if user set 'E-Delivery for all documents' to false"
                    + "1184689: Verify the user can able to choose Paper delivery or E-Delivery for document types", dataProvider = "customer", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsSaved(final String username, final String password) {
        List<String> documentTypes = Arrays
                .asList("Statements", "Trade Confirmations", "Tax Reporting", "Reports & Proxies",
                        "Prospectuses", "Other Correspondence");
        Map<String, String> accounts = new HashMap<>();
        accounts.put("zx", "E-Delivery");
        accounts.put("Test account", "E-Delivery");
        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(AccountServicesOptions.DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();

        log.info("Verify Delivery types are shown on toggling 'E-Delivery for All Documents'.");
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        verifyDeliveryTypesVisible(documentTypes);
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.ON);
        verifyDeliveryTypesNOTVisible(documentTypes);

        log.info("Set Document Types and check the changes persist by logout and login back.");
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        getDocumentDeliveryScreen().tapDocumentType(documentTypes.get(0));
        getAccountDeliveryOptionsScreen().waitToLoad();
        getAccountDeliveryOptionsScreen().setDeliveryTypes(accounts);
        getAccountDeliveryOptionsScreen()
                .tapBack(); // TODO: App does not turns the toggle off after navigating back to the previous screen.
        getDocumentDeliveryScreen().waitToLoad();
        getDocumentDeliveryScreen().tapDocumentType(documentTypes.get(1));
        getAccountDeliveryOptionsScreen().waitToLoad();
        getAccountDeliveryOptionsScreen().setDeliveryTypes(accounts);
        getAccountDeliveryOptionsScreen().tapBack();
        getDocumentDeliveryScreen().waitToLoad();

        getDocumentDeliveryScreen().tapDone();
        if (getDriver().isElementVisible(getEDeliveryTermsandConditionsScreen().getAgreeButton())) {
            getEDeliveryTermsandConditionsScreen().tapIAgree();
            getAccountServicesScreen().waitToLoad();
        }
        tearDownApp();
        login(username, password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(AccountServicesOptions.DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        Assert.assertTrue(
                getDriver().isElementVisible(getDocumentDeliveryScreen().getStatementsEDelivery()),
                "Statements E-Delivery option is not saved.");
        Assert
                .assertTrue(getDocumentDeliveryScreen().getTradeConfirmationsEDelivery().isDisplayed(),
                        "Trade Confirmations E-Delivery option is not saved.");
        getDocumentDeliveryScreen().tapDocumentType(documentTypes.get(0));
        getAccountDeliveryOptionsScreen().waitToLoad();
        List<String> accountlist = new ArrayList<>(accounts.keySet());
        Assert.assertTrue(
                getAccountDeliveryOptionsScreen().isDeliveryTypeSelected(accountlist.get(0)),
                "Statements E-Delivery option is not saved.");
        Assert.assertTrue(
                getAccountDeliveryOptionsScreen().isDeliveryTypeSelected(accountlist.get(1)),
                "Trade Confirmations E-Delivery option is not saved.");
    }

    @Test(
            description =
                    "1209554: Verify the Document Delivery Options when the user has RJ Bank DDO Billing<br>"
                            + "1209546: Verify the Document Delivery Options when the user has invalid DDO account (DMI)<br>"
            , dataProvider = "ddobillingandstatement", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsEditable(final String username, final String password) {
        Map<String, String> deliveryTypes = new HashMap<>();
        deliveryTypes.put("Statements", "E-Delivery");
        final String DMIAccount = "Residential Mortgage";

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(AccountServicesOptions.DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();

        log.info("Verify Delivery options can be edited for individual accounts.");
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        verifyAccountDeliveryOptions(deliveryTypes);

        log.info("Verify DMI account is not shown up the list of Document delivery accounts.");
        tearDownApp();
        login(Accounts.USERNAME6.toString(), password, secretAnswer);
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(AccountServicesOptions.DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        verifyDMIAccoutNotVisible(DMIAccount);
    }

    @Test(
            description =
                    "1209490: Verify the Document Delivery Options when the user has no full access to DDO displayed<br>"
                            + "1209494: Verify the Document Delivery Options when the user only has Raymond James accounts<br>"
            , dataProvider = "noaccessaccount", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsVisibleForNoAccessAccount(final String username,
                                                                   final String password) {
        List<String> documentTypes = Arrays
                .asList("Statements", "Trade Confirmations", "Tax Reporting", "Reports & Proxies",
                        "Prospectuses", "Other Correspondence");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        if (getDriver().isAlertPresent()) {
            getDriver().clearAlert("OK");
        }
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(AccountServicesOptions.DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();

        log.info("Verify Delivery options Not displayed.");
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        verifyDeliveryTypesNOTVisible(documentTypes);

        //TODO: yet to implement TC 1209494
    }

    @Test(
            description =
                    "1209558: Verify the Document Delivery Options when the user has RJ Bank DDO Statement<br>"
                            + "1209565: Verify the Document Delivery Options when the user has both RJ Bank DDO Billing & Statement<br>"
            , dataProvider = "ddobillingandstatement", retryAnalyzer = RetryAnalyzer.class, groups = {
            "documents", "documentdelivery", "regression"})
    public void TestVerifyDeliveryOptionsVisibleForAccountWithDDOStatement(final String username,
                                                                           final String password) {
        Map<String, String> deliveryTypes = new HashMap<>();
        deliveryTypes.put("Statements", "E-Delivery");
        List<String> accounts = Arrays.asList("Wendy DampmanHenry Trust1 xxxx3934",
                "Simply Checking xxxxxx0565", "Select Savings xxxxxx2882");

        log.info("Sign In.");
        login(username, password, secretAnswer);

        log.info("Navigate to Document Delivery screen.");
        getTabBar().tap(TabBarOption.MORE);
        getMoreScreen().waitToLoad();
        getMoreScreen().tapMoreOption(MoreOptions.CLIENT_TOOLS.toString());
        getAccountServicesScreen().waitToLoad();
        getAccountServicesScreen().tapService(AccountServicesOptions.DOCUMENT_DELIVERY.toString());
        getDocumentDeliveryScreen().waitToLoad();

        log.info("Verify Delivery options Not displayed.");
        getDocumentDeliveryScreen().setEDeliveryToggle(Toggle.OFF);
        getDocumentDeliveryScreen().tapAccountsHeader();
        verifyAccountsVisible(accounts);
        verifyAccountDeliveryOptions(deliveryTypes);
    }

    private void verifyDeliveryTypesVisible(final List<String> deliverytypes) {
        final String deliveryType_locator = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";
        for (String type : deliverytypes) {
            getDriver().scrollTo(
                    AppiumBy.iOSClassChain(String.format(deliveryType_locator, type)));
        }
    }

    private void verifyDeliveryTypesNOTVisible(final List<String> deliverytypes) {
        final String deliveryType_locator = "**/XCUIElementTypeStaticText[`label == \"%s\"`]";
        for (String type : deliverytypes) {
            Assert.assertFalse(getDriver().isElementPresent(
                            AppiumBy.iOSClassChain(String.format(deliveryType_locator, type))),
                    String.format("%s is visible.", type));
        }
    }

    private void verifyAccountDeliveryOptions(final Map<String, String> deliveryTypes) {
        getDocumentDeliveryScreen().tapAccountsHeader();
        getDriver()
                .scrollTo(getDocumentDeliveryScreen().getViewOnlyAccountsHeader(),
                        Direction.UP_SMALL, 3);
        List<String> accounts = getDocumentDeliveryScreen().getAccounts()
                .stream().map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
        List<String> accountNames = accounts.subList(accounts.indexOf("Investment Accounts"),
                accounts.indexOf("View Only Accounts"));
        List<String> investmentAccounts = accountNames
                .subList(accountNames.indexOf("Investment Accounts") + 1,
                        accountNames.indexOf("Bank Accounts *"));
        for (String acct : investmentAccounts) {
            getDocumentDeliveryScreen().tapAccount(acct.split(",")[0]);
            getAccountDeliveryOptionsScreen().waitToLoad();
            getAccountDeliveryOptionsScreen().setDeliveryTypes(deliveryTypes);
            Assert.assertTrue(
                    IOSUtils.getToggleState(getAccountDeliveryOptionsScreen().getStatementsToggle()),
                    "Account Delivery Option is not Editable.");
            getAccountDeliveryOptionsScreen().tapBack();
        }
    }

    private void verifyDMIAccoutNotVisible(final String accountName) {
        getDriver()
                .scrollTo(getDocumentDeliveryScreen().getAccountsHeader(), Direction.UP, 3);
        final List<String> accounts = getDocumentDeliveryScreen().getAccounts().stream()
                .map(x -> x.getAttribute("label"))
                .collect(Collectors.toList());
        Assert.assertFalse(accounts.contains(accountName),
                "DMI account is shown up in Document Delivery screen.");
    }

    private void verifyAccountsVisible(List<String> accounts) {
        for (String account : accounts) {
            Assert.assertTrue(getDocumentDeliveryScreen().isAccountVisible(account),
                    String.format("%s is not displayed.", account));
        }
    }
}
