package listeners;

import com.aventstack.extentreports.ExtentReports;

import java.util.Objects;

public class ExReportManager {

    private static final ThreadLocal<ExtentReports> extentReport = new ThreadLocal();

    private ExReportManager() {
    }

    static ExtentReports getExtentReport() {
        return (ExtentReports) extentReport.get();
    }

    static void setExtentReport(ExtentReports rep) {
        if (Objects.nonNull(rep)) {
            extentReport.set(rep);
        }

    }

    static void unload() {
        extentReport.remove();
    }
}
