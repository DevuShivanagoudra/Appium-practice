package listeners;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryAnalyzer implements IRetryAnalyzer {

    final int maxRetries = Integer.parseInt(System.getProperty("appium.retry")) - 1;
    int counter = 0;

    @Override
    public boolean retry(ITestResult result) {
        // based on the value of annotation see if test needs to be rerun
        if (counter < maxRetries) {
            counter++;
            return true;
        }
        return false;
    }
}