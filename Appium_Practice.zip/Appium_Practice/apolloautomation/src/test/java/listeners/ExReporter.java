package listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.model.Media;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import jarvis.mobile.appium.Utils;
import jarvis.mobile.reports.Reporter;
import mobile.base.AndroidTestBase;
import mobile.base.IOSTestBase;

import java.io.File;
import java.io.IOException;
import java.util.Objects;

public class ExReporter implements Reporter {

    private static final String FILENAME = Utils.getProperty("appium.platformName");
    private static final String OS_VERSION = Utils.getProperty("appium.platformVersion");
    private static final String DEVICE_NAME = Utils.getProperty("appium.deviceName");
    private static final ExtentSparkReporter report;
    private static final ExtentSparkReporter failedReport;
    private static final File PATH;

    static {
        report = new ExtentSparkReporter(
                String.format("target/%s-ExecutionCustomReport.html", FILENAME));
        failedReport = (ExtentSparkReporter) (new ExtentSparkReporter(
                String.format("target/%sFailedTests.html", FILENAME))).filter().statusFilter()
                .as(new Status[]{Status.FAIL}).apply();
        PATH = new File("src/main/resources/extent-config-default.json");
    }

    private ExReporter() {
    }

    public static void initReport() throws IOException {
        final String platformName = System.getProperty("appium.platformName");
        final String buildType =
                (platformName.equalsIgnoreCase("ios")) ? IOSTestBase.build : AndroidTestBase.build;

        if (Objects.isNull(ExReportManager.getExtentReport())) {
            ExReportManager.setExtentReport(new ExtentReports());
            report.config().setReportName(String
                    .format("<h4 style=\"color:white;\">Environment: %s, %s[%s], %s</h4>",
                            buildType, FILENAME,
                            OS_VERSION, DEVICE_NAME));
            report.loadJSONConfig(PATH);
            failedReport.loadJSONConfig(PATH);
            failedReport.config().setDocumentTitle("Failed Execution Report");
            ExReportManager.getExtentReport()
                    .setSystemInfo("OS", String.format("%s [%s]", FILENAME, OS_VERSION));
            ExReportManager.getExtentReport().setSystemInfo("Device", DEVICE_NAME);
            ExReportManager.getExtentReport()
                    .attachReporter(report, failedReport);
        }
    }

    public static void flushReport() {
        if (Objects.nonNull(ExReportManager.getExtentReport())) {
            ExReportManager.getExtentReport().flush();
        }

        ExReportManager.unload();
        NodeManager.unload();
    }

    public static void createTest(String testName, String testDescription) {
        NodeManager
                .setTestNode(ExReportManager.getExtentReport().createTest(testName, testDescription));
    }

    public static ExtentTest getLogger() {
        return NodeManager.getTestNode();
    }

    public static void logInfo(String message) {
        getLogger().info(message);
    }

    public static void logPass(String message) {
        getLogger().pass(message);
    }

    public static void logFail(String message) {
        getLogger().fail(message);
    }

    public static void logFail(Markup m) {
        getLogger().fail(m);
    }

    public static void logFail(String details, Media media) {
        getLogger().fail(details, media);
    }

    public static void logSkip(String message) {
        getLogger().skip(message);
    }

}
