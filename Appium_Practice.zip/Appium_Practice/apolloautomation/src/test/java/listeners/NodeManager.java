package listeners;

import com.aventstack.extentreports.ExtentTest;

import java.util.Objects;

public class NodeManager {

    private static final ThreadLocal<ExtentTest> testNode = new ThreadLocal();

    private NodeManager() {
    }

    static ExtentTest getTestNode() {
        return (ExtentTest) testNode.get();
    }

    static void setTestNode(ExtentTest test) {
        if (Objects.nonNull(test)) {
            testNode.set(test);
        }

    }

    static void unload() {
        testNode.remove();
    }
}
