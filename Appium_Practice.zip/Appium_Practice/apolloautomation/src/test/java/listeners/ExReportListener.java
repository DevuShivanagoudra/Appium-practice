package listeners;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import io.appium.java_client.AppiumDriver;
import jarvis.mobile.common.driver.CustomDriver;
import jarvis.mobile.common.driver.DriverFactory;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class ExReportListener<D extends CustomDriver> extends
        DriverFactory<D> implements ITestListener {

    private static final String SCREENSHOT_PATH = String
            .format("%s%s", System.getProperty("user.home"), "/Documents/Projects/apolloautomation");

    public ExReportListener() {
    }

    public static synchronized String getScreenshot(final AppiumDriver driver) {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String path = String.format("%s%s%s%s",
                SCREENSHOT_PATH, "/screenshots/", System.currentTimeMillis(), ".png");
        File destination = new File(path);
        try {
            FileUtils.copyFile(src, destination);
        } catch (IOException e) {
            log.error("Capture Failed {}", e.getMessage());
        }
        return path;
    }

    public void onFinish(ITestContext context) {
        ExReporter.flushReport();
    }

    @SneakyThrows
    public void onTestStart(ITestResult result) {
        ExReporter.initReport();
        ExReporter
                .createTest(result.getMethod().getMethodName(), result.getMethod().getDescription());
    }

    public void onTestSuccess(ITestResult result) {
        ExReporter.logPass(result.getMethod().getMethodName() + " Passed.");
    }

    public void onTestFailure(ITestResult result) {
        String screen;
        String message = String.format("%s%n%s", result.getThrowable().toString(),
                String.join("\n", this.getStackTraceAsList(result)));
        try {
            screen = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.BASE64);
            ExReporter.logFail(MarkupHelper.createCodeBlock(message, CodeLanguage.XML).getMarkup(),
                    MediaEntityBuilder.createScreenCaptureFromBase64String(screen).build());
        } catch (Exception e) {
            log.error("Capture Failed {}", e.getMessage());
            ExReporter.logFail(MarkupHelper.createCodeBlock(message, CodeLanguage.XML).getMarkup());
        }
    }

    @SneakyThrows
    public void onTestSkipped(ITestResult result) {
        ExReporter.initReport();
        ExReporter.logSkip(result.getMethod().getMethodName() + " was Skipped.");
    }

    protected List<String> getStackTraceAsList(ITestResult result) {
        return (List) Arrays.stream(result.getThrowable().getStackTrace())
                .map(StackTraceElement::toString).collect(Collectors.toList());
    }
}


